import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [adminUser, setAdminUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [networkErrorAuth, setNetworkErrorAuth] = useState(null);
  const { toast } = useToast();

  const fetchUserSession = useCallback(async () => {
    setLoadingAuth(true);
    setNetworkErrorAuth(null);
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) {
        if (error.message.toLowerCase().includes('failed to fetch')) {
          setNetworkErrorAuth("Error de red al obtener sesión. Verifica tu conexión.");
          toast({ title: "Error de Red", description: "No se pudo conectar con el servidor de autenticación. Verifica tu conexión.", variant: "destructive", duration: 7000 });
        } else {
          toast({ title: "Error obteniendo sesión", description: error.message, variant: "destructive" });
        }
        throw error;
      }
      setCurrentUser(session?.user ?? null);
      if (session?.user?.email === 'direcwork@gmail.com') {
        setAdminUser(session.user);
      } else {
        setAdminUser(null);
      }
      return session?.user ?? null;
    } catch (error) {
      setCurrentUser(null);
      setAdminUser(null);
      return null;
    } finally {
      setLoadingAuth(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchUserSession();
    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      setNetworkErrorAuth(null); 
      setCurrentUser(session?.user ?? null);
      if (session?.user?.email === 'direcwork@gmail.com') {
        setAdminUser(session.user);
      } else {
        setAdminUser(null);
      }
      setLoadingAuth(false);
    });
    return () => authListener.subscription.unsubscribe();
  }, [fetchUserSession]);

  return { currentUser, adminUser, setAdminUser, loadingAuth, fetchUserSession, networkErrorAuth };
};