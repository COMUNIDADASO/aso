import { useContext } from 'react';
import { Web3WalletContext } from '@/context/Web3WalletProvider';

export const useWeb3 = () => {
  const context = useContext(Web3WalletContext);
  if (context === null) {
    throw new Error('useWeb3 must be used within a Web3WalletProvider');
  }
  return context;
};