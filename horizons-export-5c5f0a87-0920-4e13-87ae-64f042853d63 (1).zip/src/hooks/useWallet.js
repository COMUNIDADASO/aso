import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { ASSET_CONFIG } from '@/config/assets.jsx';

export const useWallet = (userId) => {
  const { toast } = useToast();
  const [balances, setBalances] = useState({});
  const [transactions, setTransactions] = useState([]);
  const [loadingBalances, setLoadingBalances] = useState(true);
  const [loadingTransactions, setLoadingTransactions] = useState(true);
  const [networkErrorWallet, setNetworkErrorWallet] = useState(null);

  const fetchBalances = useCallback(async () => {
    if (!userId) {
      setBalances(ASSET_CONFIG.reduce((acc, asset) => ({ ...acc, [asset.symbol]: 0 }), {}));
      setLoadingBalances(false);
      return;
    }

    setLoadingBalances(true);
    setNetworkErrorWallet(null);
    try {
      const { data, error } = await supabase
        .from('user_wallets')
        .select('asset_symbol, balance')
        .eq('user_id', userId);

      if (error) {
        if (error.message.toLowerCase().includes('failed to fetch')) {
          setNetworkErrorWallet("Error de red al cargar saldos. Verifica tu conexión.");
        }
        throw error;
      }

      const calculatedBalances = data.reduce((acc, wallet) => {
        const symbol = wallet.asset_symbol?.trim();
        if (symbol && wallet.balance !== null) {
          const balanceValue = parseFloat(wallet.balance);
          if (!isNaN(balanceValue)) {
            acc[symbol] = (acc[symbol] || 0) + balanceValue;
          }
        }
        return acc;
      }, {});

      const finalBalances = ASSET_CONFIG.reduce((acc, asset) => {
        acc[asset.symbol] = calculatedBalances[asset.symbol] || 0;
        return acc;
      }, {});
      
      setBalances(finalBalances);

    } catch (error) {
      if (!networkErrorWallet) {
        toast({ title: "Error al cargar saldos", description: error.message, variant: "destructive" });
      }
      setBalances(ASSET_CONFIG.reduce((acc, asset) => ({ ...acc, [asset.symbol]: 0 }), {}));
    } finally {
      setLoadingBalances(false);
    }
  }, [userId, toast]);

  const fetchTransactions = useCallback(async () => {
    if (!userId) {
      setTransactions([]);
      setLoadingTransactions(false);
      return;
    }
    setNetworkErrorWallet(null);
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
         if (error.message.toLowerCase().includes('failed to fetch')) {
          setNetworkErrorWallet("Error de red al cargar transacciones. Verifica tu conexión.");
        }
        throw error;
      }
      setTransactions(data.map(tx => ({
        ...tx,
        date: new Date(tx.created_at).toLocaleDateString(),
        description: tx.type === 'intercambio' 
          ? `${tx.from_asset_symbol || ''} ${tx.from_amount || ''} -> ${tx.to_asset_symbol || ''} ${tx.to_amount || ''}`.trim()
          : tx.type === 'mineria'
          ? `Recompensa de minería ASO`
          : `${tx.notes || tx.type}`.trim(),
        amountDisplay: tx.type === 'intercambio' 
          ? `-${tx.from_amount} ${tx.from_asset_symbol} / +${tx.to_amount} ${tx.to_asset_symbol}` 
          : tx.type === 'mineria'
          ? `+${tx.mining_reward} ASO`
          : `+${tx.to_amount || tx.from_amount} ${tx.to_asset_symbol || tx.from_asset_symbol}`
      })));
    } catch (error) {
      if (!networkErrorWallet) {
        toast({ title: "Error al cargar transacciones", description: error.message, variant: "destructive" });
      }
      setTransactions([]);
    } finally {
      setLoadingTransactions(false);
    }
  }, [userId, toast]);

  const fetchAllWalletData = useCallback(async () => {
    if (!userId) {
      setLoadingBalances(false);
      setLoadingTransactions(false);
      setNetworkErrorWallet(null);
      return;
    }
    setLoadingBalances(true);
    setLoadingTransactions(true);
    setNetworkErrorWallet(null);
    await Promise.all([
      fetchBalances(),
      fetchTransactions()
    ]);
  }, [userId, fetchBalances, fetchTransactions]);

  useEffect(() => {
    if (userId) {
      fetchAllWalletData();

      const walletsChannel = supabase
        .channel(`realtime:wallets:${userId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'user_wallets', filter: `user_id=eq.${userId}` },
          (payload) => {
            console.log('Realtime wallet change received, refetching all balances for consistency:', payload);
            toast({
              title: "¡Wallet actualizada!",
              description: "Sincronizando tus saldos en tiempo real...",
              variant: 'success'
            });
            fetchBalances();
          }
        )
        .subscribe((status, err) => {
          if (status === 'SUBSCRIBED') {
            console.log(`Successfully subscribed to realtime wallets channel for user ${userId}`);
          }
          if (status === 'CHANNEL_ERROR') {
            console.error(`Failed to subscribe to wallets channel:`, err);
            toast({
              title: "Error de Conexión en Tiempo Real",
              description: "No se pudieron obtener actualizaciones automáticas de saldo.",
              variant: "destructive",
            });
          }
        });
        
      const transactionsChannel = supabase
        .channel(`realtime:transactions:${userId}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'transactions', filter: `user_id=eq.${userId}` },
          (payload) => {
            console.log('Transaction change received!', payload);
            toast({
              title: "Nueva Transacción",
              description: "Tu historial de transacciones ha sido actualizado.",
              variant: 'info'
            });
            fetchTransactions();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(walletsChannel);
        supabase.removeChannel(transactionsChannel);
      };
    } else {
      setBalances({});
      setTransactions([]);
      setLoadingBalances(true);
      setLoadingTransactions(true);
    }
  }, [userId, fetchAllWalletData, fetchBalances, fetchTransactions, toast]);

  return { 
    balances, 
    transactions, 
    loadingBalances, 
    loadingTransactions, 
    fetchAllWalletData,
    networkErrorWallet
  };
};