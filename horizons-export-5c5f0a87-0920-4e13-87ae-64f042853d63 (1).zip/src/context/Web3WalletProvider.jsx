import React, { useState, createContext, useCallback, useEffect } from 'react';
import { ethers } from 'ethers';
import { useToast } from '@/components/ui/use-toast';

export const Web3WalletContext = createContext(null);

export const Web3WalletProvider = ({ children }) => {
  const [provider, setProvider] = useState(null);
  const [account, setAccount] = useState(null);
  const [signer, setSigner] = useState(null);
  const [chainId, setChainId] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleAccountsChanged = (accounts) => {
    if (accounts.length === 0) {
      disconnectWallet();
      toast({
        title: "Wallet Desconectada",
        description: "Has desconectado tu wallet. Conéctate de nuevo para continuar.",
        variant: "warning",
      });
    } else {
      setAccount(accounts[0]);
    }
  };

  const handleChainChanged = (newChainId) => {
    setChainId(newChainId);
    window.location.reload(); 
  };
  
  const connectWallet = useCallback(async () => {
    setLoading(true);
    setError(null);
    if (typeof window.ethereum === 'undefined') {
      toast({
        title: "Wallet no encontrada",
        description: "Por favor, instala MetaMask o usa un navegador compatible con dApps.",
        variant: "destructive",
      });
      setError("No se encontró un proveedor de wallet (ej. MetaMask).");
      setLoading(false);
      return;
    }

    try {
      const web3Provider = new ethers.BrowserProvider(window.ethereum, 'any');
      const accounts = await web3Provider.send("eth_requestAccounts", []);
      
      if (accounts.length > 0) {
        setProvider(web3Provider);
        const currentSigner = await web3Provider.getSigner();
        setSigner(currentSigner);
        setAccount(accounts[0]);
        const network = await web3Provider.getNetwork();
        setChainId(network.chainId.toString());

        toast({
          title: "Wallet Conectada",
          description: `Conectado con la dirección: ${accounts[0].substring(0, 6)}...${accounts[0].substring(accounts[0].length - 4)}`,
          variant: "success",
        });

        window.ethereum.on('accountsChanged', handleAccountsChanged);
        window.ethereum.on('chainChanged', handleChainChanged);

      } else {
        throw new Error("No se seleccionó ninguna cuenta.");
      }
    } catch (err) {
      console.error("Error conectando la wallet:", err);
      setError(err.message);
      toast({
        title: "Error al Conectar",
        description: err.code === 4001 ? "La solicitud de conexión fue rechazada." : err.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const disconnectWallet = useCallback(() => {
    setProvider(null);
    setSigner(null);
    setAccount(null);
    setChainId(null);
    if (window.ethereum) {
      window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
      window.ethereum.removeListener('chainChanged', handleChainChanged);
    }
  }, []);

  const value = {
    provider,
    account,
    signer,
    chainId,
    error,
    loading,
    connectWallet,
    disconnectWallet,
  };

  return (
    <Web3WalletContext.Provider value={value}>
      {children}
    </Web3WalletContext.Provider>
  );
};