import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';

import AdminHeader from '@/components/admin/AdminHeader';
import AdminFooter from '@/components/admin/AdminFooter';
import AdminDashboard from '@/components/admin/AdminDashboard';
import AdminLoginForm from '@/components/admin/AdminLoginForm';
import ManageUsers from '@/components/admin/sections/ManageUsers';
import ManageUserMining from '@/components/admin/sections/ManageUserMining';
import UserImportManager from '@/components/admin/UserImportManager';
import ManageNewsFeed from '@/components/admin/sections/ManageNewsFeed';
import ManageReserveFunds from '@/components/admin/sections/ManageReserveFunds';
import ManageContent from '@/components/admin/sections/ManageContent.jsx';
import { Home, Users, Settings, UploadCloud, Newspaper, Gift, FileVideo } from 'lucide-react'; 


const AdminPanel = () => {
  const { adminUser, setAdminUser, loadingAuth } = useAuth();
  const [showAdminLogin, setShowAdminLogin] = useState(true);
  const [activeSection, setActiveSection] = useState('dashboard');
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAdminSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session && session.user && session.user.email === 'direcwork@gmail.com') {
        setAdminUser(session.user);
        setShowAdminLogin(false);
      } else if (session && session.user && session.user.email !== 'direcwork@gmail.com') {
        await supabase.auth.signOut();
        setAdminUser(null);
        setShowAdminLogin(true);
        toast({ title: "Acceso Denegado", description: "Por favor, inicia sesión como administrador.", variant: "warning" });
      } else {
        setAdminUser(null);
        setShowAdminLogin(true);
      }
    };

    if (!loadingAuth) {
      checkAdminSession();
    }

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user?.email === 'direcwork@gmail.com') {
        setAdminUser(session.user);
        setShowAdminLogin(false);
      } else if (event === 'SIGNED_OUT') {
        setAdminUser(null);
        setShowAdminLogin(true);
        setActiveSection('dashboard'); 
      } else if (session && session.user.email !== 'direcwork@gmail.com') {
        await supabase.auth.signOut();
        setAdminUser(null);
        setShowAdminLogin(true);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [setAdminUser, navigate, toast, loadingAuth]);

  const handleAdminLoginSuccess = (user) => {
    setAdminUser(user);
    setShowAdminLogin(false);
    toast({ title: "¡Bienvenido, Admin!", description: "Has iniciado sesión correctamente." });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setAdminUser(null);
    setShowAdminLogin(true);
    navigate('/');
    toast({ title: "Sesión Cerrada", description: "Has cerrado sesión como administrador." });
  };

  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', label: 'Dashboard', icon: Home, component: <AdminDashboard menuItems={[]} /> },
    { id: 'reserve-funds', name: 'Fondos de Reserva', label: 'Fondos de Reserva', icon: Gift, component: <ManageReserveFunds /> },
    { id: 'manage-content', name: 'Gestionar Contenido', label: 'Contenido', icon: FileVideo, component: <ManageContent /> },
    { id: 'manage-users', name: 'Gestionar Usuarios', label: 'Gestionar Usuarios', icon: Users, component: <ManageUsers /> },
    { id: 'manage-mining', name: 'Gestionar Minería', label: 'Gestionar Minería', icon: Settings, component: <ManageUserMining /> },
    { id: 'import-users', name: 'Importar Usuarios', label: 'Importar Usuarios', icon: UploadCloud, component: <UserImportManager /> },
    { id: 'manage-news', name: 'Gestionar Noticias', label: 'Gestionar Noticias', icon: Newspaper, component: <ManageNewsFeed /> },
  ];
  
  const dashboardMenuItems = menuItems
    .filter(item => item.id !== 'dashboard') 
    .map(item => ({ ...item, action: () => setActiveSection(item.id) }));


  if (loadingAuth) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-900"><p className="text-white text-lg">Cargando panel de administrador...</p></div>;
  }

  if (showAdminLogin || !adminUser) {
    return <AdminLoginForm onLoginSuccess={handleAdminLoginSuccess} />;
  }
  
  let CurrentSectionComponent;
  if (activeSection === 'dashboard') {
    CurrentSectionComponent = <AdminDashboard menuItems={dashboardMenuItems} />;
  } else {
    CurrentSectionComponent = menuItems.find(item => item.id === activeSection)?.component || <AdminDashboard menuItems={dashboardMenuItems} />;
  }


  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-900 text-slate-100">
      <AdminHeader 
        adminUser={adminUser} 
        onLogout={handleLogout} 
        activeSection={activeSection}
        onSetActiveSection={setActiveSection}
        menuItems={menuItems}
      />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {CurrentSectionComponent}
      </main>
      <AdminFooter />
    </div>
  );
};

export default AdminPanel;