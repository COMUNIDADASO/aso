import React, { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { RefreshCw, Loader2 } from 'lucide-react';

const LedgerPage = () => {
    const [ledgerEntries, setLedgerEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    const fetchLedger = useCallback(async () => {
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('crypto_ledger')
                .select(`
                    id,
                    created_at,
                    asset_symbol,
                    amount,
                    transaction_type,
                    notes,
                    user:users(email)
                `)
                .order('created_at', { ascending: false })
                .limit(100);

            if (error) throw error;

            setLedgerEntries(data.map(e => ({...e, user_email: e.user?.email || 'Sistema' })));
        } catch (error) {
            toast({
                title: 'Error al Cargar el Libro Mayor',
                description: error.message,
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    useEffect(() => {
        fetchLedger();
    }, [fetchLedger]);

    const formatAmount = (amount, symbol) => {
        const isCredit = parseFloat(amount) > 0;
        const color = isCredit ? 'text-green-400' : 'text-red-400';
        return (
            <span className={color}>
                {isCredit ? '+' : ''}
                {parseFloat(amount).toLocaleString(undefined, { maximumFractionDigits: 8 })} {symbol}
            </span>
        );
    };

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="p-4 sm:p-6 lg:p-8 text-white"
        >
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-slate-100">Libro Mayor de Criptomonedas</h1>
                <Button onClick={fetchLedger} disabled={loading}>
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                    Actualizar
                </Button>
            </div>
            
            <div className="rounded-lg border border-slate-700 bg-slate-800/50 shadow-lg overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow className="border-slate-700 hover:bg-slate-800/80">
                            <TableHead className="text-slate-300">Fecha</TableHead>
                            <TableHead className="text-slate-300">Usuario</TableHead>
                            <TableHead className="text-slate-300">Monto</TableHead>
                            <TableHead className="text-slate-300">Tipo</TableHead>
                            <TableHead className="text-slate-300">Notas</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {loading ? (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center py-10">
                                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-purple-400" />
                                </TableCell>
                            </TableRow>
                        ) : ledgerEntries.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center text-slate-400 py-10">
                                    No hay entradas en el libro mayor.
                                </TableCell>
                            </TableRow>
                        ) : (
                            ledgerEntries.map((entry) => (
                                <TableRow key={entry.id} className="border-slate-800">
                                    <TableCell className="text-slate-400 text-xs">{new Date(entry.created_at).toLocaleString()}</TableCell>
                                    <TableCell className="font-medium text-slate-200 text-xs">{entry.user_email}</TableCell>
                                    <TableCell className="font-mono">{formatAmount(entry.amount, entry.asset_symbol)}</TableCell>
                                    <TableCell className="text-slate-300 capitalize text-xs">{entry.transaction_type.replace(/_/g, ' ')}</TableCell>
                                    <TableCell className="text-slate-400 text-xs">{entry.notes}</TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
        </motion.div>
    );
};

export default LedgerPage;