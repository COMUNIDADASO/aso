import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Shovel, Clock, Coins, AlertTriangle, CheckCircle2, Loader2, Zap, Gift, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';

const MINING_INTERVAL_HOURS = 24;
const MINING_INTERVAL_MS = MINING_INTERVAL_HOURS * 60 * 60 * 1000;

const MiningPage = () => {
  const { toast } = useToast();
  const { currentUser, loadingAuth, networkErrorAuth } = useAuth();
  const [miningProfile, setMiningProfile] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [isMining, setIsMining] = useState(false);
  const [showMineButton, setShowMineButton] = useState(false);
  const [pageMessage, setPageMessage] = useState("Cargando estado...");
  const [networkErrorMining, setNetworkErrorMining] = useState(null);

  const fetchMiningStatus = useCallback(async (userId) => {
    if (!userId) {
      setLoadingStatus(false);
      setPageMessage("Inicia sesión para minar.");
      setShowMineButton(false);
      setMiningProfile(null);
      return;
    }
    setLoadingStatus(true);
    setNetworkErrorMining(null);
    try {
      const { data, error } = await supabase
        .from('user_mining_profiles')
        .select('mining_rate_aso_per_day, is_mining_active, is_capacitado, last_claimed_at')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') { 
        if (error.message.toLowerCase().includes('failed to fetch')) {
            setNetworkErrorMining("Error de red al cargar el estado de minería. Verifica tu conexión.");
        }
        throw error;
      }
      
      if (data) {
        setMiningProfile(data);
        if (data.last_claimed_at) {
          const lastMinedTime = new Date(data.last_claimed_at).getTime();
          const nextMineTime = lastMinedTime + MINING_INTERVAL_MS;
          const now = Date.now();
          const remaining = Math.max(0, Math.floor((nextMineTime - now) / 1000));
          setTimeLeft(remaining);
          if (remaining > 0) {
            setShowMineButton(false);
            setPageMessage("Próxima Sesión de Minería en:");
          } else {
            setShowMineButton(data.is_mining_active);
            setPageMessage(data.is_mining_active ? "¡Listo para Minar HOY?" : "Minería no activa.");
          }
        } else {
          setTimeLeft(0); 
          setShowMineButton(data.is_mining_active);
          setPageMessage(data.is_mining_active ? "¡Listo para Minar HOY?" : "Minería no activa.");
        }
      } else {
        setMiningProfile({ mining_rate_aso_per_day: 0, is_mining_active: false, is_capacitado: false, last_claimed_at: null });
        setTimeLeft(0);
        setShowMineButton(false); 
        setPageMessage("Perfil de Minería no encontrado. Contacta a soporte.");
        toast({ title: "Perfil de Minería no encontrado", description: "Asegúrate de que tu cuenta esté configurada para minar.", variant: "warning" });
      }
    } catch (error) {
      if (!networkErrorMining) { 
        toast({ title: "Error al cargar estado de minería", description: error.message, variant: "destructive" });
      }
      setMiningProfile({ mining_rate_aso_per_day: 0, is_mining_active: false, is_capacitado: false, last_claimed_at: null });
      setShowMineButton(false);
      setPageMessage("Error al cargar perfil.");
    } finally {
      setLoadingStatus(false);
    }
  }, [toast]);

  useEffect(() => {
    if (currentUser) {
      fetchMiningStatus(currentUser.id);
    } else if (!loadingAuth) {
      setLoadingStatus(false);
      setMiningProfile(null);
      setShowMineButton(false);
      setPageMessage("Inicia sesión para minar.");
    }
  }, [currentUser, loadingAuth, fetchMiningStatus]);

  useEffect(() => {
    let timer;
    if (timeLeft > 0 && miningProfile?.is_mining_active) {
      setShowMineButton(false); 
      setPageMessage("Próxima Sesión de Minería en:");
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            if (miningProfile?.is_mining_active) {
                 setShowMineButton(true);
                 setPageMessage("¡Listo para Minar HOY?");
            } else {
                 setShowMineButton(false);
                 setPageMessage("Minería no activa.");
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (miningProfile) {
        setShowMineButton(miningProfile.is_mining_active && timeLeft === 0);
        setPageMessage(miningProfile.is_mining_active ? "¡Listo para Minar HOY?" : "Minería no activa.");
    }
    return () => clearInterval(timer);
  }, [timeLeft, miningProfile]);

  const formatTime = (seconds) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleMine = async () => {
    if (!currentUser || !miningProfile) {
      toast({ title: "Minería no disponible", description: "No se pudo cargar tu perfil de minería o necesitas iniciar sesión.", variant: "warning" });
      return;
    }
    if (!miningProfile.is_mining_active) {
      toast({ title: "Minería Desactivada", description: "La minería no está activa para tu cuenta. Contacta al administrador.", variant: "warning" });
      return;
    }
    if (timeLeft > 0) {
      toast({ title: "YA ESTÁS MINANDO", description: `EN 24 TENDRÁS MÁS ASO AL MINAR NUEVAMENTE.`, variant: "default" });
      return;
    }

    setIsMining(true);
    setNetworkErrorMining(null);
    try {
      const { data, error: functionError } = await supabase.functions.invoke('claim-mining-reward', {
        body: { userId: currentUser.id }
      });

      if (functionError) {
        console.error("Edge function error object:", functionError);
        let detailedMessage = "Error de la función Edge. Intenta de nuevo.";
        if (functionError instanceof TypeError && functionError.message.toLowerCase().includes('failed to fetch')) {
            detailedMessage = "Error de red al contactar la función. Revisa tu conexión.";
            setNetworkErrorMining(detailedMessage);
        } else if (functionError.message && functionError.message.includes("Function returned non-2xx status")) {
            try {
                const errorContextBody = functionError.context?.response_body;
                const errorResponse = typeof errorContextBody === 'string' ? JSON.parse(errorContextBody) : errorContextBody || {};
                detailedMessage = errorResponse.error || "La función de minería devolvió un error.";
            } catch (e) {
                console.error("Failed to parse error response body:", e);
                detailedMessage = "Error no especificado de la función de minería.";
            }
        } else {
            detailedMessage = functionError.message;
        }
        throw new Error(detailedMessage);
      }
      
      if (data?.error) {
         throw new Error(data.error);
      }
      
      toast({ 
        title: "¡TE FELICITO!", 
        description: `ESTÁS MINANDO FUTURO CON DIGINiDAD. Has minado ${parseFloat(data.reward).toFixed(10)} ASO.`, 
        variant: "success",
        duration: 7000
      });
      setShowMineButton(false); 
      setPageMessage("Próxima Sesión de Minería en:"); 
      await fetchMiningStatus(currentUser.id); 
    } catch (error) {
      if (!networkErrorMining) {
        const errorMessage = (error.message || '').toLowerCase();
        if (errorMessage.includes('already claimed') || errorMessage.includes('ya ha minado') || errorMessage.includes('recently')) {
          toast({
            title: 'YA ESTÁS MINANDO',
            description: 'EN 24 TENDRÁS MÁS ASO AL MINAR NUEVAMENTE.',
            variant: 'default',
            duration: 7000,
          });
          fetchMiningStatus(currentUser.id);
        } else {
          toast({ title: "Error de Minería", description: error.message, variant: "destructive" });
        }
      }
    } finally {
      setIsMining(false);
    }
  };

  if (loadingAuth || (loadingStatus && !networkErrorMining && !networkErrorAuth)) {
    return (
      <div className="container mx-auto px-4 sm:px-6 py-20 text-center flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
        <Loader2 size={64} className="mx-auto text-purple-400 mb-4 animate-spin" />
        <p className="text-lg text-gray-300">Cargando información de minería...</p>
      </div>
    );
  }

  if (!currentUser && !loadingAuth) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="container mx-auto px-4 sm:px-6 py-20 text-center flex flex-col items-center justify-center min-h-[calc(100vh-200px)]"
      >
        <Shovel size={64} className="mx-auto text-purple-400 mb-4" />
        <h1 className="text-3xl sm:text-4xl font-bold mb-4 gradient-text-gold">Minería ASO</h1>
        <p className="text-lg text-gray-300 mb-6">Inicia sesión para comenzar a minar ASO y ver tu progreso.</p>
        <Button onClick={() => {
          const authModalTrigger = document.querySelector('button[data-auth-modal-trigger="true"]');
          if (authModalTrigger) authModalTrigger.click();
        }} className="gradient-bg hover:opacity-90">
          Iniciar Sesión
        </Button>
      </motion.div>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto px-4 sm:px-6 py-12 sm:py-20"
    >
      <div className="text-center mb-12 sm:mb-16">
        <h1 className="text-4xl sm:text-5xl font-bold mb-4 sm:mb-6">
          Minería <span className="gradient-text-gold">ASO</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto">
          ¡Participa en la minería de ASO y gana recompensas! Haz clic para minar cada {MINING_INTERVAL_HOURS} horas.
        </p>
      </div>

      {(networkErrorMining || networkErrorAuth) && (
        <div className="max-w-md mx-auto p-4 mb-6 bg-yellow-900/30 border border-yellow-700/50 rounded-lg text-center">
          <WifiOff className="mx-auto h-8 w-8 text-yellow-400 mb-2" />
          <p className="text-yellow-300 font-semibold">Error de Red</p>
          <p className="text-slate-300 text-sm">{networkErrorMining || networkErrorAuth}</p>
          <Button variant="link" onClick={() => fetchMiningStatus(currentUser.id)} className="text-purple-400 mt-2">Reintentar</Button>
        </div>
      )}

      <div className="max-w-md mx-auto glass-effect rounded-xl sm:rounded-3xl p-6 sm:p-10 shadow-2xl">
        <div className="text-center mb-6 sm:mb-8">
          <div className="w-20 h-20 sm:w-24 sm:h-24 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-5 pulse-glow-subtle">
            <Gift className="h-10 w-10 sm:h-12 sm:w-12 text-white" />
          </div>
          <h3 className="text-2xl sm:text-3xl font-bold mb-2 text-slate-100">{pageMessage}</h3>
          {miningProfile && miningProfile.is_mining_active ? (
            timeLeft > 0 ? (
              <div className="text-4xl sm:text-5xl font-mono gradient-text mb-2 sm:mb-3">
                {formatTime(timeLeft)}
              </div>
            ) : (
              <div className="text-green-400 text-2xl sm:text-3xl font-semibold mb-2 sm:mb-3">
                <CheckCircle2 className="inline-block mr-2 h-8 w-8" />
                ¡Ahora!
              </div>
            )
          ) : (
            <div className="text-yellow-400 text-lg sm:text-xl font-semibold mb-2 sm:mb-3">
              {miningProfile ? "Minería no activa." : (networkErrorMining || networkErrorAuth) ? "Reintentando conexión..." : "Cargando..."}
            </div>
          )}
        </div>

        {miningProfile && miningProfile.is_mining_active && showMineButton && (
            <Button 
              onClick={handleMine}
              disabled={isMining || timeLeft > 0 || !!networkErrorMining || !!networkErrorAuth} 
              className="w-full text-lg py-3 sm:py-4 gradient-bg hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {isMining ? <Loader2 className="h-6 w-6 mr-2 animate-spin" /> : <Coins className="h-6 w-6 mr-2" />}
              {isMining ? 'Procesando...' : 'Minar ASO Ahora'}
            </Button>
        )}

        {miningProfile && !miningProfile.is_mining_active && (
           <div className="flex items-center justify-center p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg text-yellow-300">
              <AlertTriangle className="h-6 w-6 mr-3" />
              <span>La minería no está habilitada para tu cuenta. Contacta al administrador.</span>
            </div>
        )}
        
        {!miningProfile && !loadingStatus && !loadingAuth && currentUser && !networkErrorMining && !networkErrorAuth && (
            <div className="flex items-center justify-center p-4 bg-slate-700/50 rounded-lg text-slate-400">
            <AlertTriangle className="h-6 w-6 mr-3" />
            <span>No se pudo cargar tu perfil de minería. Intenta recargar o contacta a soporte.</span>
          </div>
        )}

        <div className="mt-8 space-y-4 text-sm">
          <div className="flex items-center text-slate-300">
            <Zap className="h-5 w-5 mr-3 text-yellow-400" />
            <span>Tasa de Minería: {miningProfile ? parseFloat(miningProfile.mining_rate_aso_per_day).toFixed(10) : '0.0000000000'} ASO/día</span>
          </div>
          <div className="flex items-center text-slate-300">
            <Clock className="h-5 w-5 mr-3 text-purple-400" />
            <span>Intervalo: Cada {MINING_INTERVAL_HOURS} horas</span>
          </div>
          {miningProfile?.last_claimed_at && (
            <div className="flex items-center text-slate-300">
              <CheckCircle2 className="h-5 w-5 mr-3 text-green-400" />
              <span>Última minería: {new Date(miningProfile.last_claimed_at).toLocaleString()}</span>
            </div>
          )}
           {miningProfile?.is_capacitado && (
            <div className="flex items-center text-slate-300">
              <CheckCircle2 className="h-5 w-5 mr-3 text-blue-400" />
              <span>Estado: Capacitado</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default MiningPage;