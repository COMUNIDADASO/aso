import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import ProductCard from '@/components/ProductCard';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Package, Leaf, Wind, Loader2 } from 'lucide-react';

const products = [
  {
    id: 'forraje-module',
    name: 'Módulo de Forraje Hidropónico',
    icon: Leaf,
    shortDescription: 'Solución completa para producción intensiva de forraje verde hidropónico.',
    price: 5000,
    features: [
      'Capacidad para 200 bandejas',
      'Bomba de agua y tanque PVC de 200L incluidos',
      '200 bandejas de acero inoxidable',
      'Estructura de hierro con baño anticorrosivo',
      'Malla gris (1.5m x 5m)',
      'Sistema de riego por aspersión completo (mangueras, boquillas)',
      'Timer para control de riego',
      'Medidor digital de PH y CE',
    ],
    productionValue: 'Produce en promedio $2,500 USD mensuales.',
    note: 'La capacitación para su uso no se incluye en el valor del módulo.',
  },
  {
    id: 'aeroponia-module',
    name: 'Módulo de Aeroponía Avanzado',
    icon: Wind,
    shortDescription: 'Sistema de cultivo aeropónico de alta eficiencia para 600 plantas.',
    price: 4000,
    features: [
      'Capacidad para 600 plantas',
      'Bomba de agua y tanque PVC de 200L incluidos',
      '3 tubos de PVC de 200mm para cultivo',
      'Estructura de hierro con baño anticorrosivo',
      'Malla gris (1.5m x 5m)',
      'Sistema de riego por aspersión completo (mangueras, boquillas)',
      'Timer para control de riego',
      'Medidor digital de PH y CE',
    ],
    productionValue: 'Produce en promedio $2,500 USD mensuales a partir de los 90 días.',
    note: 'La capacitación para su uso no se incluye en el valor del módulo.',
  },
];

const ShopPage = () => {
  const { toast } = useToast();
  const [payPalClientId, setPayPalClientId] = useState(null);
  const [loadingClientId, setLoadingClientId] = useState(true);

  useEffect(() => {
    const fetchPayPalClientId = async () => {
      setLoadingClientId(true);
      try {
        const { data, error } = await supabase.functions.invoke('get-paypal-client-id');
        if (error) throw error;
        if (data.clientId) {
          setPayPalClientId(data.clientId);
        } else {
          throw new Error(data.error || "No se pudo obtener el Client ID de PayPal.");
        }
      } catch (error) {
        console.error("Error fetching PayPal Client ID:", error);
        toast({
          title: "Error de Configuración de Pago",
          description: "No se pudo cargar la configuración de PayPal. Los pagos para productos podrían no estar disponibles.",
          variant: "destructive",
        });
        setPayPalClientId(null);
      } finally {
        setLoadingClientId(false);
      }
    };
    fetchPayPalClientId();
  }, [toast]);


  return (
    <div className="container mx-auto px-4 sm:px-6 py-24 sm:py-32">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-center mb-12 sm:mb-16"
      >
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-4">
          Tienda de <span className="gradient-text-gold">Módulos Productivos</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto">
          Invierte en tu futuro agrícola con nuestros módulos de última generación. Comienza a producir y generar ingresos con COMUNIDAD ASO.
        </p>
      </motion.div>

      {loadingClientId && (
        <div className="flex justify-center items-center my-10">
          <Loader2 className="h-12 w-12 animate-spin text-purple-400" />
          <p className="ml-3 text-slate-300">Cargando opciones de compra...</p>
        </div>
      )}

      {!loadingClientId && products.length > 0 && (
        <div className="grid md:grid-cols-2 gap-8 sm:gap-10 items-stretch mb-16">
          {products.map((product, index) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              index={index} 
              payPalClientId={payPalClientId} 
            />
          ))}
        </div>
      )}
      
      {!loadingClientId && products.length === 0 && !loadingClientId && (
         <div className="text-center my-10">
            <p className="text-xl text-gray-400">No hay productos disponibles en este momento. Vuelve más tarde.</p>
        </div>
      )}


      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.7 }}
        className="text-center p-6 sm:p-8 bg-slate-800/70 rounded-xl border border-slate-700 max-w-3xl mx-auto shadow-xl"
      >
        <h2 className="text-2xl sm:text-3xl font-bold text-gold-aso mb-4">¿Listo para Empezar?</h2>
        <p className="text-gray-300 mb-6 text-sm sm:text-base">
          Adquirir un módulo es el primer paso hacia la producción agrícola moderna y rentable. Recuerda que la capacitación se gestiona por separado para asegurar tu éxito.
        </p>
        <div className="flex items-center justify-center text-gray-400">
          <Package className="w-5 h-5 mr-2" />
          <p className="text-xs">Todos los módulos se entregan listos para ensamblar e iniciar producción.</p>
        </div>
      </motion.div>
    </div>
  );
};

export default ShopPage;