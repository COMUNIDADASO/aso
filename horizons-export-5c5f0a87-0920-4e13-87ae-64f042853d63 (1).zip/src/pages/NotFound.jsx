import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AlertTriangle, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
        className="text-center"
      >
        <AlertTriangle className="h-24 w-24 text-yellow-400 mx-auto mb-8 animate-pulse" />
        <h1 className="text-6xl font-bold mb-4 gradient-text">404</h1>
        <h2 className="text-3xl font-semibold mb-6">¡Ups! Página no encontrada</h2>
        <p className="text-lg text-gray-400 mb-10 max-w-md mx-auto">
          Parece que te has perdido en el ciberespacio agrícola. No te preocupes, podemos ayudarte a volver al camino.
        </p>
        <Link to="/">
          <Button size="lg" className="gradient-bg hover:opacity-90 transition-opacity group">
            <Home className="mr-2 h-5 w-5" />
            Volver a la Página Principal
            <span className="ml-2 text-xl group-hover:translate-x-1 transition-transform">🌱</span>
          </Button>
        </Link>
      </motion.div>

      <motion.div
        className="absolute top-10 left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl floating-animation"
        style={{ animationDelay: '0s' }}
      />
      <motion.div
        className="absolute bottom-10 right-10 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl floating-animation"
        style={{ animationDelay: '1s' }}
      />
    </div>
  );
};

export default NotFound;