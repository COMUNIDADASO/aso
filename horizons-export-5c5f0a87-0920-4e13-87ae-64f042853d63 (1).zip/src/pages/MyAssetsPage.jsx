import React, { useEffect, useState, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { useToast } from '@/components/ui/use-toast';
    import { useAuth } from '@/hooks/useAuth';
    import { useWallet } from '@/hooks/useWallet';
    import { supabase } from '@/lib/supabaseClient';
    import { ASSET_CONFIG } from '@/config/assets.jsx';

    import PageLoader from '@/components/my_assets/PageLoader';
    import LoginPrompt from '@/components/my_assets/LoginPrompt';
    import NetworkStatusBanners from '@/components/my_assets/NetworkStatusBanners';
    import UserProfileSection from '@/components/my_assets/UserProfileSection';
    import UserDashboardSection from '@/components/my_assets/UserDashboardSection';
    import NewsSlider from '@/components/my_assets/NewsSlider';
    import ManagementTabs from '@/components/my_assets/ManagementTabs';
    import ExternalExchangesSection from '@/components/my_assets/ExternalExchangesSection';
    import Web3WalletConnectSection from '@/components/my_assets/Web3WalletConnectSection';
    import TrainingSection from '@/components/my_assets/TrainingSection';
    import CommunityButton from '@/components/my_assets/CommunityButton';

    const MyAssetsPage = () => {
      const { toast } = useToast();
      const { currentUser, loadingAuth, networkErrorAuth } = useAuth();
      const { 
        balances, 
        transactions, 
        loadingBalances, 
        loadingTransactions,
        fetchAllWalletData,
        networkErrorWallet,
      } = useWallet(currentUser?.id);

      const [payPalClientId, setPayPalClientId] = useState(null);
      const [loadingPayPalId, setLoadingPayPalId] = useState(true);
      const [userProfileData, setUserProfileData] = useState(null);
      const [loadingProfile, setLoadingProfile] = useState(true);
      const [networkErrorPayPal, setNetworkErrorPayPal] = useState(null);
      const [networkErrorProfile, setNetworkErrorProfile] = useState(null);

      const fetchUserProfile = useCallback(async () => {
        if (!currentUser) {
          setLoadingProfile(false);
          return;
        }
        setLoadingProfile(true);
        setNetworkErrorProfile(null);
        try {
          const { data, error } = await supabase
            .from('users_imported')
            .select('auth_user_id, name, email, raw_data, avatar_url')
            .eq('auth_user_id', currentUser.id)
            .single();
          if (error && error.code !== 'PGRST116') {
            if (error.message.toLowerCase().includes('failed to fetch')) {
              setNetworkErrorProfile("Error de red al cargar tu perfil. Verifica tu conexión.");
            }
            throw error; 
          }
          setUserProfileData(data);
        } catch (error) {
          console.error("Error fetching user profile:", error);
           if (error.code !== 'PGRST116' && !networkErrorProfile) {
            toast({ title: "Error de Perfil", description: "No se pudo cargar tu información de perfil.", variant: "destructive" });
          }
        } finally {
          setLoadingProfile(false);
        }
      }, [currentUser, toast]);

      useEffect(() => {
        if (currentUser) {
          fetchUserProfile();
        } else if (!loadingAuth) { 
            setUserProfileData(null);
        }
      }, [currentUser, fetchUserProfile, loadingAuth]);

      const fetchPayPalClientIdWithRetry = useCallback(async (retries = 3, delay = 1000) => {
        setLoadingPayPalId(true);
        setNetworkErrorPayPal(null);
        for (let i = 0; i < retries; i++) {
          try {
            const { data, error } = await supabase.functions.invoke('get-paypal-client-id');
            if (error) {
              if (error instanceof TypeError && error.message.toLowerCase().includes('failed to fetch')) {
                if (i === retries - 1) { 
                  setNetworkErrorPayPal("Error de red persistente. La carga de saldo podría no estar disponible.");
                  throw error; 
                }
                await new Promise(resolve => setTimeout(resolve, delay * (i + 1))); 
                continue; 
              }
              throw error; 
            }
            if (data.clientId) {
              setPayPalClientId(data.clientId);
              setLoadingPayPalId(false);
              return; 
            } else {
              throw new Error(data.error || "No se pudo obtener el Client ID de PayPal.");
            }
          } catch (errorCatch) {
            if (i === retries - 1) { 
              console.error(`Error fetching PayPal Client ID after ${retries} retries:`, errorCatch);
              if(!networkErrorPayPal) { 
                 toast({
                  title: "Error de Configuración de Pago",
                  description: "No se pudo cargar la configuración de PayPal.",
                  variant: "destructive",
                });
              }
              setPayPalClientId(null);
              setLoadingPayPalId(false);
              return;
            }
          }
        }
      }, [toast]);

      useEffect(() => {
        fetchPayPalClientIdWithRetry();
      }, [fetchPayPalClientIdWithRetry]);

      const handleWalletLoadSuccess = async (details, loadedAmount) => {
        toast({
          title: "¡Saldo Cargado!",
          description: `Se han cargado ${loadedAmount.toFixed(2)} USD. Orden: ${details.id || 'N/A'}`,
          variant: "success",
        });
        if (currentUser) {
          try {
             await supabase.from('transactions').insert({
                user_id: currentUser.id, type: 'deposito_paypal', status: 'completado',
                deposit_amount_usd: loadedAmount, currency: 'USD',
                notes: `Carga de saldo vía PayPal. Order ID: ${details.id || details.orderID || 'N/A'}`,
                related_transaction_id: details.id || details.orderID || `paypal_${Date.now()}`
            });

            await supabase.functions.invoke('update-mining-profile', {
              body: { userId: currentUser.id, depositAmount: loadedAmount }
            });

            await fetchAllWalletData(); 
          } catch (error) {
            console.error("Error al registrar transacción o actualizar perfil:", error);
            const errorMsg = error.message.toLowerCase().includes('failed to fetch') ? 
                "El pago fue exitoso, pero hubo un problema de red al actualizar tu saldo. Contacta soporte si no se refleja."
                : "El pago fue exitoso, pero hubo un problema al actualizar tu saldo. Por favor, contacta a soporte.";
            toast({ title: "Error Post-Pago", description: errorMsg, variant: "destructive"});
          }
        }
      };

      const handlePaymentError = (error) => {
        toast({
          title: "Error en el Pago",
          description: `Ocurrió un error con PayPal: ${error.message || 'Error desconocido.'}`,
          variant: "destructive",
        });
      };

      const handleProfileUpdate = async (updatedData) => {
        if (!currentUser || !userProfileData) return; 
        setLoadingProfile(true);
        setNetworkErrorProfile(null);
        try {
          const updatePayload = { name: updatedData.name };
          if (updatedData.avatar_url) updatePayload.avatar_url = updatedData.avatar_url;
          if(updatedData.raw_data_updates) updatePayload.raw_data = { ...userProfileData.raw_data, ...updatedData.raw_data_updates };

          const { data, error } = await supabase
            .from('users_imported')
            .update(updatePayload)
            .eq('auth_user_id', currentUser.id)
            .select()
            .single();

          if (error) {
            if (error.message.toLowerCase().includes('failed to fetch')) setNetworkErrorProfile("Error de red al actualizar tu perfil.");
            throw error;
          }
          setUserProfileData(data); 
          toast({ title: "Perfil Actualizado", description: "Tu información de perfil ha sido guardada.", variant: "success" });
        } catch (error) {
          console.error("Error updating profile:", error);
          if(!networkErrorProfile) toast({ title: "Error", description: "No se pudo actualizar tu perfil.", variant: "destructive" });
        } finally {
          setLoadingProfile(false);
        }
      };

      const availableAssetsForTransfer = ASSET_CONFIG.map(asset => ({
        symbol: asset.symbol, name: asset.name, balance: balances[asset.symbol] || 0, precision: asset.precision
      }));

      if (loadingAuth || (loadingPayPalId && !networkErrorPayPal)) { 
         return <PageLoader message="Cargando tu dashboard..." />;
      }

      if (!currentUser && !loadingAuth) {
        return <LoginPrompt />;
      }
      
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="container mx-auto px-4 sm:px-6 py-12 sm:py-20"
        >
          <NetworkStatusBanners 
            errors={{ auth: networkErrorAuth, profile: networkErrorProfile, wallet: networkErrorWallet }}
            retryFunctions={{ profile: fetchUserProfile, wallet: fetchAllWalletData }}
          />
          <UserProfileSection 
            profileData={userProfileData} 
            onUpdateProfile={handleProfileUpdate}
            loading={loadingProfile}
          />
          <UserDashboardSection balances={balances} loadingBalances={loadingBalances} />
          <NewsSlider /> 
          <ManagementTabs
            balances={balances}
            transactions={transactions}
            loadingBalances={loadingBalances}
            loadingTransactions={loadingTransactions}
            fetchAllWalletData={fetchAllWalletData}
            currentUser={currentUser}
            payPalClientId={payPalClientId}
            loadingPayPalId={loadingPayPalId}
            networkErrorPayPal={networkErrorPayPal}
            fetchPayPalClientIdWithRetry={fetchPayPalClientIdWithRetry}
            handleWalletLoadSuccess={handleWalletLoadSuccess}
            handlePaymentError={handlePaymentError}
            availableAssetsForTransfer={availableAssetsForTransfer}
            userProfileData={userProfileData}
            loadingProfile={loadingProfile}
          />
          <TrainingSection 
            usdBalance={balances['USD'] || 0}
            loadingBalances={loadingBalances}
            userId={currentUser?.id}
            onBookingSuccess={fetchAllWalletData}
          />
          <ExternalExchangesSection />
          <Web3WalletConnectSection />
          <CommunityButton />
        </motion.div>
      );
    };

    export default MyAssetsPage;