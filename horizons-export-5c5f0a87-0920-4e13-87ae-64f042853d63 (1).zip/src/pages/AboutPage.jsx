import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users2, HeartHandshake, Brain, TrendingUp, Globe, Home, Eye, Youtube, Loader2 } from 'lucide-react';
import ManifestoVideo from '@/components/ManifestoVideo';
import { supabase } from '@/lib/supabaseClient';

const AboutPage = () => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png";
  
  const [manifestoVideoSrc, setManifestoVideoSrc] = useState(null);
  const [isLoadingVideo, setIsLoadingVideo] = useState(true);

  useEffect(() => {
    const fetchVideoUrl = async () => {
      setIsLoadingVideo(true);
      try {
        const { data, error } = await supabase
          .from('app_settings')
          .select('value,updated_at')
          .eq('key', 'about_page_video_url')
          .single();

        if (error && error.code !== 'PGRST116') {
          console.error("Error fetching video URL:", error);
        } else if (data && data.value) {
          setManifestoVideoSrc(data.value);
        }
      } catch (e) {
        console.error("Exception fetching video URL:", e);
      } finally {
        setIsLoadingVideo(false);
      }
    };

    fetchVideoUrl();
  }, []);

  const contentSections = [
    {
      icon: <Users2 className="h-8 w-8 sm:h-10 sm:w-10 text-gold-aso mb-3 sm:mb-4" />,
      title: "Nuestra Comunidad",
      text: "LA COMUNIDAD ASO se compone de 400 mil ciudadanos en todo el Ecuador que se capacitaron en la producción agrícola sin tierra con tecnología propia hidropónica, aeropónica y energías renovables desarrollada por el Tecnólogo Miguel Peñafiel fundador y gestor de diversos proyectos privados con visión social.",
    },
    {
      icon: <HeartHandshake className="h-8 w-8 sm:h-10 sm:w-10 text-purple-400 mb-3 sm:mb-4" />,
      title: "Nuestro Objetivo",
      text: "El objetivo es que los ciudadanos que en Ecuador hoy son presa de la violencia por la pobreza, delincuencia y falta de trabajo y oportunidades, tenga una opción de ingresos dignos y reunificación familiar real, porque con esta tecnología que no demanda el extenuante esfuerzo que es sembrar en tierra, porque producimos en nuestros patios con módulos de 2mtr x 2 mtr la pueden usar, niños, niñas, adolecentes, mujeres ancianos, personas con capacidades especiales.",
    },
    {
      icon: <Brain className="h-8 w-8 sm:h-10 sm:w-10 text-blue-400 mb-3 sm:mb-4" />,
      title: "Capacitación y Oportunidad",
      text: "La empresa capacita a los integrantes de la COMUNIDAD ASO, una vez aprobada la capacitación en todas las áreas de producción de la comunidad, se entrega en comodato uno o más módulos, según sea el caso, los integrantes producir diversos productos acorde a los mercados a los que las COMUNIDAD ASO venda o exporte, nacionales o internacionales.",
    },
    {
      icon: <TrendingUp className="h-8 w-8 sm:h-10 sm:w-10 text-green-400 mb-3 sm:mb-4" />,
      title: "Impacto Económico",
      text: "La producción mínima que cada módulo produce a cada hogar son $1.000 dólares mensuales, pudiendo llegar a $2500 dólares según su capacidad de producción.",
    },
    {
      icon: <Globe className="h-8 w-8 sm:h-10 sm:w-10 text-gold-aso mb-3 sm:mb-4" />,
      title: "Visión Financiera Global",
      text: "Somos una COMUNIDAD AGRICOLA que tenemos un plan de negocios adaptado a las realidades financieras actuales, con una CRIPTOMONEDA para generar un futuro financiero para todos, el valor de la cripto ASO es y será de $500 dólares cada unidad, porque su valor no es por la especulación es por la producción de los integrantes que se suma al uso financiero fuera del mercado bancario del Ecuador que por historia a abusado y sumido en pobreza al país.",
    },
    {
      icon: <Home className="h-8 w-8 sm:h-10 sm:w-10 text-purple-400 mb-3 sm:mb-4" />,
      title: "Tú Eres la Comunidad",
      text: "La COMUNIDAD ASO eres tú, tus padres tus hijos que salen del colegio o de la universidad y no consiguen un trabajo digno y envejecen viendo que su esfuerzo nunca fue valorado.",
    },
    {
      icon: <Eye className="h-8 w-8 sm:h-10 sm:w-10 text-blue-400 mb-3 sm:mb-4" />,
      title: "La Verdadera Oportunidad",
      text: "La pobreza no es falta de talento ni vagancia... es falta de oportunidades. COMUNIDAD ASO es la oportunidad que tú y tu familia esperaba.",
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-gray-200 py-20 sm:py-24 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="container mx-auto max-w-4xl"
      >
        <header className="text-center mb-12 sm:mb-16">
          <img src={logoUrl} alt="COMUNIDAD ASO Logo" className="h-16 w-16 sm:h-20 sm:w-20 mx-auto mb-4 sm:mb-6 rounded-full shadow-lg border-2 border-gold-aso" />
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-3 sm:mb-4">
            <span className="gradient-text-gold">Sobre COMUNIDAD ASO</span>
          </h1>
          <p className="text-lg sm:text-xl text-purple-300 text-justify">
            Transformando vidas a través de la agricultura innovadora y la tecnología blockchain.
          </p>
        </header>

        <section className="my-12 sm:my-16">
          <motion.div
            initial={{ opacity: 0, y:20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-6 sm:mb-8"
          >
            <h2 className="text-3xl sm:text-4xl font-semibold text-white mb-2 inline-flex items-center">
              <Youtube className="h-8 w-8 sm:h-10 sm:w-10 text-red-500 mr-3" />
              Nuestro Manifiesto
            </h2>
            <p className="text-md sm:text-lg text-purple-300 text-justify">Conoce el corazón y la visión de nuestra comunidad.</p>
          </motion.div>
          
          {isLoadingVideo ? (
             <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center">
                <Loader2 className="h-10 w-10 animate-spin text-purple-400" />
            </div>
          ) : manifestoVideoSrc ? (
            <ManifestoVideo videoSrc={manifestoVideoSrc} title="Manifiesto de la Comunidad ASO" />
          ) : (
            <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center text-slate-400">
                <p>Video no disponible en este momento.</p>
            </div>
          )}
        </section>

        <div className="space-y-8 sm:space-y-12">
          {contentSections.map((section, index) => (
            <motion.section
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.7, delay: index * 0.1 }}
              className="p-6 sm:p-8 rounded-lg sm:rounded-xl glass-effect-light shadow-xl hover:shadow-purple-500/30 transition-shadow duration-300"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center">
                <div className="flex-shrink-0 mb-3 sm:mb-0 sm:mr-4 md:mr-6">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-semibold text-white mb-2 sm:mb-3">{section.title}</h2>
                  <p className="text-base sm:text-lg leading-relaxed text-gray-300 whitespace-pre-line text-justify">
                    {section.text}
                  </p>
                </div>
              </div>
            </motion.section>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.7, delay: contentSections.length * 0.1 }}
          className="mt-16 sm:mt-20 text-center"
        >
          <p className="text-xl sm:text-2xl font-semibold text-gold-aso italic text-justify">
            "La agricultura es nuestra raíz, la tecnología nuestra herramienta, la comunidad nuestra fuerza."
          </p>
          <p className="text-md sm:text-lg text-purple-300 mt-1.5 sm:mt-2 text-justify">- Tecnólogo Miguel Peñafiel, Fundador</p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default AboutPage;