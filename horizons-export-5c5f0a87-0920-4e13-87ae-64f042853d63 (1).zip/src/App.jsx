import React from 'react';
import { Routes, Route, useLocation, Outlet } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import PriceTable from '@/components/PriceTable';
import MiningInfoSection from '@/components/Mining'; 
import Testimonials from '@/components/Testimonials';
import Footer from '@/components/Footer';
import AdminPanel from '@/pages/AdminPanel.jsx'; 
import AboutPage from '@/pages/AboutPage.jsx';
import MyAssetsPage from '@/pages/MyAssetsPage.jsx';
import MiningPage from '@/pages/MiningPage.jsx'; 
import ShopPage from '@/pages/ShopPage.jsx';
import NotFound from '@/pages/NotFound.jsx';
import LedgerPage from '@/pages/admin/LedgerPage.jsx';

function LandingPageLayout() {
  return (
    <>
      <Header />
      <Hero />
      <Features />
      <PriceTable />
      <MiningInfoSection />
      <Testimonials />
      <Footer />
    </>
  );
}

function PageWithHeaderAndFooterLayout() {
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  );
}


function App() {
  return (
    <div className="min-h-screen bg-background">
      <Routes>
        <Route path="/" element={<LandingPageLayout />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/admin/ledger" element={<LedgerPage />} />
        <Route element={<PageWithHeaderAndFooterLayout />}>
          <Route path="/about" element={<AboutPage />} />
          <Route path="/my-assets" element={<MyAssetsPage />} />
          <Route path="/mining" element={<MiningPage />} />
          <Route path="/shop" element={<ShopPage />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Toaster />
    </div>
  );
}

export default App;