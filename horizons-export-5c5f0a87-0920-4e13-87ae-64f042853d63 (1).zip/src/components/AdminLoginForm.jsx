import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Eye, EyeOff, LogIn, AlertTriangle, WifiOff } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';

const ADMIN_EMAIL = 'direcwork@gmail.com';
const ADMIN_DEFAULT_PASSWORD = 'Papapapa1@';

const AdminLoginForm = () => {
  const [email, setEmail] = useState(ADMIN_EMAIL);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [networkError, setNetworkError] = useState(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { loginAdmin, logout } = useAuth();


  useEffect(() => {
    setEmail(ADMIN_EMAIL);
  }, []);

  const syncAdminUserToImported = async (adminAuthUser) => {
    if (!adminAuthUser || !adminAuthUser.id || !adminAuthUser.email) {
      console.error("syncAdminUserToImported: adminAuthUser data is incomplete.");
      return;
    }

    try {
      const { error: rpcError } = await supabase.rpc('handle_user_sync_users_imported_direct', {
        p_user_id: adminAuthUser.id,
        p_email: adminAuthUser.email,
        p_raw_user_meta_data: adminAuthUser.user_metadata || { name: 'Admin Direcwork', full_name: 'Admin Direcwork' } 
      });

      if (rpcError) {
        throw rpcError;
      }
      console.log(`Admin user ${adminAuthUser.email} synced to users_imported successfully.`);
    } catch (err) {
      console.error("Error syncing admin user to users_imported:", err);
      toast({
        title: "Error de Sincronización (Admin)",
        description: "No se pudo sincronizar la cuenta de administrador con la tabla de usuarios importados. Algunas funciones podrían no operar correctamente.",
        variant: "destructive"
      });
    }
  };


  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setNetworkError(null);

    if (email !== ADMIN_EMAIL) {
      setError("El correo electrónico para el administrador no es válido.");
      setLoading(false);
      return;
    }

    try {
      const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
      });

      if (loginError) {
        if (loginError.message.toLowerCase().includes('invalid login credentials') && password === ADMIN_DEFAULT_PASSWORD) {
          
          toast({ title: "Primer Inicio de Sesión Detectado", description: "Intentando registrar cuenta de administrador..." });
          
          const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
            email: ADMIN_EMAIL,
            password: ADMIN_DEFAULT_PASSWORD,
            options: {
              data: {
                name: 'Admin Direcwork',
                full_name: 'Admin Direcwork',
                is_admin: true 
              }
            }
          });

          if (signUpError) {
             if (signUpError.message.toLowerCase().includes('user already registered')) {
                setError("La contraseña proporcionada es incorrecta. Si es tu primer inicio, usa la contraseña predeterminada. Si no, verifica tus credenciales.");
                toast({ title: "Error de Autenticación", description: "El administrador ya está registrado pero la contraseña es incorrecta.", variant: "destructive" });
            } else if (signUpError.message.toLowerCase().includes('failed to fetch')) {
                setNetworkError("Error de red al intentar registrar administrador. Verifica tu conexión.");
                throw signUpError;
            } else {
                setError(`Error al registrar administrador: ${signUpError.message}`);
                throw signUpError;
            }
          } else if (signUpData.user) {
            toast({ title: "Cuenta de Administrador Creada", description: "Iniciando sesión...", variant: "success" });
            await syncAdminUserToImported(signUpData.user); 
            
            const { data: secondLoginData, error: secondLoginError } = await supabase.auth.signInWithPassword({ email, password });
            if(secondLoginError) throw secondLoginError;

            if (secondLoginData.user) {
                loginAdmin(secondLoginData.user, secondLoginData.session);
                navigate('/admin/dashboard');
            } else {
                 setError("No se pudo iniciar sesión después de crear la cuenta de administrador.");
            }
          }
        } else if (loginError.message.toLowerCase().includes('failed to fetch')) {
            setNetworkError("Error de red al intentar iniciar sesión. Verifica tu conexión.");
            throw loginError;
        } else {
          setError(loginError.message);
          throw loginError;
        }
      } else if (loginData.user) {
        if (loginData.user.email !== ADMIN_EMAIL) {
            await supabase.auth.signOut(); 
            setError("Acceso denegado. Esta cuenta no es de administrador.");
            toast({ title: "Acceso Denegado", description: "Solo cuentas de administrador pueden acceder aquí.", variant: "destructive" });
            return;
        }
        await syncAdminUserToImported(loginData.user);
        loginAdmin(loginData.user, loginData.session);
        navigate('/admin/dashboard');
      }
    } catch (err) {
      console.error("Login/Signup error:", err);
      if (!networkError && !error) { 
          setError(err.message || "Ocurrió un error desconocido.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-md bg-slate-800/80 backdrop-blur-md border-purple-700/50 shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold gradient-text-gold">Acceso de Administrador</CardTitle>
            <CardDescription className="text-slate-400">Ingresa tus credenciales para gestionar la plataforma.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email-admin" className="text-slate-300">Correo Electrónico</Label>
                <Input
                  id="email-admin"
                  type="email"
                  value={email}
                  readOnly 
                  className="bg-slate-700/70 border-slate-600 cursor-not-allowed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password-admin" className="text-slate-300">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="password-admin"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="••••••••"
                    className="bg-slate-700/70 border-slate-600"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-slate-400 hover:text-purple-400"
                    aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </Button>
                </div>
              </div>
              
              {(error || networkError) && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="p-3 bg-red-900/40 border border-red-700/60 rounded-md text-sm text-red-300 flex items-start space-x-2"
                >
                  {networkError ? <WifiOff size={20} className="flex-shrink-0"/> : <AlertTriangle size={20} className="flex-shrink-0"/>}
                  <span>{networkError || error}</span>
                </motion.div>
              )}

              <Button type="submit" className="w-full gradient-button font-semibold py-3 text-base" disabled={loading}>
                {loading ? (
                  <LogIn size={20} className="mr-2 animate-pulse" />
                ) : (
                  <LogIn size={20} className="mr-2" />
                )}
                {loading ? 'Ingresando...' : 'Ingresar'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center">
            <p className="text-xs text-slate-500">
              Plataforma de Administración ASO. Solo personal autorizado.
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default AdminLoginForm;