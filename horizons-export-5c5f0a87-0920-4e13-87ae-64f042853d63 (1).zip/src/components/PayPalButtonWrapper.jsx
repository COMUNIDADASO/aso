import React, { useEffect, useState, useCallback } from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Loader2, WifiOff } from 'lucide-react';
import { Input } from '@/components/ui/input';

const PayPalButtonWrapper = ({ 
  amount: initialAmount, 
  description: initialDescription, 
  productId: initialProductId, 
  payPalClientId, 
  onSuccess, 
  onError,
  allowCustomAmount = false,
  customAmountLabel = "Monto a cargar (USD)"
}) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [scriptError, setScriptError] = useState(false); 
  const [currentAmount, setCurrentAmount] = useState(allowCustomAmount ? '' : initialAmount.toString());
  const [inputError, setInputError] = useState('');
  const [networkError, setNetworkError] = useState(null); 

  const uniqueKey = `${payPalClientId}-${currentAmount}-${initialDescription}-${initialProductId}-${allowCustomAmount}`;

  useEffect(() => {
    if (!allowCustomAmount) {
      setCurrentAmount(initialAmount.toString());
    }
  }, [initialAmount, allowCustomAmount]);

  const finalDescription = allowCustomAmount ? "Cargar saldo a mi wallet" : initialDescription;
  const finalProductId = allowCustomAmount ? "wallet-top-up" : initialProductId;

  const handleAmountChange = (e) => {
    const value = e.target.value;
    setInputError('');
    if (value === '' || /^\d*\.?\d{0,2}$/.test(value)) {
        if (parseFloat(value) > 10000) {
             setInputError('El monto no puede exceder $10,000.00');
             setCurrentAmount('10000');
        } else if (value.startsWith('0') && value !== '0' && !value.startsWith('0.')) {
            setCurrentAmount(value.substring(1));
        }
        else {
            setCurrentAmount(value);
        }
    }
  };

  const validateAmount = useCallback(() => {
    const numericAmount = parseFloat(currentAmount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setInputError('Por favor, ingresa un monto válido mayor a $0.00.');
      return false;
    }
    if (numericAmount > 10000) {
      setInputError('El monto no puede exceder $10,000.00.');
      return false;
    }
    setInputError('');
    return true;
  }, [currentAmount]);

  const createOrder = useCallback(async (data, actions) => {
    if (allowCustomAmount && !validateAmount()) {
      toast({
        title: 'Error de Monto',
        description: inputError || 'Por favor, ingresa un monto válido.',
        variant: 'destructive',
      });
      return Promise.reject(new Error('Monto inválido'));
    }

    setLoading(true);
    setNetworkError(null);
    try {
      const { data: functionData, error: functionError } = await supabase.functions.invoke('create-paypal-order', {
        body: JSON.stringify({ 
          amount: parseFloat(currentAmount), 
          description: finalDescription,
          productId: finalProductId
        }),
      });

      
      if (functionError) {
        if (functionError instanceof TypeError && functionError.message.toLowerCase().includes('failed to fetch')) {
          setNetworkError("Error de red al crear orden. Verifica tu conexión.");
        }
        throw functionError;
      }
      if (functionData.error) throw new Error(functionData.error);
      
      if (functionData.orderId) {
        setLoading(false);
        return functionData.orderId;
      } else {
        throw new Error('No se recibió el ID de la orden de PayPal desde la función.');
      }
    } catch (err) {
      setLoading(false);
      console.error('Error creating PayPal order via Edge Function:', err);
      if (!networkError) { 
        toast({
          title: 'Error al Crear Orden de PayPal',
          description: err.message || 'No se pudo iniciar el proceso de pago. Inténtalo de nuevo.',
          variant: 'destructive',
        });
      }
      if (onError) onError(err);
      return Promise.reject(err);
    }
  }, [currentAmount, finalDescription, finalProductId, onError, toast, allowCustomAmount, validateAmount, inputError, supabase]);

  const onApprove = useCallback(async (data, actions) => {
    setLoading(true);
    setNetworkError(null);
    try {
      const { data: captureData, error: captureError } = await supabase.functions.invoke('capture-paypal-order', {
        body: JSON.stringify({ orderID: data.orderID }),
      });
      
      if (captureError) {
        if (captureError instanceof TypeError && captureError.message.toLowerCase().includes('failed to fetch')) {
          setNetworkError("Error de red al capturar pago. Verifica tu conexión.");
        }
        throw captureError;
      }
      if (captureData.error) {
        if (captureData.details && captureData.details.issue === 'ORDER_ALREADY_CAPTURED') {
           toast({
            title: 'Advertencia de Pago',
            description: 'Esta orden ya ha sido capturada previamente.',
            variant: 'default',
            className: 'bg-yellow-500 text-black'
          });
          if (onSuccess) onSuccess(captureData, parseFloat(currentAmount)); 
          setLoading(false);
          return;
        }
        throw new Error(captureData.error);
      }
      
      toast({
        title: '¡Pago Exitoso!',
        description: `Tu pago de ${parseFloat(currentAmount).toFixed(2)} USD para "${finalDescription}" ha sido procesado. ID de Orden: ${data.orderID}`,
        variant: 'success',
      });
      if (onSuccess) onSuccess(captureData, parseFloat(currentAmount));
      if (allowCustomAmount) setCurrentAmount('');
    } catch (err) {
      console.error('Error capturing PayPal order via Edge Function:', err);
      if (!networkError) {
         toast({
          title: 'Error al Capturar Pago de PayPal',
          description: err.message || 'No se pudo completar el pago. Si el problema persiste, contacta a soporte.',
          variant: 'destructive',
        });
      }
      if (onError) onError(err);
    } finally {
      setLoading(false);
    }
  }, [onSuccess, onError, toast, finalDescription, allowCustomAmount, currentAmount, supabase]);

  const onPayPalSDKError = useCallback((err) => {
    setLoading(false);
    setScriptError(true); 
    console.error('PayPal SDK Error:', err);
    toast({
      title: 'Error de Carga de PayPal',
      description: 'No se pudo cargar el script de PayPal. Verifica tu conexión o inténtalo más tarde.',
      variant: 'destructive',
    });
    if (onError) onError(err);
  }, [onError, toast]);

  if (!payPalClientId) {
    return (
      <div className="text-center text-red-400 p-4 bg-red-900/20 rounded-md">
        PayPal Client ID no configurado. La funcionalidad de pago está deshabilitada.
      </div>
    );
  }
  
  return (
    <PayPalScriptProvider 
        key={payPalClientId} 
        options={{ 
            "client-id": payPalClientId, 
            currency: "USD", 
            intent: "capture",
            "disable-funding": "venmo,sepa,bancontact,eps,giropay,ideal,mybank,p24,sofort",
            "enable-funding": "paypal,card", 
        }}
        onError={onPayPalSDKError} 
    >
      {allowCustomAmount && (
        <div className="mb-4">
          <label htmlFor={`customAmountInput-${finalProductId}`} className="block text-sm font-medium text-gray-300 mb-1">{customAmountLabel}</label>
          <Input
            id={`customAmountInput-${finalProductId}`}
            type="text"
            inputMode="decimal"
            placeholder="Ej: 50.00"
            value={currentAmount}
            onChange={handleAmountChange}
            className={`bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500 ${inputError ? 'border-red-500 focus:border-red-500' : ''}`}
          />
          {inputError && <p className="text-red-400 text-xs mt-1">{inputError}</p>}
        </div>
      )}

      {scriptError ? ( 
         <div className="text-center text-yellow-400 p-3 bg-yellow-900/30 rounded-md">
            Error al cargar los botones de PayPal. Inténtalo de nuevo más tarde.
          </div>
      ) : networkError ? ( 
         <div className="text-center text-yellow-400 p-3 bg-yellow-900/30 rounded-md">
            <WifiOff className="inline-block mr-2 h-5 w-5"/>
            {networkError} Inténtalo de nuevo.
          </div>
      ) : (
        <div className="relative min-h-[50px]">
          {loading && (
            <div className="absolute inset-0 bg-slate-800/80 flex items-center justify-center z-20 rounded-md">
              <Loader2 className="h-8 w-8 animate-spin text-purple-300" />
            </div>
          )}
          <PayPalButtons
            key={uniqueKey} 
            style={{ layout: 'vertical', color: 'blue', shape: 'rect', label: 'pay', tagline: false, height: 40 }}
            createOrder={createOrder}
            onApprove={onApprove}
            onError={(err) => { 
              console.error('PayPalButtons onError:', err);
              setNetworkError(null); 
              toast({
                title: 'Error de PayPal',
                description: err.message || 'Ocurrió un error con los botones de PayPal. Inténtalo de nuevo.',
                variant: 'destructive',
              });
              if(onError) onError(err);
            }}
            disabled={loading || (allowCustomAmount && (!currentAmount || parseFloat(currentAmount) <= 0 || !!inputError))}
            forceReRender={[currentAmount, finalDescription, finalProductId, allowCustomAmount, payPalClientId]}
          />
        </div>
      )}
    </PayPalScriptProvider>
  );
};

export default PayPalButtonWrapper;