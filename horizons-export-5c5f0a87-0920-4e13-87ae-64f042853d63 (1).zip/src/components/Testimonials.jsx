import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "María González",
      role: "Ama de casa agricultora",
      location: "Canuto, Manabi Ecuador",
      content: "COMUNIDAD ASO ha revolucionado mi forma de comercializar mis cultivos. Ahora puedo acceder a mercados globales y obtener mejores precios.",
      rating: 5,
      avatarKey: "avatar1" 
    },
    {
      name: "Carlos Mendoza",
      role: "Inversor Cripto",
      location: "Ciudad de México, México",
      content: "La combinación de agricultura real con blockchain es genial. Mis inversiones están respaldadas por activos tangibles y la plataforma es súper fácil de usar.",
      rating: 5,
      avatarKey: "avatar2"
    },
    {
      name: "Ana Silva",
      role: "Cooperativa Agrícola",
      location: "Celica, Loja Ecuador",
      content: "Nuestra cooperativa ha aumentado sus ingresos un 40% desde que usamos COMUNIDAD ASO. La minería diaria es un beneficio adicional increíble.",
      rating: 5,
      avatarKey: "avatar3"
    }
  ];

  return (
    <section className="py-12 sm:py-20 px-4 sm:px-6 relative">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12 sm:mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
            Lo Que Dicen Nuestros <span className="gradient-text-gold">Usuarios</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto">
            Descubre cómo <span className="text-gold-aso">COMUNIDAD ASO</span> está transformando la vida de agricultores e inversores.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              viewport={{ once: true }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-effect rounded-xl sm:rounded-2xl p-6 sm:p-8 hover:glow-effect transition-all duration-300 relative flex flex-col"
            >
              <Quote className="h-6 w-6 sm:h-8 sm:w-8 text-purple-400 mb-3 sm:mb-4" />
              
              <div className="flex items-center mb-3 sm:mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-400 fill-current" />
                ))}
              </div>

              <p className="text-sm sm:text-base text-gray-300 mb-4 sm:mb-6 leading-relaxed italic flex-grow">
                "{testimonial.content}"
              </p>

              <div className="flex items-center mt-auto">
                {testimonial.avatarKey === "avatar1" && <img  alt={`Foto de perfil de ${testimonial.name}`} className="w-10 h-10 sm:w-12 sm:h-12 rounded-full mr-3 sm:mr-4 object-cover" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/ffdec05243101324bcfc7303881ca11e.jpg" />}
                {testimonial.avatarKey === "avatar2" && <img  alt={`Foto de perfil de ${testimonial.name}`} className="w-10 h-10 sm:w-12 sm:h-12 rounded-full mr-3 sm:mr-4" src="https://images.unsplash.com/photo-1623880840102-7df0a9f3545b" />}
                {testimonial.avatarKey === "avatar3" && <img  alt={`Foto de perfil de ${testimonial.name}`} className="w-10 h-10 sm:w-12 sm:h-12 rounded-full mr-3 sm:mr-4 object-cover" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/8716e94d96ab3610ec30d87f8917afca.jpg" />}
                <div>
                  <h4 className="text-base sm:text-lg text-white font-semibold">{testimonial.name}</h4>
                  <p className="text-xs sm:text-sm text-gray-400">{testimonial.role}</p>
                  <p className="text-xs text-gray-500">{testimonial.location}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-12 sm:mt-16"
        >
          <div className="glass-effect rounded-xl sm:rounded-2xl p-6 sm:p-8 max-w-2xl mx-auto">
            <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4 gradient-text-gold">Únete a Nuestra <span className="text-gold-aso">COMUNIDAD ASO</span></h3>
            <p className="text-sm sm:text-base text-gray-300 mb-4 sm:mb-6">
              Más de 50,000 usuarios ya confían en <span className="text-gold-aso">COMUNIDAD ASO</span> para sus operaciones.
            </p>
            <div className="grid grid-cols-3 gap-2 sm:gap-6 text-center">
              <div>
                <div className="text-xl sm:text-3xl font-bold gradient-text-gold">50K+</div>
                <div className="text-xs sm:text-sm text-gray-400">Usuarios</div>
              </div>
              <div>
                <div className="text-xl sm:text-3xl font-bold gradient-text-gold">$2.5M</div>
                <div className="text-xs sm:text-sm text-gray-400">Vol. Diario</div>
              </div>
              <div>
                <div className="text-xl sm:text-3xl font-bold gradient-text-gold">99.9%</div>
                <div className="text-xs sm:text-sm text-gray-400">Uptime</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;