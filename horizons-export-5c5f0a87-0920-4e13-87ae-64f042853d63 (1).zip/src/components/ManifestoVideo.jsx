import React from 'react';
import { motion } from 'framer-motion';

const getEmbedUrl = (url) => {
  if (!url || typeof url !== 'string') return null;

  let videoId;
  
  try {
    if (url.includes('youtube.com/') || url.includes('youtu.be/')) {
      if (url.includes('watch?v=')) {
        videoId = new URL(url).searchParams.get('v');
      } else if (url.includes('/shorts/')) {
        videoId = url.split('/shorts/')[1].split('?')[0];
      } else if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1].split('?')[0];
      } else if (url.includes('/embed/')) {
        return url; 
      }
      
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&loop=1&playlist=${videoId}`;
      }
    }

    if (url.includes('drive.google.com/file/d/')) {
      videoId = url.split('/d/')[1].split('/')[0];
      if (videoId) {
        return `https://drive.google.com/file/d/${videoId}/preview`;
      }
    }
  } catch (error) {
    console.error("Error parsing video URL:", error);
    return null;
  }

  return null;
};


const ManifestoVideo = ({ videoSrc, title }) => {
  const embedUrl = getEmbedUrl(videoSrc);

  if (!embedUrl) {
    return (
      <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 text-center p-4">
        <p>URL de video no válida o no soportada. Por favor, usa un enlace de YouTube o Google Drive.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.7 }}
      className="w-full max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl shadow-purple-900/40 border-2 border-purple-500/30"
    >
      <div className="relative aspect-video bg-black">
        <iframe
          src={embedUrl}
          title={title || 'Video'}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="absolute top-0 left-0 w-full h-full"
        ></iframe>
      </div>
    </motion.div>
  );
};

export default ManifestoVideo;