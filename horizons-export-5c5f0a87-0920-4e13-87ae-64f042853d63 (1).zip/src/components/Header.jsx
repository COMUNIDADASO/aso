import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Menu, X, UserCircle, DownloadCloud, Briefcase, Shovel, Settings, Users, ShoppingCart, LogOut, ChevronDown, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import AuthForm from '@/components/AuthForm';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { ThemeToggle } from '@/components/ThemeToggle';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState(null);
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png";

  useEffect(() => {
    const beforeInstallPromptHandler = (e) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', beforeInstallPromptHandler);

    return () => {
      window.removeEventListener('beforeinstallprompt', beforeInstallPromptHandler);
    };
  }, []);
  
  useEffect(() => {
    if (currentUser && isAuthModalOpen) {
      setIsAuthModalOpen(false);
    }
  }, [currentUser, isAuthModalOpen]);

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({ title: "Error al cerrar sesión", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Sesión cerrada", description: "Has cerrado sesión exitosamente." });
      navigate('/');
    }
  };

  const handleInstallClick = async () => {
    setIsInstallModalOpen(false);
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        toast({ title: "¡Gracias!", description: "COMUNIDAD ASO se está instalando." });
      } else {
        toast({ title: "Instalación cancelada", description: "Puedes instalar la app más tarde desde el menú del navegador." });
      }
      setDeferredInstallPrompt(null);
    } else {
       toast({ title: "Instalación no disponible", description: "Parece que ya has instalado la app o tu navegador no soporta esta función. También puedes añadirla a tu pantalla de inicio desde el menú del navegador." });
    }
  };

  const navLinks = [
    { name: "Conócenos", path: "/about", icon: Users, action: () => navigate("/about") },
    { name: "Tienda", path: "/shop", icon: ShoppingCart, action: () => navigate("/shop") },
    { name: "Minería", path: "/mining", icon: Shovel, action: () => navigate("/mining") },
  ];
  
  const userSpecificLinks = [
      { name: "Mis Activos", path: "/my-assets", icon: Briefcase, action: () => navigate("/my-assets") }
  ];

  const adminLink = { name: "Admin", path: "/admin", icon: Settings, action: () => navigate("/admin") };

  const commonButtonClass = "text-muted-foreground hover:text-foreground hover:bg-accent transition-colors px-3 py-2 text-sm";
  const activeLinkClass = "text-gold-aso font-semibold border-b-2 border-gold-aso";


  const renderNavLinks = (isMobile = false) => {
    let linksToRender = [...navLinks];
    if (currentUser) {
        linksToRender = [...linksToRender, ...userSpecificLinks];
    }
    if (currentUser && currentUser.email === 'direcwork@gmail.com') {
        linksToRender.push(adminLink);
    }

    return linksToRender.map((link) => (
      <Button 
        key={link.name}
        variant="ghost"
        onClick={() => { link.action(); if(isMobile) setIsMenuOpen(false); }} 
        className={`${isMobile ? 'w-full justify-start py-2.5 text-base' : commonButtonClass} ${location.pathname === link.path ? activeLinkClass : ''}`}
      >
        <link.icon className={`mr-${isMobile ? '2.5' : '1.5'} h-${isMobile ? '5' : '4'} w-${isMobile ? '5' : '4'}`} />
        {link.name}
      </Button>
    ));
  };


  return (
    <motion.header 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 w-full z-50 glass-effect"
    >
      <nav className="container mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <motion.div 
              className="flex items-center"
              whileHover={{ scale: 1.05 }}
            >
              <img src={logoUrl} alt="COMUNIDAD ASO Logo" className="h-8 w-8" />
              <span className="ml-2 text-xl sm:text-2xl font-bold text-gold-aso">COMUNIDAD ASO</span>
            </motion.div>
          </Link>

          <div className="hidden md:flex items-center space-x-1">
            {renderNavLinks(false)}
            
            {deferredInstallPrompt && (
              <Button 
                variant="outline"
                onClick={() => setIsInstallModalOpen(true)} 
                className="text-green-500 border-green-500/50 hover:text-green-400 hover:bg-green-500/10 transition-colors px-3 py-2 text-sm ml-2"
              >
                <DownloadCloud className="mr-1.5 h-4 w-4" />
                Instalar App
              </Button>
            )}
            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className={`${commonButtonClass} flex items-center`}>
                    <UserCircle className="mr-1.5 h-4 w-4" />
                    Hola, {currentUser.email.split('@')[0]}
                    <ChevronDown className="ml-1 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-card border-border text-card-foreground w-56 mr-4">
                  <DropdownMenuLabel className="text-muted-foreground">Mi Cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-border" />
                  <DropdownMenuItem onClick={() => navigate('/my-assets')} className="hover:!bg-accent focus:bg-accent cursor-pointer">
                    <LayoutDashboard className="mr-2 h-4 w-4 text-purple-400" />
                    Mi Panel (Activos)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} className="text-red-500 hover:!text-red-400 hover:!bg-destructive/20 focus:bg-destructive/20 cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    Cerrar Sesión
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Dialog open={isAuthModalOpen} onOpenChange={setIsAuthModalOpen}>
                <DialogTrigger asChild>
                  <Button variant="glow" aria-label="Iniciar Sesión" data-auth-modal-trigger="true" className="ml-2 px-3 py-2 text-sm">
                    <UserCircle className="mr-1.5 h-4 w-4" /> Iniciar Sesión
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] bg-card border-border glass-effect">
                  <DialogHeader>
                    <DialogTitle className="text-center text-2xl gradient-text-gold">
                      COMUNIDAD ASO
                    </DialogTitle>
                  </DialogHeader>
                  <AuthForm onSuccess={(user) => {
                    toast({title: `¡Bienvenido ${user.email}!`, description: "Autenticación procesada."});
                    setIsAuthModalOpen(false);
                  }} />
                </DialogContent>
              </Dialog>
            )}
            <div className="ml-2">
              <ThemeToggle />
            </div>
          </div>

          <button
            className="md:hidden text-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Cerrar menú" : "Abrir menú"}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden mt-3 pb-3 space-y-1 bg-card/90 backdrop-blur-md rounded-md p-3"
          >
            {renderNavLinks(true)}
            
            {deferredInstallPrompt && (
              <Button 
                variant="outline"
                onClick={() => { setIsInstallModalOpen(true); setIsMenuOpen(false); }} 
                className="w-full justify-start text-green-500 border-green-500/50 hover:text-green-400 hover:bg-green-500/10 transition-colors py-2.5 text-base"
              >
                <DownloadCloud className="mr-2.5 h-5 w-5" />
                Instalar App
              </Button>
            )}
            <hr className="border-border my-1.5" />
            {currentUser ? (
              <>
                <Button 
                  onClick={() => { navigate('/my-assets'); setIsMenuOpen(false);}}
                  variant="ghost"
                  className="w-full justify-start text-purple-400 hover:text-foreground hover:bg-accent py-2.5 text-base"
                >
                  <LayoutDashboard className="mr-2.5 h-5 w-5"/> Mi Panel (Activos)
                </Button>
                <Button 
                  onClick={() => {handleLogout(); setIsMenuOpen(false);}}
                  variant="outline"
                  className="w-full justify-start border-destructive/50 text-destructive hover:bg-destructive/10 py-2.5 text-base"
                >
                  <LogOut className="mr-2.5 h-5 w-5" /> Cerrar Sesión
                </Button>
              </>
            ) : (
               <div className="flex items-center gap-2">
                <Dialog open={isAuthModalOpen} onOpenChange={setIsAuthModalOpen}>
                  <DialogTrigger asChild>
                     <Button 
                      onClick={() => { setIsAuthModalOpen(true); setIsMenuOpen(false);}}
                      data-auth-modal-trigger="true"
                      variant="glow"
                      className="w-full justify-start py-2.5 text-base"
                    >
                      <UserCircle className="mr-2.5 h-5 w-5" /> Iniciar Sesión / Registro
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px] bg-card border-border glass-effect">
                     <DialogHeader>
                      <DialogTitle className="text-center text-2xl gradient-text-gold">
                        COMUNIDAD ASO
                      </DialogTitle>
                    </DialogHeader>
                    <AuthForm onSuccess={(user) => {
                      setIsAuthModalOpen(false);
                    }} />
                  </DialogContent>
                </Dialog>
                <ThemeToggle />
              </div>
            )}
          </motion.div>
        )}
      </nav>
      <Dialog open={isInstallModalOpen} onOpenChange={setIsInstallModalOpen}>
        <DialogContent className="sm:max-w-md bg-card border-border glass-effect">
          <DialogHeader>
            <DialogTitle className="gradient-text-gold">Instalar COMUNIDAD ASO</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              ¡Lleva COMUNIDAD ASO contigo! Instala la aplicación en tu dispositivo para un acceso rápido y una mejor experiencia.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <Button onClick={handleInstallClick} variant="glow" className="w-full">
              <DownloadCloud className="mr-2 h-5 w-5" /> Instalar Ahora
            </Button>
            <Button variant="outline" onClick={() => setIsInstallModalOpen(false)} className="w-full">
              Quizás más tarde
            </Button>
          </div>
           <p className="mt-4 text-xs text-muted-foreground text-center">
            Si el botón de instalación no funciona, busca la opción "Añadir a pantalla de inicio" o "Instalar aplicación" en el menú de tu navegador.
          </p>
        </DialogContent>
      </Dialog>
    </motion.header>
  );
};

export default Header;