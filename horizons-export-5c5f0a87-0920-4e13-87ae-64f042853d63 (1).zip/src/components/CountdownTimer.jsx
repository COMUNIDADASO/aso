import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shovel, TrendingUp } from 'lucide-react';

const CountdownTimer = () => {
  const calculateTimeLeft = () => {
    const now = new Date();
    const midnight = new Date(now);
    midnight.setHours(24, 0, 0, 0); 
    let difference = midnight - now;

    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    } else {
      timeLeft = { hours: 23, minutes: 59, seconds: 59 }; 
    }
    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearTimeout(timer);
  });

  const formatTime = (time) => {
    return String(time).padStart(2, '0');
  };

  const numberVariants = {
    beat: {
      scale: [1, 1.08, 1],
      transition: {
        duration: 1,
        repeat: Infinity,
        ease: "easeInOut",
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
      className="glass-effect rounded-2xl sm:rounded-3xl p-6 sm:p-8 pulse-glow text-center flex flex-col items-center justify-around shadow-2xl bg-gradient-to-br from-purple-600/30 via-indigo-600/30 to-blue-600/30 w-full mx-auto"
      style={{ minHeight: '420px' }} 
    >
      <div className="bg-purple-500/30 p-3 sm:p-4 rounded-full mb-2 inline-block shadow-lg">
        <Shovel className="h-8 w-8 sm:h-10 sm:w-10 text-yellow-400" />
      </div>
      <h2 className="text-xl sm:text-2xl font-bold text-white mb-1">
        Próxima Minería ASO
      </h2>
      <div className="text-4xl sm:text-6xl font-mono font-bold text-yellow-400 my-2 sm:my-4 tracking-wider flex items-center justify-center">
        <motion.span variants={numberVariants} animate="beat">{formatTime(timeLeft.hours)}</motion.span>
        <span className="mx-1 sm:mx-2">:</span>
        <motion.span variants={numberVariants} animate="beat">{formatTime(timeLeft.minutes)}</motion.span>
        <span className="mx-1 sm:mx-2">:</span>
        <motion.span variants={numberVariants} animate="beat">{formatTime(timeLeft.seconds)}</motion.span>
      </div>
      <p className="text-xs sm:text-sm text-purple-200 mb-2">
        Tiempo restante para tu próxima recompensa.
      </p>
      <div className="mt-2 border-t border-purple-400/30 pt-3 w-full max-w-xs">
        <p className="text-sm sm:text-base font-semibold text-yellow-300 mb-1">
          ¿TÚ YA ESTÁS MINANDO?
        </p>
        <p className="text-xs sm:text-sm text-purple-200 flex items-center justify-center">
          ¿Qué esperas para hacerlo? <TrendingUp className="ml-1.5 h-4 w-4 text-green-400" />
        </p>
      </div>
    </motion.div>
  );
};

export default CountdownTimer;