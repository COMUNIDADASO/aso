import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Loader2, AlertTriangle, WifiOff } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { getAssetConfig } from '@/config/assets';

const PriceTable = () => {
  const genericCryptoPlaceholder = "https://images.unsplash.com/photo-1627435407254-1e01816ca5e7?q=80&w=200&auto=format&fit=crop";
  
  const [cryptoData, setCryptoData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isNetworkError, setIsNetworkError] = useState(false);
  const [isRateLimitError, setIsRateLimitError] = useState(false);
  
  const initialAsoMarketCap = 153456267.89;
  const dailyAsoMarketCapIncrease = 100000;
  
  const [currentAsoMarketCap, setCurrentAsoMarketCap] = useState(initialAsoMarketCap);

  const calculateAsoMarketCap = useCallback(() => {
    const startDate = new Date('2025-06-18T00:00:00Z'); 
    const now = new Date();
    const diffTime = Math.abs(now - startDate);
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    const newMarketCap = initialAsoMarketCap + (diffDays * dailyAsoMarketCapIncrease);
    setCurrentAsoMarketCap(newMarketCap);
    return newMarketCap;
  }, [initialAsoMarketCap, dailyAsoMarketCapIncrease]);

  const getDynamicAsoData = useCallback(() => {
    const currentMarketCap = calculateAsoMarketCap();
    const AsoIconComponent = getAssetConfig('ASO').iconComponent;
    return { 
      id: 'aso',
      icon: <AsoIconComponent className="h-8 w-8 rounded-full" />,
      symbol: 'ASO', 
      name: 'COMUNIDAD ASO', 
      price: '$500.00', 
      change: '+10.25%', 
      volumeToken: '500,000,000 ASO', 
      marketCap24h: `${currentMarketCap.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 
      isPositive: true,
    };
  }, [calculateAsoMarketCap]);

  useEffect(() => {
    calculateAsoMarketCap(); 
    const marketCapIntervalId = setInterval(calculateAsoMarketCap, 60000); 
    return () => clearInterval(marketCapIntervalId);
  }, [calculateAsoMarketCap]);

  const createFallbackData = useCallback(() => {
    const BtcIconComponent = getAssetConfig('BTC').iconComponent;
    const EthIconComponent = getAssetConfig('ETH').iconComponent;
    return [
      getDynamicAsoData(),
      { 
        id: 'bitcoin-fallback',
        icon: <BtcIconComponent className="h-8 w-8 rounded-full" />, 
        symbol: 'BTC', 
        name: 'Bitcoin', 
        price: 'N/A', 
        change: 'N/A', 
        volumeToken: 'N/A', 
        marketCap24h: 'N/A', 
        isPositive: true 
      },
      { 
        id: 'ethereum-fallback',
        icon: <EthIconComponent className="h-8 w-8 rounded-full" />, 
        symbol: 'ETH', 
        name: 'Ethereum', 
        price: 'N/A', 
        change: 'N/A', 
        volumeToken: 'N/A', 
        marketCap24h: 'N/A', 
        isPositive: false 
      },
    ];
  }, [getDynamicAsoData]);

  const fetchCryptoData = useCallback(async () => {
    setLoading(true);
    setError(null);
    setIsNetworkError(false);
    setIsRateLimitError(false);
    const dynamicAsoData = getDynamicAsoData();

    try {
      const { data: functionResponse, error: functionError } = await supabase.functions.invoke('get-coinmarketcap-prices');
      
      if (functionError) {
        console.error("Supabase function invocation error:", functionError);
        let userFriendlyError = "Error al contactar el servicio de precios.";
        const errorMessageLower = functionError.message ? functionError.message.toLowerCase() : "";

        if (errorMessageLower.includes('failed to fetch')) {
          userFriendlyError = "Error de red. Verifica tu conexión a internet e inténtalo de nuevo.";
          setIsNetworkError(true);
        } else if (errorMessageLower.includes("too many requests") || errorMessageLower.includes("429") || errorMessageLower.includes("rate limit")) {
          userFriendlyError = "Se ha alcanzado el límite de solicitudes a la API de precios (CoinMarketCap). Los datos podrían no estar actualizados. Inténtalo más tarde.";
          setIsRateLimitError(true);
        } else if (functionError.message) {
          userFriendlyError = functionError.message;
        }
        throw new Error(userFriendlyError);
      }

      if (functionResponse && functionResponse.error) {
        console.error("Error from Supabase function logic:", functionResponse.error, functionResponse.details);
        let userFriendlyError = "Error interno al procesar los precios.";
        const errorDetailsLower = functionResponse.details ? String(functionResponse.details).toLowerCase() : "";
        const errorFromFunctionLower = functionResponse.error ? String(functionResponse.error).toLowerCase() : "";

        if (errorDetailsLower.includes("too many requests") || errorDetailsLower.includes("429") || errorDetailsLower.includes("rate limit") ||
            errorFromFunctionLower.includes("too many requests") || errorFromFunctionLower.includes("429") || errorFromFunctionLower.includes("rate limit")) {
          userFriendlyError = "Se ha alcanzado el límite de solicitudes a la API de precios (CoinMarketCap). Los datos podrían no estar actualizados. Inténtalo más tarde.";
          setIsRateLimitError(true);
        } else if (functionResponse.error) {
          userFriendlyError = String(functionResponse.error);
        }
        throw new Error(userFriendlyError);
      }
      
      if (!functionResponse || !Array.isArray(functionResponse)) {
        console.error("Unexpected data format received:", functionResponse);
        throw new Error("Formato de datos inesperado del servidor de precios.");
      }

      const formattedData = functionResponse.map((coin) => {
        const assetConfig = getAssetConfig(coin.symbol);
        const IconComponent = assetConfig.iconComponent;
        return {
          ...coin,
          icon: <IconComponent className="h-8 w-8 rounded-full" />
        };
      });
      
      setCryptoData([dynamicAsoData, ...formattedData]);

    } catch (err) {
      console.error("Error fetching crypto data in component:", err);
      if (err.message.includes("Error de red")) setIsNetworkError(true);
      if (err.message.includes("Rate Limit") || err.message.includes("Too Many Requests") || err.message.includes("429")) setIsRateLimitError(true);
      setError(err.message || "No se pudieron cargar los datos de precios. Mostrando datos de respaldo.");
      setCryptoData(createFallbackData());
    } finally {
      setLoading(false);
    }
  }, [getDynamicAsoData, createFallbackData]);

  useEffect(() => {
    fetchCryptoData();
    const cryptoDataIntervalId = setInterval(fetchCryptoData, 600000); // 10 minutes, matching cache
    return () => clearInterval(cryptoDataIntervalId);
  }, [fetchCryptoData]);


  return (
    <section className="py-12 sm:py-20 px-4 sm:px-6 relative">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12 sm:mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
            Precios de <span className="gradient-text-gold">Criptomonedas</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto">
            Mantente actualizado con los precios más recientes de <span className="text-gold-aso">COMUNIDAD ASO</span> y otras criptomonedas líderes.
          </p>
        </motion.div>

        {loading && (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-10 w-10 sm:h-12 sm:w-12 text-purple-400 animate-spin" />
            <p className="ml-3 sm:ml-4 text-lg sm:text-xl text-gray-300">Cargando datos...</p>
          </div>
        )}

        {!loading && error && (
          <div className="text-center my-8 sm:my-10 p-4 sm:p-6 bg-red-900/30 rounded-lg border border-red-700/50">
            <div className="flex items-center justify-center text-red-400 mb-2">
              {isRateLimitError ? <AlertTriangle className="h-6 w-6 mr-2" /> : isNetworkError ? <WifiOff className="h-6 w-6 mr-2" /> : <AlertTriangle className="h-6 w-6 mr-2" />}
              <p className="text-lg sm:text-xl font-semibold">
                {isRateLimitError ? "Límite de API Alcanzado" : isNetworkError ? "Error de Red" : "Error al Cargar Precios"}
              </p>
            </div>
            <p className="text-gray-300">{error}</p>
            <p className="text-gray-400 mt-1 sm:mt-2 text-sm sm:text-base">
              {isRateLimitError ? "Los datos de CoinMarketCap podrían no estar actualizados. Se mostrarán datos de respaldo o la última información disponible." : "Mostrando datos de respaldo o la información podría estar desactualizada."}
            </p>
          </div>
        )}

        {!loading && cryptoData.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="glass-effect rounded-xl sm:rounded-3xl overflow-hidden shadow-2xl"
          >
            <div className="overflow-x-auto">
              <table className="w-full min-w-[700px] sm:min-w-[900px]">
                <thead className="bg-gradient-to-r from-purple-600/20 to-blue-600/20">
                  <tr>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      #
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Icono
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Símbolo / Nombre
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Precio
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider hidden md:table-cell">
                      Cambio 24h
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider hidden lg:table-cell">
                      Volumen (Token)
                    </th>
                    <th className="px-3 py-3 sm:px-4 sm:py-4 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Cap. Mercado
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/50">
                  {cryptoData.map((crypto, index) => (
                    <motion.tr
                      key={crypto.id || crypto.symbol + index} 
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.05 }}
                      viewport={{ once: true }}
                      className="hover:bg-purple-500/10 transition-colors duration-200 ease-in-out"
                    >
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-400">
                        {index + 1}
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap">
                        <div className="flex items-center justify-center h-6 w-6 sm:h-8 sm:w-8">
                          {crypto.icon}
                        </div>
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap">
                        <div>
                          <div className="text-xs sm:text-sm font-semibold text-white">{crypto.symbol}</div>
                          <div className="text-xs text-gray-400 hidden sm:block">{crypto.name}</div>
                        </div>
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap text-right">
                        <div className="text-xs sm:text-sm font-medium text-white">{crypto.price}</div>
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap text-right hidden md:table-cell">
                        <div className={`flex items-center justify-end text-xs sm:text-sm font-medium ${
                          crypto.isPositive === undefined ? 'text-gray-300' : crypto.isPositive ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {crypto.isPositive === undefined ? null : crypto.isPositive ? (
                            <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 mr-0.5 sm:mr-1" />
                          ) : (
                            <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 mr-0.5 sm:mr-1" />
                          )}
                          {crypto.change}
                        </div>
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap text-right hidden lg:table-cell">
                        <div className="text-xs sm:text-sm text-gray-300">{crypto.volumeToken}</div>
                      </td>
                      <td className="px-3 py-3 sm:px-4 sm:py-4 whitespace-nowrap text-right">
                        <div className="text-xs sm:text-sm text-gray-300">{crypto.marketCap24h}</div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-3 sm:p-4 text-center text-xs text-gray-500 bg-slate-800/30">
              Los datos de precios de criptomonedas (excepto ASO) son proporcionados por CoinMarketCap y pueden tener un ligero retraso. ASO se actualiza acorde a la minería diaria y la producción en los hogares de sus integrantes.
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default PriceTable;