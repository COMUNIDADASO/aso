import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldCheck, Linkedin, Twitter, Facebook, Instagram, MapPin, Mail } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Footer = () => {
  const { toast } = useToast();
  const customToastMessage = "¡HOLA COMUNIDAD ASO se prepara para listarse en los Exchange! Pronto tendrás acceso. 🚀";
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png";

  const handleSocialClick = (platform) => {
    toast({
      title: `🚧 Enlace a ${platform} no configurado.`,
      description: customToastMessage
    });
  };

  const footerLinks = [
    { name: "Términos de Servicio", action: () => handleSocialClick("Términos de Servicio") },
    { name: "Política de Privacidad", action: () => handleSocialClick("Política de Privacidad") },
    { name: "Soporte", action: () => handleSocialClick("Soporte") },
    { name: "FAQs", action: () => handleSocialClick("FAQs") },
  ];

  const socialIcons = [
    { icon: Linkedin, name: "LinkedIn", action: () => handleSocialClick("LinkedIn") },
    { icon: Twitter, name: "Twitter", action: () => handleSocialClick("Twitter") },
    { icon: Facebook, name: "Facebook", action: () => handleSocialClick("Facebook") },
    { icon: Instagram, name: "Instagram", action: () => handleSocialClick("Instagram") },
  ];

  return (
    <motion.footer 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1, delay: 0.5 }}
      className="bg-slate-900/50 backdrop-blur-md text-gray-400 py-8 sm:py-12 border-t border-slate-700/50"
    >
      <div className="container mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-3 sm:mb-4">
              <motion.div 
                className="flex items-center"
                whileHover={{ scale: 1.05 }}
              >
                 <img src={logoUrl} alt="COMUNIDAD ASO Logo" className="h-7 w-7 sm:h-8 sm:w-8" />
                <span className="ml-2 text-lg sm:text-xl font-bold text-gold-aso">COMUNIDAD ASO</span>
              </motion.div>
            </Link>
            <p className="text-xs sm:text-sm">Transformando la agricultura con tecnología blockchain.</p>
            <Link to="/admin" className="text-xs sm:text-sm text-blue-400 hover:text-blue-300 transition-colors mt-1.5 sm:mt-2 block">
              Panel de Administración
            </Link>
          </div>

          <div className="lg:col-span-1">
            <p className="text-md sm:text-lg font-semibold text-white mb-3 sm:mb-4">Enlaces Rápidos</p>
            <ul className="space-y-1.5 sm:space-y-2">
              {footerLinks.map(link => (
                <li key={link.name}>
                  <button onClick={link.action} className="hover:text-white transition-colors text-xs sm:text-sm">
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="lg:col-span-1">
            <p className="text-md sm:text-lg font-semibold text-white mb-3 sm:mb-4">Oficinas de Correspondencia</p>
            <div className="space-y-2 text-xs sm:text-sm">
              <div className="flex items-start">
                <MapPin className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <p><span className="font-semibold text-gray-300">Miami:</span> 7801 NW 37th Street Doral, FL 33195-6503</p>
              </div>
              <div className="flex items-start">
                <MapPin className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <p><span className="font-semibold text-gray-300">Ecuador:</span> Guayaquil Av Orellana 2324 Av Causarima</p>
              </div>
              <div className="flex items-start">
                <MapPin className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <p><span className="font-semibold text-gray-300">Colombia:</span> 5B - 26, Cl. 64 Nte. #146, Menga, Cali, Valle del Cauca, Colombia</p>
              </div>
               <div className="flex items-start">
                <MapPin className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <p><span className="font-semibold text-gray-300">Chile:</span> Pdte. Juan Antonio Ríos 14, 8320000 Santiago, Región Metropolitana, Chile</p>
              </div>
               <div className="flex items-start">
                <MapPin className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <p><span className="font-semibold text-gray-300">Perú:</span> Ca. Enrique Palacios 1133, Miraflores 15074, Perú-Lima</p>
              </div>
              <div className="flex items-start">
                <Mail className="h-4 w-4 text-gold-aso mr-2 mt-0.5 flex-shrink-0" />
                <a href="mailto:administracion@comunidadaso.org" className="hover:text-white transition-colors">administracion@comunidadaso.org</a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <p className="text-md sm:text-lg font-semibold text-white mb-3 sm:mb-4">Síguenos</p>
            <div className="flex space-x-3 sm:space-x-4 mb-4">
              {socialIcons.map(social => (
                <motion.button 
                  key={social.name} 
                  onClick={social.action}
                  whileHover={{ scale: 1.2, color: "#60A5FA" }} /* blue-400 */
                  className="text-gray-400 transition-colors"
                  title={social.name}
                >
                  <social.icon className="h-5 w-5 sm:h-6 sm:w-6" />
                </motion.button>
              ))}
            </div>
            <div className="flex items-center text-xs sm:text-sm">
              <ShieldCheck className="h-4 w-4 sm:h-5 sm:w-5 text-green-400 mr-1.5 sm:mr-2" />
              <span>Transacciones Seguras</span>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-700/50 pt-6 sm:pt-8 text-center text-xs sm:text-sm">
          <p>&copy; {new Date().getFullYear()} <span className="text-gold-aso">COMUNIDAD ASO</span>. Todos los derechos reservados.</p>
          <p className="mt-1">Diseñado con pasión y tecnología de vanguardia.</p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;