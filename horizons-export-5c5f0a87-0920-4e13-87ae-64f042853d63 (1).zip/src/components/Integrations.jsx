import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MetaMaskIcon, TrustWalletIcon } from '@/config/assets.jsx';
import { useWeb3 } from '@/hooks/useWeb3';
import { AlertTriangle, CheckCircle, Loader2, LogOut, Wallet } from 'lucide-react';

const WalletCard = ({ wallet, onConnect, onDisconnect, loading, connectedAccount }) => {
  const isConnected = !!connectedAccount;
  const isMetaMask = wallet.name === 'MetaMask';
  const isMetaMaskInstalled = typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask;

  const handleConnectClick = () => {
    if (isMetaMask && !isMetaMaskInstalled) {
      window.open('https://metamask.io/download/', '_blank', 'noopener,noreferrer');
    } else {
      onConnect();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(138, 43, 226, 0.3)" }}
    >
      <Card className="bg-slate-800/60 border-slate-700/50 hover:border-purple-500/70 transition-all duration-300 rounded-xl overflow-hidden text-center flex flex-col h-full">
        <CardHeader>
          <wallet.icon className="w-16 h-16 mx-auto mb-4" />
          <CardTitle className="text-2xl font-bold text-slate-100">{wallet.name}</CardTitle>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-slate-400 min-h-[40px]">{wallet.description}</p>
        </CardContent>
        <CardFooter className="flex-col p-6">
          {isConnected ? (
            <div className="flex flex-col items-center w-full">
              <div className="flex items-center text-green-400 mb-2">
                <CheckCircle className="w-5 h-5 mr-2" />
                <span className="font-semibold">Conectado</span>
              </div>
              <p className="text-xs text-slate-300 bg-slate-700/50 px-2 py-1 rounded w-full truncate mb-4">
                {connectedAccount}
              </p>
              <Button onClick={onDisconnect} variant="destructive" className="w-full">
                <LogOut className="w-4 h-4 mr-2" /> Desconectar
              </Button>
            </div>
          ) : (
            <Button onClick={handleConnectClick} className="w-full gradient-button" disabled={loading}>
              {loading && (!isMetaMask || isMetaMaskInstalled) ? (
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Wallet className="w-5 h-5 mr-2" />
              )}
              {isMetaMask && !isMetaMaskInstalled ? 'Instalar MetaMask' : 'Conectar'}
            </Button>
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

const Integrations = () => {
  const { account, loading, error, connectWallet, disconnectWallet } = useWeb3();

  const wallets = [
    {
      name: 'MetaMask',
      description: 'Conecta tu wallet de MetaMask para interactuar con la dApp.',
      icon: MetaMaskIcon,
    },
    {
      name: 'Trust Wallet',
      description: 'Usa Trust Wallet en tu móvil para una experiencia segura.',
      icon: TrustWalletIcon,
    },
  ];

  return (
    <section id="integrations" className="py-20 sm:py-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-white">
            Conecta tu Wallet
          </h2>
          <p className="mt-4 text-lg text-slate-400 max-w-2xl mx-auto">
            Accede al ecosistema ASO conectando tu wallet Web3 preferida de forma segura.
          </p>
        </div>

        {error && !loading && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-900/30 border border-red-500/50 text-red-300 px-4 py-3 rounded-lg relative max-w-2xl mx-auto mb-8 text-center"
            role="alert"
          >
            <strong className="font-bold mr-2">¡Error!</strong>
            <span className="block sm:inline">{error}</span>
          </motion.div>
        )}
        
        {!window.ethereum && (
           <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-yellow-900/30 border border-yellow-500/50 text-yellow-300 px-4 py-3 rounded-lg relative max-w-2xl mx-auto mb-8 text-center"
            role="alert"
          >
            <AlertTriangle className="inline-block mr-2" />
            <strong className="font-bold mr-2">Atención:</strong>
            <span className="block sm:inline">No se detecta un proveedor de wallet. Por favor, instala MetaMask o usa un navegador dApp.</span>
          </motion.div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {wallets.map((wallet) => (
            <WalletCard
              key={wallet.name}
              wallet={wallet}
              onConnect={connectWallet}
              onDisconnect={disconnectWallet}
              loading={loading}
              connectedAccount={account}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Integrations;