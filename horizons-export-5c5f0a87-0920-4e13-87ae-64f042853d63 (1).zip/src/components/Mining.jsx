import React from 'react';
import { motion } from 'framer-motion';
import { Shovel as Pickaxe, Zap, Award, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const MiningInfoSection = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Pickaxe,
      title: "Minería Simplificada",
      description: "Gana ASO con un solo clic. Sin complicaciones, solo recompensas.",
      color: "text-blue-400",
    },
    {
      icon: Zap,
      title: "Recompensas Diarias",
      description: "Reclama tus ASO minados cada 24 horas y ve crecer tu portafolio.",
      color: "text-yellow-400",
    },
    {
      icon: Award,
      title: "Exclusivo para Usuarios",
      description: "La minería está disponible para todos nuestros usuarios registrados y activados.",
      color: "text-purple-400",
    },
    {
      icon: Users,
      title: "Únete a la Comunidad",
      description: "Forma parte de una comunidad creciente que construye el futuro de ASO.",
      color: "text-green-400",
    },
  ];

  return (
    <section id="mining-info" className="py-16 sm:py-24 bg-slate-900/50">
      <div className="container mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12 sm:mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
            Explora la Minería <span className="gradient-text-gold">ASO</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto">
            Descubre cómo puedes participar en la minería de tokens ASO y ser recompensado. ¡Es fácil y accesible para todos nuestros miembros!
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-effect p-6 rounded-xl shadow-lg hover:shadow-purple-500/30 transition-shadow duration-300"
            >
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 bg-gradient-to-br from-purple-600 to-blue-500`}>
                <feature.icon className={`h-6 w-6 text-white`} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-slate-100">{feature.title}</h3>
              <p className="text-gray-400 text-sm">{feature.description}</p>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Button 
            size="lg" 
            className="gradient-bg text-lg px-8 py-6 hover:opacity-90 transition-opacity"
            onClick={() => navigate('/mining')}
          >
            Ir a la Página de Minería
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default MiningInfoSection;