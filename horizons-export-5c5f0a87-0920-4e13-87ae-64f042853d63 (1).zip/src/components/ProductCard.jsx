import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, ShoppingCart, Info, DollarSign, CreditCard } from 'lucide-react';
import PayPalButtonWrapper from '@/components/PayPalButtonWrapper';
import { useToast } from '@/components/ui/use-toast';

const ProductCard = ({ product, index, payPalClientId }) => {
  const { toast } = useToast();
  
  const handlePaymentSuccess = (details, amount) => {
    toast({
      title: "¡Compra Exitosa!",
      description: `Tu compra de ${product.name} por ${amount.toFixed(2)} USD ha sido procesada. ID de Orden: ${details.id || details.orderID}`,
      variant: "success",
    });
  };

  const handlePaymentError = (error) => {
    toast({
      title: "Error en el Pago",
      description: `Ocurrió un error al procesar tu compra: ${error.message || 'Error desconocido'}`,
      variant: "destructive",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-slate-800/60 backdrop-blur-md rounded-xl shadow-2xl overflow-hidden flex flex-col h-full border border-slate-700 hover:border-purple-500/50 transition-all duration-300"
    >
      <div className="p-6 sm:p-8 flex-grow">
        <div className="flex items-center mb-4">
          <div className="p-2 bg-gradient-to-br from-purple-600 to-blue-500 rounded-lg mr-4">
            <product.icon className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white">{product.name}</h2>
        </div>
        <p className="text-gray-400 mb-5 text-sm sm:text-base">{product.shortDescription}</p>

        <ul className="space-y-2.5 mb-6 text-sm sm:text-base">
          {product.features.map((feature, i) => (
            <li key={i} className="flex items-start">
              <CheckCircle className="w-5 h-5 text-green-400 mr-2.5 mt-0.5 flex-shrink-0" />
              <span className="text-gray-300">{feature}</span>
            </li>
          ))}
        </ul>

        <div className="p-3 bg-slate-700/50 rounded-md mb-5">
          <div className="flex items-center text-yellow-300">
            <DollarSign className="w-5 h-5 mr-2" />
            <p className="font-semibold text-sm sm:text-base">{product.productionValue}</p>
          </div>
        </div>
        
        {product.note && (
          <div className="p-3 bg-blue-700/30 rounded-md mb-6">
            <div className="flex items-start text-blue-300">
              <Info className="w-5 h-5 mr-2.5 mt-0.5 flex-shrink-0" />
              <p className="text-xs sm:text-sm">{product.note}</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 sm:p-8 bg-slate-800 border-t border-slate-700 mt-auto">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
          <p className="text-3xl sm:text-4xl font-bold text-gold-aso mb-3 sm:mb-0">
            ${product.price.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
        
        {payPalClientId ? (
          <div className="space-y-3">
            <p className="text-sm text-center text-gray-300 mb-2">Pagar de forma segura con PayPal:</p>
            <PayPalButtonWrapper
              amount={product.price}
              description={`Compra de ${product.name}`}
              productId={product.id}
              payPalClientId={payPalClientId}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
              allowCustomAmount={false} 
            />
          </div>
        ) : (
          <p className="text-center text-sm text-yellow-400 p-3 bg-yellow-900/20 rounded-md">
            La opción de pago con PayPal no está configurada actualmente.
          </p>
        )}
        <p className="text-xs text-gray-500 mt-4 text-center">Los precios se muestran en USD. Pueden aplicarse impuestos.</p>
      </div>
    </motion.div>
  );
};

export default ProductCard;