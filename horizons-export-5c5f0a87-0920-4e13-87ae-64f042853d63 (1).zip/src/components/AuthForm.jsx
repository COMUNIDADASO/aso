import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { LoginFormMode, SignupFormMode, ForgotPasswordByEmailMode } from '@/components/auth/AuthFormModes';
import AuthModeToggle from '@/components/auth/AuthModeToggle';

const AuthForm = ({ onSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const { toast } = useToast();

  useEffect(() => {
    setEmail('');
    setPassword('');
    setConfirmPassword('');
  }, [authMode]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (email.toLowerCase() === 'direcwork@gmail.com') {
        toast({ title: 'Acceso de Administrador', description: 'Para iniciar sesión como administrador, por favor usa el panel de administración dedicado.', variant: 'warning', duration: 9000 });
        setIsLoading(false);
        return;
    }
    
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    setIsLoading(false);

    if (error) {
      let description = error.message;
      if (error.message.toLowerCase().includes('invalid login credentials')) {
        description = `Credenciales incorrectas para "${email}". Verifica tu email y contraseña, o usa la opción de recuperación.`;
      } else if (error.message.toLowerCase().includes('email not confirmed')) {
        description = `Tu email (${email}) aún no ha sido confirmado. Por favor, revisa tu bandeja de entrada (y spam) por el correo de confirmación.`;
      }
      toast({ title: 'Error de inicio de sesión', description: description, variant: 'destructive', duration: 9000 });
    } else if (data.user) {
      toast({ title: 'Inicio de sesión exitoso', description: `¡Bienvenido de nuevo!` });
      if (onSuccess) onSuccess(data.user);
    }
  };
  
  const handleSignUp = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({ title: 'Error de registro', description: 'Las contraseñas no coinciden.', variant: 'destructive' });
      return;
    }
    if (password.length < 8) {
      toast({ title: 'Error de registro', description: 'La contraseña debe tener al menos 8 caracteres.', variant: 'destructive' });
      return;
    }
    if (!email.includes('@')) {
      toast({ title: 'Error de registro', description: 'Por favor, proporciona un email válido.', variant: 'destructive' });
      return;
    }

    if (email.toLowerCase() === 'direcwork@gmail.com') {
        toast({ title: 'Registro de Administrador', description: 'La cuenta de administrador no puede ser creada desde este formulario.', variant: 'warning', duration: 9000 });
        return;
    }

    const rawUserData = {
      name: email.split('@')[0],
      email: email,
    };

    setIsLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: email,
      password,
      options: {
        data: { ...rawUserData, full_name: rawUserData.name }, 
        emailRedirectTo: `${window.location.origin}/my-assets`, 
      }
    });

    setIsLoading(false);
    if (error) {
      let errorTitle = 'Error de registro';
      let errorDescription = error.message;
      if (error.message.toLowerCase().includes('user already registered')) {
        errorDescription = `El email "${email}" ya está registrado. Intenta iniciar sesión o recuperar tu contraseña.`;
      } else if (error.message.toLowerCase().includes('email rate limit exceeded')) {
        errorTitle = 'Límite de registros alcanzado';
        errorDescription = 'Se ha superado el número máximo de registros por ahora. Por favor, inténtalo de nuevo en unos minutos.';
      }
      toast({ title: errorTitle, description: errorDescription, variant: 'destructive', duration: 9000 });
    } else if (data.user) {
      let successTitle = '¡Registro Exitoso!';
      let successDescription = 'Tu cuenta ha sido creada.';
      
      if (!data.session && data.user.identities && data.user.identities.length > 0 && !data.user.email_confirmed_at) {
        successTitle = '¡Registro Exitoso! Revisa tu correo';
        successDescription = `Se ha enviado un correo de confirmación a ${email}. Por favor, haz clic en el enlace para activar tu cuenta.`;
      } else if (data.session) {
         successDescription = `¡Bienvenido! Tu cuenta ha sido creada y ya has iniciado sesión.`;
      }
      
      toast({ 
        title: successTitle, 
        description: successDescription,
        duration: 9000
      });

      if (onSuccess) onSuccess(data.user); 
    } else {
       toast({ title: 'Registro pendiente', description: 'Algo inesperado ocurrió. Intenta de nuevo o revisa tu correo por un email de confirmación.' });
    }
  };

  const handlePasswordResetByEmail = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, { 
      redirectTo: `${window.location.origin}/my-assets`, 
    });
    setIsLoading(false);
    if (error) {
      toast({ title: 'Error al enviar enlace', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Enlace enviado', description: 'Revisa tu correo para restablecer tu contraseña.', duration: 7000 });
      setAuthMode('login');
    }
  };
  
  const togglePasswordVisibility = () => setShowPassword(!showPassword);

  const renderForm = () => {
    switch (authMode) {
      case 'login':
        return <LoginFormMode {...{ identifier: email, setIdentifier: setEmail, password, setPassword, showPassword, togglePasswordVisibility, handleLogin, isLoading, isEmailOnly: true }} />;
      case 'signup':
        return <SignupFormMode {...{ identifier: email, setIdentifier: setEmail, password, setPassword, confirmPassword, setConfirmPassword, showPassword, togglePasswordVisibility, handleSignUp, isLoading, isEmailOnly: true }} />;
      case 'forgotPassword':
        return <ForgotPasswordByEmailMode {...{ email, setEmail, handlePasswordResetByEmail, isLoading }} />;
      default:
        return <LoginFormMode {...{ identifier: email, setIdentifier: setEmail, password, setPassword, showPassword, togglePasswordVisibility, handleLogin, isLoading, isEmailOnly: true }} />;
    }
  };

  return (
    <div className="w-full max-w-md p-6 sm:p-8 space-y-6 bg-slate-800 rounded-xl shadow-2xl glass-effect">
      <h2 className="text-2xl sm:text-3xl font-bold text-center gradient-text">
        {authMode === 'login' && 'Iniciar Sesión'}
        {authMode === 'signup' && 'Crear Nueva Cuenta'}
        {authMode === 'forgotPassword' && 'Recuperar Contraseña'}
      </h2>
      {renderForm()}
      <div className="text-center text-sm text-gray-400 space-y-2 pt-4">
        <AuthModeToggle authMode={authMode} setAuthMode={setAuthMode} isEmailOnly={true} />
      </div>
    </div>
  );
};

export default AuthForm;