import React from 'react';
import { motion } from 'framer-motion';

const Features = () => {
  const imageUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/6d797c36a8ae3c3038d94813cc44cd03.png";

  return (
    <section className="py-12 sm:py-20 px-4 sm:px-6 relative bg-slate-900/50">
      <div className="container mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Visión Financiera <span className="gradient-text-gold">Global</span>
            </h2>
            <div className="text-base sm:text-lg text-gray-300 leading-relaxed space-y-4">
              <p className="text-justify">
                Somos una comunidad revolucionando la producción agrícola con tecnología de vanguardia. No somos solo otro proyecto: somos una alianza productiva que une a agricultores, tecnólogos y ciudadanos comprometidos con un futuro justo y sostenible.
              </p>
              <p className="text-justify">
                Hemos creado un plan de negocios realista, adaptado a las condiciones financieras actuales del Ecuador, diseñado para devolverle el poder económico al pueblo.
              </p>
              <p className="text-justify">
                Y para hacerlo posible, nace ASO, nuestra criptomoneda respaldada por producción agrícola, no por especulación. Cada unidad tendrá y mantendrá un valor estable de 500 dólares, gracias al trabajo colectivo de quienes forman parte de esta gran cadena productiva.
              </p>
              <p className="text-justify">
                ASO está fuera del control de los bancos tradicionales, esos que históricamente han excluido y empobrecido al país. Es una moneda construida sobre principios de equidad, transparencia y soberanía financiera.
              </p>
              <p className="font-semibold text-gold-aso">
                Algunos hechos clave:
              </p>
              <ul className="list-disc list-inside space-y-2 pl-2 sm:pl-4">
                <li>Solo existe una emisión única de 500 millones de ASO: ni más, ni menos.</li>
                <li>Se puede minar gratuitamente desde la web, democratizando su acceso.</li>
                <li>El límite máximo de compra es de 10 mil ASO por persona, para evitar la concentración y garantizar que todos tengan una oportunidad justa.</li>
              </ul>
              <p className="text-justify">
                No buscamos crear millonarios. Buscamos construir un Ecuador donde cada persona tenga en su billetera digital un activo real, seguro y estable, capaz de brindar comodidad, tranquilidad y bienestar a sus familias.
              </p>
              <p className="text-justify">
                Con ASO, el usuario tiene el control total de su inversión. Puede almacenarlo, usarlo o transferirlo como desee, sin intermediarios.
              </p>
              <p className="font-bold text-gold-aso text-justify">
                ASO no es solo una criptomoneda. Es una revolución productiva. Es tu futuro financiero, en tus manos.
              </p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-center items-center"
          >
            <motion.img
              src={imageUrl}
              alt="Moneda ASO con efecto de brillo y latido"
              className="w-full max-w-md"
              animate={{
                scale: [1, 1.03, 1],
                filter: [
                  "drop-shadow(0 0 8px rgba(255, 215, 0, 0.5))",
                  "drop-shadow(0 0 20px rgba(255, 215, 0, 0.8))",
                  "drop-shadow(0 0 8px rgba(255, 215, 0, 0.5))"
                ]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Features;