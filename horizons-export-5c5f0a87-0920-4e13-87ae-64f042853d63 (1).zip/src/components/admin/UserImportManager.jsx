import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, FileText, UserCheck, UserX, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient.js';

const UserImportManager = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importResults, setImportResults] = useState(null);
  const { toast } = useToast();

  const handleFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
      setImportResults(null); 
    }
  };

  const normalizeHeader = (header) => {
    return header.trim().toLowerCase()
      .replace(/\s+/g, '_') // Reemplaza espacios con guiones bajos
      .replace(/[^a-z0-9_]/gi, ''); // Elimina caracteres no alfanuméricos excepto guion bajo
  };

  const parseFileContent = async (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          let usersDataFromSheet;
          if (file.type === "application/json") {
            usersDataFromSheet = JSON.parse(event.target.result);
          } else if (file.type === "text/csv") {
            const text = event.target.result;
            const lines = text.split(/\r\n|\n/).filter(line => line.trim() !== '');
            if (lines.length < 2) reject(new Error("El archivo CSV debe tener una cabecera y al menos una fila de datos."));
            
            const rawHeaders = lines[0].split(',');
            const headers = rawHeaders.map(normalizeHeader);
            
            const emailHeaderVariants = ['email', 'correo', 'correo_electronico'];
            let emailIndex = -1;
            for (const variant of emailHeaderVariants) {
              emailIndex = headers.indexOf(variant);
              if (emailIndex !== -1) break;
            }

            if (emailIndex === -1) reject(new Error("La columna 'email' (o 'correo') es obligatoria en el CSV."));
            
            const nameHeaderVariants = ['name', 'nombre', 'full_name', 'nombre_completo'];
            let nameIndex = -1;
            for (const variant of nameHeaderVariants) {
              nameIndex = headers.indexOf(variant);
              if (nameIndex !== -1) break;
            }
            
            usersDataFromSheet = [];
            for (let i = 1; i < lines.length; i++) {
              const data = lines[i].split(',');
              const raw_user_data = {};
              headers.forEach((header, idx) => {
                raw_user_data[header] = data[idx]?.trim() || null; // Guardar como null si está vacío
              });

              const email = data[emailIndex]?.trim();
              if (!email) continue; // Omitir filas sin email

              const name = nameIndex !== -1 ? data[nameIndex]?.trim() : email.split('@')[0];
              
              usersDataFromSheet.push({
                email: email,
                name: name, // Este será el 'full_name' en options.data
                additional_data: raw_user_data // Todos los datos de la fila
              });
            }
          } else {
            reject(new Error("Tipo de archivo no soportado. Por favor, sube un archivo JSON o CSV."));
            return;
          }
          
          const usersToProcess = usersDataFromSheet.map(user => ({
            email: user.email,
            password: `Pass_${Math.random().toString(36).slice(-8)}!A1${Math.random().toString(36).slice(-2)}`,
            options: {
              data: {
                full_name: user.name, // Usado por el trigger para el campo 'name' en users_imported
                ...user.additional_data // Todos los demás campos del CSV/JSON
              },
              emailRedirectTo: `${window.location.origin}/`
            }
          }));
          resolve(usersToProcess);

        } catch (e) {
          reject(new Error(`Error parseando el archivo: ${e.message}`));
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsText(file);
    });
  };

  const handleImportUsers = useCallback(async () => {
    if (!selectedFile) {
      toast({ title: "⚠️ Archivo no seleccionado", description: "Por favor, selecciona un archivo para importar.", variant: "destructive" });
      return;
    }

    setIsProcessing(true);
    setImportResults(null);
    toast({ title: "⚙️ Importando usuarios...", description: `Procesando archivo: ${selectedFile.name}` });

    try {
      const usersToSignUp = await parseFileContent(selectedFile);

      if (!usersToSignUp || usersToSignUp.length === 0) {
        toast({ title: "ℹ️ Archivo vacío o sin datos válidos", description: "No se encontraron usuarios con email para importar." });
        setIsProcessing(false);
        return;
      }
      
      let successfulImports = 0;
      let failedImports = 0;
      const errors = [];

      for (const user of usersToSignUp) {
        try {
          const { data, error: signUpError } = await supabase.auth.signUp(user);

          if (signUpError) {
            if (signUpError.message.includes('User already registered') || signUpError.message.includes('already registered')) {
              errors.push({ email: user.email, reason: 'Ya registrado en Auth. Se omitió la creación. (Trigger podría actualizar users_imported si existe y el email coincide).' });
              // No contamos como fallo si ya existe, pero lo anotamos.
            } else {
              throw signUpError; // Otro tipo de error de signUp
            }
          } else if (data.user) {
            successfulImports++;
          } else {
            errors.push({ email: user.email, reason: 'Respuesta inesperada de Supabase Auth (sin error pero sin usuario).' });
            failedImports++;
          }
        } catch (loopError) {
          errors.push({ email: user.email, reason: loopError.message });
          failedImports++;
        }
      }

      setImportResults({
        totalProcessed: usersToSignUp.length,
        successfulCreations: successfulImports,
        failedCreations: failedImports,
        existingOrOtherIssues: errors
      });

      toast({
        title: "✅ Importación de Auth completada",
        description: `Usuarios procesados para Auth: ${usersToSignUp.length}. Nuevos creados: ${successfulImports}. Fallos en creación: ${failedImports}. (Datos en 'users_imported' se sincronizan por trigger).`
      });
      if (errors.length > 0) {
        console.warn("Detalles de errores/advertencias durante la importación:", errors);
        toast({ title: `⚠️ ${errors.length} advertencia(s)/error(es) durante la importación de Auth`, description: `Algunos usuarios ya existían o tuvieron otros problemas. Revisa la consola para detalles.`, variant: 'default', duration: 9000 });
      }

    } catch (error) {
      console.error("Error general durante la importación:", error);
      toast({ title: "❌ Error general de importación", description: `${error.message}`, variant: "destructive" });
      setImportResults({ error: error.message });
    } finally {
      setIsProcessing(false);
    }
  }, [selectedFile, toast]);

  return (
    <div className="flex flex-col items-center space-y-4 p-4 bg-slate-800 rounded-lg shadow-xl">
      <h3 className="text-xl font-semibold text-gold-aso mb-2">Importar Usuarios Masivamente</h3>
      <label htmlFor="file-upload" className="cursor-pointer w-full max-w-lg">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-purple-400/50 rounded-lg hover:bg-purple-500/10 transition-colors"
        >
          <UploadCloud className="h-12 w-12 text-purple-400 mb-2" />
          <span className="text-purple-300 font-medium">
            {selectedFile ? selectedFile.name : "Selecciona un archivo (CSV o JSON)"}
          </span>
          <span className="text-xs text-gray-500 mt-1">
            {selectedFile ? `Tamaño: ${(selectedFile.size / 1024).toFixed(2)} KB` : "Arrastra y suelta o haz clic"}
          </span>
        </motion.div>
        <Input 
          id="file-upload" 
          type="file" 
          className="hidden" 
          onChange={handleFileChange}
          accept=".csv,.json" 
        />
      </label>
      
      <Button 
        onClick={handleImportUsers} 
        disabled={!selectedFile || isProcessing}
        className="gradient-button w-full max-w-lg"
      >
        {isProcessing ? (
          <>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-5 h-5 border-2 border-t-transparent border-white rounded-full mr-2"
            />
            Procesando...
          </>
        ) : (
          "Importar y Crear Cuentas de Usuario"
        )}
      </Button>
      <div className="text-xs text-gray-400 text-left max-w-lg space-y-1 p-3 bg-slate-700/30 rounded-md">
        <p className="font-semibold">Instrucciones:</p>
        <p>• El archivo debe ser CSV o JSON.</p>
        <p>• **Obligatorio**: Una columna llamada 'email' (o 'correo', 'correo_electronico').</p>
        <p>• **Opcional**: Una columna 'name' (o 'nombre', 'full_name', 'nombre_completo') para el nombre del usuario.</p>
        <p>• Todas las demás columnas (Ej: Edad, Cedula, Telefono, etc.) se guardarán como datos adicionales.</p>
        <p>• Se crearán cuentas en Supabase Auth. Se enviará un correo de confirmación a cada nuevo usuario.</p>
        <p>• Los datos adicionales se sincronizarán con la tabla `users_imported` (columna `raw_data`).</p>
      </div>

      {importResults && (
        <motion.div 
          initial={{ opacity: 0, y:10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 p-4 bg-slate-700/50 rounded-lg w-full max-w-lg text-sm"
        >
          <h4 className="font-semibold text-lg mb-2 text-gold-aso">Resultados de la Importación:</h4>
          {importResults.error ? (
            <p className="text-red-400 flex items-center"><AlertTriangle className="h-4 w-4 mr-1"/> Error general: {importResults.error}</p>
          ) : (
            <>
              <p>Total de usuarios en archivo procesados: <span className="font-bold">{importResults.totalProcessed}</span></p>
              <p className="text-green-400 flex items-center"><UserCheck className="h-4 w-4 mr-1"/> Nuevas cuentas creadas en Auth: <span className="font-bold">{importResults.successfulCreations}</span></p>
              <p className="text-red-400 flex items-center"><UserX className="h-4 w-4 mr-1"/> Fallos en creación de nuevas cuentas: <span className="font-bold">{importResults.failedCreations}</span></p>
              {importResults.existingOrOtherIssues && importResults.existingOrOtherIssues.length > 0 && (
                <div className="mt-2">
                  <p className="font-semibold text-yellow-400">Advertencias / Usuarios ya existentes / Otros problemas:</p>
                  <ul className="list-disc list-inside max-h-40 overflow-y-auto text-xs bg-slate-800/50 p-2 rounded">
                    {importResults.existingOrOtherIssues.map((err, index) => (
                      <li key={index} className="truncate" title={`${err.email}: ${err.reason}`}>{err.email}: {err.reason}</li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </motion.div>
      )}
    </div>
  );
};

export default UserImportManager;