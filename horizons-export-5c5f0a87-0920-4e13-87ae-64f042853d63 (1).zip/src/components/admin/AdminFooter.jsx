import React from 'react';

const AdminFooter = () => {
  return (
    <footer className="bg-slate-800/50 text-center p-4 mt-auto">
      <p className="text-sm text-gray-500">© {new Date().getFullYear()} <span className="text-gold-aso">COMUNIDAD ASO</span> Admin Panel</p>
    </footer>
  );
};

export default AdminFooter;