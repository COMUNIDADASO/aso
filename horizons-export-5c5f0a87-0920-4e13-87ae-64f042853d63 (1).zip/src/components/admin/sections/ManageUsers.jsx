import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient.js';
import { useToast } from '@/components/ui/use-toast';
import { UserCog, Loader2, Search, Edit3, Link2, Link2Off } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('users_imported')
        .select('id, auth_user_id, email, name, raw_data, created_at, updated_at, avatar_url')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setUsers(data);
    } catch (err) {
      toast({ title: "Error cargando usuarios", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const filteredUsers = users.filter(user =>
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.raw_data?.cedula && typeof user.raw_data.cedula === 'string' && user.raw_data.cedula.includes(searchTerm)) ||
    (user.auth_user_id && user.auth_user_id.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return <div className="text-center p-10"><Loader2 className="h-12 w-12 animate-spin text-purple-400 mx-auto" /> <p className="mt-2 text-gray-300">Cargando usuarios...</p></div>;

  return (
    <motion.div 
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="p-4 sm:p-6 bg-slate-800/70 rounded-xl shadow-2xl glass-effect"
    >
      <h3 className="text-2xl font-semibold mb-6 text-center gradient-text-gold flex items-center justify-center">
        <UserCog className="h-7 w-7 mr-3 text-blue-400" />
        Gestor de Usuarios Registrados (Tabla `users_imported`)
      </h3>
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
        <Input
          type="text"
          placeholder="Buscar por email, nombre, cédula o Auth ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
        />
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">Avatar</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Nombre</TableHead>
              <TableHead>Cédula</TableHead>
              <TableHead>Auth User ID</TableHead>
              <TableHead>Registrado</TableHead>
              <TableHead className="text-center">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length > 0 ? filteredUsers.map(user => (
              <TableRow key={user.id}>
                <TableCell>
                  <img-replace 
                    src={user.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || user.email)}&background=random&size=32`} 
                    alt={user.name || user.email} 
                    className="h-8 w-8 rounded-full object-cover" 
                  />
                </TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.name || 'N/A'}</TableCell>
                <TableCell>{user.raw_data?.cedula || 'N/A'}</TableCell>
                <TableCell className="text-xs">
                  {user.auth_user_id ? (
                    <span className="flex items-center text-green-400">
                      <Link2 size={14} className="mr-1"/> Vinculado
                    </span>
                  ) : (
                    <span className="flex items-center text-yellow-400">
                      <Link2Off size={14} className="mr-1"/> No Vinculado
                    </span>
                  )}
                  <span className="block text-slate-500 truncate w-24" title={user.auth_user_id}>{user.auth_user_id}</span>
                </TableCell>
                <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                <TableCell className="text-center">
                  <Button variant="ghost" size="sm" onClick={() => toast({ title: "🚧 Próximamente", description: "La edición de usuarios estará disponible pronto."})}>
                    <Edit3 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            )) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-slate-400">
                    No se encontraron usuarios que coincidan con la búsqueda.
                  </TableCell>
                </TableRow>
            )}
          </TableBody>
          <TableCaption>{filteredUsers.length === 0 ? (searchTerm ? 'No se encontraron usuarios con ese criterio.' : 'No hay usuarios para mostrar.') : `Total de usuarios: ${filteredUsers.length}`}</TableCaption>
        </Table>
      </div>
    </motion.div>
  );
};

export default ManageUsers;