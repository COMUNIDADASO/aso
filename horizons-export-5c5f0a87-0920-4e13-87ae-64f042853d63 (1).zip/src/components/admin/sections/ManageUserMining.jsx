import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient.js';
import { useToast } from '@/components/ui/use-toast';
import { Zap, UserCheck, UserX, Loader2, Search, Edit, AlertCircle, CheckCircle2, XCircle, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

const ManageUserMining = () => {
  const [usersWithProfiles, setUsersWithProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingUser, setEditingUser] = useState(null);
  const [newMiningRate, setNewMiningRate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [networkError, setNetworkError] = useState(null);
  const [activatingUser, setActivatingUser] = useState(null);
  const { toast } = useToast();

  const fetchUsersWithMiningProfiles = useCallback(async () => {
    setLoading(true);
    setNetworkError(null);
    try {
      const { data: usersImported, error: usersError } = await supabase
        .from('users_imported')
        .select('id, auth_user_id, email, name, raw_data, avatar_url');

      if (usersError) {
        if (usersError.message.toLowerCase().includes('failed to fetch')) {
          setNetworkError("Error de red al cargar usuarios. Verifica tu conexión.");
        }
        throw usersError;
      }

      if (!usersImported || usersImported.length === 0) {
        setUsersWithProfiles([]);
        setLoading(false);
        return;
      }

      const userIds = usersImported.map(u => u.auth_user_id).filter(id => id);
      
      let miningProfiles = [];
      if (userIds.length > 0) {
        const { data, error: profilesError } = await supabase
          .from('user_mining_profiles')
          .select('*')
          .in('user_id', userIds);

        if (profilesError) {
          if (profilesError.message.toLowerCase().includes('failed to fetch')) {
            setNetworkError("Error de red al cargar perfiles de minería. Verifica tu conexión.");
          }
          throw profilesError;
        }
        miningProfiles = data || [];
      }

      const profilesMap = new Map(miningProfiles.map(p => [p.user_id, p]));

      const combinedData = usersImported.map(user => ({
        ...user,
        mining_profile: user.auth_user_id ? profilesMap.get(user.auth_user_id) || null : null,
      }));
      
      setUsersWithProfiles(combinedData);

    } catch (err) {
      if (!networkError) { 
        toast({ title: "Error cargando datos de minería", description: err.message, variant: "destructive" });
      }
      setUsersWithProfiles([]);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchUsersWithMiningProfiles();
  }, [fetchUsersWithMiningProfiles]);

  const handleUpdateProfile = async (userId, updates) => {
    setIsSubmitting(true);
    setNetworkError(null);
    try {
      const { data, error } = await supabase.functions.invoke('update-mining-profile', {
        body: { userId, ...updates },
      });

      if (error) {
         if (error instanceof TypeError && error.message.toLowerCase().includes('failed to fetch')) {
          setNetworkError("Error de red al actualizar perfil. Verifica tu conexión e inténtalo de nuevo.");
        }
        throw error;
      }
      if (data.error) throw new Error(data.error);

      toast({ title: "Perfil Actualizado", description: data.message || "El perfil de minería del usuario ha sido actualizado." });
      fetchUsersWithMiningProfiles(); 
      if (editingUser && editingUser.auth_user_id === userId) {
        setEditingUser(null); 
        setNewMiningRate('');
      }
    } catch (err) {
      if (!networkError) {
        toast({ title: "Error al actualizar", description: err.message, variant: "destructive" });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleActivateUserAndMining = async (userToActivate) => {
    setActivatingUser(userToActivate.id);
    setNetworkError(null);
    try {
      const { data, error } = await supabase.functions.invoke('admin-activate-user', {
        body: { userId: userToActivate.id },
      });

      if (error) {
        if (error instanceof TypeError && error.message.toLowerCase().includes('failed to fetch')) {
          setNetworkError("Error de red al activar usuario. Verifica tu conexión e inténtalo de nuevo.");
        }
        throw error;
      }
      if (data.error) throw new Error(data.error);

      toast({ title: "Usuario Activado", description: data.message || `La cuenta para ${userToActivate.email} ha sido creada y la minería activada.` });
      fetchUsersWithMiningProfiles();

    } catch (err) {
      if (!networkError) {
        toast({ title: "Error al Activar", description: err.message, variant: "destructive" });
      }
    } finally {
      setActivatingUser(null);
    }
  };

  const handleEditRate = (user) => {
    setEditingUser(user);
    setNewMiningRate(user.mining_profile?.mining_rate_aso_per_day || '0');
  };

  const submitNewRate = () => {
    if (!editingUser || !editingUser.auth_user_id) return;
    const rate = parseFloat(newMiningRate);
    if (isNaN(rate) || rate < 0) {
      toast({ title: "Tasa inválida", description: "Por favor, ingresa un número positivo para la tasa de minería.", variant: "destructive" });
      return;
    }
    handleUpdateProfile(editingUser.auth_user_id, { miningRateUpdate: rate });
  };

  const filteredUsers = usersWithProfiles.filter(user => {
    const searchTermLower = searchTerm.toLowerCase().trim();

    if (!searchTermLower) return true;

    const emailMatch = user.email?.toLowerCase().includes(searchTermLower);
    const nameMatch = user.name?.toLowerCase().includes(searchTermLower);
    const authIdMatch = user.auth_user_id?.toLowerCase().includes(searchTermLower);
    
    let cedulaMatch = false;
    if (user.raw_data?.cedula) {
      cedulaMatch = String(user.raw_data.cedula).toLowerCase().includes(searchTermLower);
    } else if (user.raw_data?.Cédula) { 
        cedulaMatch = String(user.raw_data.Cédula).toLowerCase().includes(searchTermLower);
    }

    let celularMatch = false;
    if (user.raw_data?.celular) {
      celularMatch = String(user.raw_data.celular).toLowerCase().includes(searchTermLower);
    } else if (user.raw_data?.telefono) { 
        celularMatch = String(user.raw_data.telefono).toLowerCase().includes(searchTermLower);
    } else if (user.raw_data?.Teléfono) { 
        celularMatch = String(user.raw_data.Teléfono).toLowerCase().includes(searchTermLower);
    }

    return emailMatch || nameMatch || authIdMatch || cedulaMatch || celularMatch;
  });
  
  if (loading && !networkError) return <div className="text-center p-10"><Loader2 className="h-12 w-12 animate-spin text-purple-400 mx-auto" /> <p className="mt-2 text-gray-300">Cargando perfiles de minería...</p></div>;

  return (
    <motion.div 
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="p-4 sm:p-6 bg-slate-800/70 rounded-xl shadow-2xl glass-effect"
    >
      <h3 className="text-2xl font-semibold mb-6 text-center gradient-text-gold flex items-center justify-center">
        <Zap className="h-7 w-7 mr-3 text-yellow-400" />
        Gestión de Minería de Usuarios
      </h3>
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
        <Input
          type="text"
          placeholder="Buscar por Email, Nombre, Cédula, Celular o Auth ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
        />
      </div>

      {networkError && (
        <div className="mb-4 p-3 bg-yellow-900/30 border border-yellow-700/50 rounded-lg text-center text-yellow-300">
          <WifiOff className="inline-block mr-2 h-5 w-5" />
          {networkError}
          <Button variant="link" onClick={fetchUsersWithMiningProfiles} className="text-purple-300 ml-2">Reintentar</Button>
        </div>
      )}

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">Avatar</TableHead>
              <TableHead>Usuario (Email/Nombre)</TableHead>
              <TableHead className="text-center">Minería Activa</TableHead>
              <TableHead className="text-center">Capacitado</TableHead>
              <TableHead>Tasa ASO/día</TableHead>
              <TableHead>Última Reclamación</TableHead>
              <TableHead className="text-center">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!loading && filteredUsers.length > 0 ? filteredUsers.map(user => {
              const profile = user.mining_profile;
              const isRegistered = !!user.auth_user_id;
              return (
                <TableRow key={user.id}>
                  <TableCell>
                    <img-replace 
                      src={user.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || user.email)}&background=random&size=32`} 
                      alt={user.name || user.email} 
                      className="h-8 w-8 rounded-full object-cover" 
                    />
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{user.name || 'N/A'}</div>
                    <div className="text-xs text-gray-400">{user.email}</div>
                    <div className="text-xs text-slate-500">Cédula: {user.raw_data?.cedula || user.raw_data?.Cédula || 'N/A'}</div>
                    <div className="text-xs text-slate-500">Cel: {user.raw_data?.celular || user.raw_data?.telefono || user.raw_data?.Teléfono || 'N/A'}</div>
                    {!isRegistered && (
                        <span className="text-xs text-orange-400 flex items-center mt-1">
                            <UserX size={14} className="mr-1"/> No Registrado
                        </span>
                    )}
                    {isRegistered && !profile && (
                        <span className="text-xs text-yellow-400 flex items-center mt-1">
                            <AlertCircle size={14} className="mr-1"/> Perfil no creado. Se creará con la primera acción.
                        </span> 
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {isRegistered && profile ? (
                      <Switch
                        checked={profile.is_mining_active}
                        onCheckedChange={(checked) => handleUpdateProfile(user.auth_user_id, { isMiningActiveUpdate: checked })}
                        disabled={isSubmitting}
                        className="data-[state=checked]:bg-green-500 data-[state=unchecked]:bg-red-500"
                      />
                    ) : <XCircle className="mx-auto text-slate-500" size={20}/>}
                  </TableCell>
                  <TableCell className="text-center">
                    {isRegistered && profile ? (
                      <Switch
                        checked={profile.is_capacitado}
                        onCheckedChange={(checked) => handleUpdateProfile(user.auth_user_id, { isCapacitadoUpdate: checked })}
                        disabled={isSubmitting}
                        className="data-[state=checked]:bg-blue-500 data-[state=unchecked]:bg-slate-600"
                      />
                    ) : <XCircle className="mx-auto text-slate-500" size={20}/>}
                  </TableCell>
                  <TableCell>
                    {isRegistered && profile ? parseFloat(profile.mining_rate_aso_per_day).toFixed(7) : 'N/A'}
                  </TableCell>
                  <TableCell>
                    {isRegistered && profile && profile.last_claimed_at ? new Date(profile.last_claimed_at).toLocaleString() : 'Nunca'}
                  </TableCell>
                  <TableCell className="text-center">
                    {!isRegistered ? (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleActivateUserAndMining(user)} 
                        disabled={activatingUser === user.id}
                        className="border-green-500 text-green-500 hover:bg-green-500/10 hover:text-green-400"
                      >
                        {activatingUser === user.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
                        <span className="ml-2">Activar Cuenta</span>
                      </Button>
                    ) : profile ? (
                      <Button variant="ghost" size="sm" onClick={() => handleEditRate(user)} disabled={isSubmitting}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button variant="ghost" size="sm" onClick={() => handleUpdateProfile(user.auth_user_id, { isMiningActiveUpdate: true, isCapacitadoUpdate: false })} title="Crear perfil y activar minería" disabled={isSubmitting}>
                        <CheckCircle2 className="h-4 w-4 text-green-400"/>
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              )
            }) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-400 py-8">
                  {loading ? <Loader2 className="h-8 w-8 animate-spin text-purple-400 mx-auto" /> : 
                   networkError ? 'Error de red. Intenta recargar.' : 
                   usersWithProfiles.length === 0 && !searchTerm ? "No hay usuarios importados para mostrar." : "No se encontraron usuarios."}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
          <TableCaption>
            {!loading && !networkError && (filteredUsers.length === 0 ? (searchTerm ? 'No se encontraron usuarios con ese criterio.' : 'No hay usuarios importados para mostrar.') : `Total de usuarios mostrados: ${filteredUsers.length}`)}
          </TableCaption>
        </Table>
      </div>

      {editingUser && editingUser.mining_profile && (
        <Dialog open={!!editingUser} onOpenChange={() => { setEditingUser(null); setNewMiningRate(''); }}>
          <DialogContent className="bg-slate-800 border-slate-700 text-white">
            <DialogHeader>
              <DialogTitle>Editar Tasa de Minería para {editingUser.name || editingUser.email}</DialogTitle>
              <DialogDescription>
                Usuario ID (Auth): {editingUser.auth_user_id} <br/>
                Tasa actual: {parseFloat(editingUser.mining_profile.mining_rate_aso_per_day).toFixed(7)} ASO/día
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="mining-rate" className="text-right col-span-1">Nueva Tasa ASO/día:</label>
                <Input
                  id="mining-rate"
                  type="number"
                  step="0.0000001"
                  min="0"
                  value={newMiningRate}
                  onChange={(e) => setNewMiningRate(e.target.value)}
                  className="col-span-3 bg-slate-700 border-slate-600"
                />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" className="border-slate-600 hover:bg-slate-700">Cancelar</Button>
              </DialogClose>
              <Button onClick={submitNewRate} disabled={isSubmitting} className="gradient-button">
                {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : null}
                Guardar Cambios
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
};

export default ManageUserMining;