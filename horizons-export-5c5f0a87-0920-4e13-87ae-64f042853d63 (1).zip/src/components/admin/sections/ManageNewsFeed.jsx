import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { PlusCircle, Edit2, Trash2, Loader2, Rss, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';

const ManageNewsFeed = () => {
  const { toast } = useToast();
  const [newsItems, setNewsItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [currentNewsItem, setCurrentNewsItem] = useState({ id: null, title: '', url: '', description: '', image_url: '' });
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchNewsItems = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('news_feed_items')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setNewsItems(data || []);
    } catch (error) {
      toast({ title: "Error", description: "No se pudieron cargar las noticias: " + error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchNewsItems();
  }, [fetchNewsItems]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentNewsItem(prev => ({ ...prev, [name]: value }));
  };

  const resetForm = () => {
    setCurrentNewsItem({ id: null, title: '', url: '', description: '', image_url: '' });
  };

  const openModalForNew = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const openModalForEdit = (item) => {
    setCurrentNewsItem({
      id: item.id,
      title: item.title || '',
      url: item.url || '',
      description: item.description || '',
      image_url: item.image_url || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentNewsItem.url) {
      toast({ title: "Error", description: "La URL es obligatoria.", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    try {
      let result;
      const payload = {
        title: currentNewsItem.title || null,
        url: currentNewsItem.url,
        description: currentNewsItem.description || null,
        image_url: currentNewsItem.image_url || null,
      };

      if (currentNewsItem.id) {
        // Update
        result = await supabase.from('news_feed_items').update(payload).eq('id', currentNewsItem.id).select();
      } else {
        // Insert
        result = await supabase.from('news_feed_items').insert(payload).select();
      }
      
      if (result.error) throw result.error;

      toast({ title: "Éxito", description: `Noticia ${currentNewsItem.id ? 'actualizada' : 'creada'} correctamente.` });
      fetchNewsItems();
      setIsModalOpen(false);
      resetForm();
    } catch (error) {
      toast({ title: "Error", description: "No se pudo guardar la noticia: " + error.message, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (itemId) => {
    if (!window.confirm("¿Estás seguro de que quieres eliminar esta noticia?")) return;
    setIsSubmitting(true); // Use same state for general processing
    try {
      const { error } = await supabase.from('news_feed_items').delete().eq('id', itemId);
      if (error) throw error;
      toast({ title: "Éxito", description: "Noticia eliminada correctamente." });
      fetchNewsItems();
    } catch (error) {
      toast({ title: "Error", description: "No se pudo eliminar la noticia: " + error.message, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="shadow-xl glass-effect-light">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-2xl flex items-center"><Rss className="mr-3 text-purple-400"/>Gestionar Feed de Noticias</CardTitle>
            <CardDescription>Agrega, edita o elimina noticias y anuncios para los usuarios.</CardDescription>
          </div>
          <Button onClick={openModalForNew} className="gradient-button">
            <PlusCircle className="mr-2 h-5 w-5" /> Agregar Noticia
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-purple-400 mx-auto" />
            <p className="mt-2">Cargando noticias...</p>
          </div>
        ) : newsItems.length === 0 ? (
          <p className="text-center py-8 text-slate-400">No hay noticias creadas aún.</p>
        ) : (
          <div className="space-y-4">
            {newsItems.map(item => (
              <Card key={item.id} className="bg-slate-800/70 border-slate-700">
                <CardContent className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                  <div className="flex-grow mb-3 sm:mb-0">
                    <h4 className="font-semibold text-lg text-gold-aso">{item.title || "Noticia sin título"}</h4>
                    <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-sm text-purple-400 hover:underline flex items-center">
                      {item.url} <ExternalLink size={14} className="ml-1" />
                    </a>
                    {item.description && <p className="text-xs text-slate-300 mt-1 line-clamp-2">{item.description}</p>}
                     {item.image_url && <p className="text-xs text-slate-400 mt-1 flex items-center"><ImageIcon size={14} className="mr-1"/> Imagen: {item.image_url.substring(0,30)}...</p>}
                  </div>
                  <div className="flex space-x-2 shrink-0">
                    <Button variant="outline" size="sm" onClick={() => openModalForEdit(item)} className="border-blue-500 text-blue-300 hover:bg-blue-500/20">
                      <Edit2 className="mr-1 h-4 w-4" /> Editar
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(item.id)} disabled={isSubmitting}>
                      {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin"/> : <Trash2 className="mr-1 h-4 w-4" />} Eliminar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[525px] bg-slate-800 border-slate-700 text-white glass-effect">
          <DialogHeader>
            <DialogTitle className="text-xl gradient-text-gold">{currentNewsItem.id ? 'Editar Noticia' : 'Agregar Nueva Noticia'}</DialogTitle>
            <DialogDescription>
              {currentNewsItem.id ? 'Modifica los detalles de la noticia.' : 'Ingresa los detalles para la nueva noticia o anuncio.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div>
              <label htmlFor="news-url" className="block text-sm font-medium text-slate-300 mb-1">URL (Obligatorio)</label>
              <Input id="news-url" name="url" value={currentNewsItem.url} onChange={handleInputChange} placeholder="https://ejemplo.com/noticia" required className="bg-slate-700/80 border-slate-600"/>
            </div>
            <div>
              <label htmlFor="news-title" className="block text-sm font-medium text-slate-300 mb-1">Título (Opcional)</label>
              <Input id="news-title" name="title" value={currentNewsItem.title} onChange={handleInputChange} placeholder="Título atractivo para la noticia" className="bg-slate-700/80 border-slate-600"/>
            </div>
            <div>
              <label htmlFor="news-description" className="block text-sm font-medium text-slate-300 mb-1">Descripción (Opcional)</label>
              <Textarea id="news-description" name="description" value={currentNewsItem.description} onChange={handleInputChange} placeholder="Breve descripción o extracto de la noticia (se mostrará en el slider)" rows={3} className="bg-slate-700/80 border-slate-600"/>
            </div>
             <div>
              <label htmlFor="news-image_url" className="block text-sm font-medium text-slate-300 mb-1">URL de Imagen (Opcional)</label>
              <Input id="news-image_url" name="image_url" value={currentNewsItem.image_url} onChange={handleInputChange} placeholder="https://ejemplo.com/imagen.jpg" className="bg-slate-700/80 border-slate-600"/>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="secondary" className="bg-slate-600 hover:bg-slate-500">Cancelar</Button>
              </DialogClose>
              <Button type="submit" disabled={isSubmitting} className="gradient-button">
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : (currentNewsItem.id ? 'Actualizar' : 'Guardar')}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default ManageNewsFeed;