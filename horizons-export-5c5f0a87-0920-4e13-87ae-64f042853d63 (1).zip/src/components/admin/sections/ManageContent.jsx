import React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileVideo, Loader2, Save, AlertTriangle } from 'lucide-react';
import ManifestoVideo from '@/components/ManifestoVideo';

const ManageContent = () => {
    const { toast } = useToast();
    const [videoUrl, setVideoUrl] = useState('');
    const [savedVideoUrl, setSavedVideoUrl] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const fetchVideoUrl = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data, error } = await supabase
                .from('app_settings')
                .select('value')
                .eq('key', 'about_page_video_url')
                .single();

            if (error && error.code !== 'PGRST116') throw error;
            
            const url = data?.value || '';
            setVideoUrl(url);
            setSavedVideoUrl(url);

        } catch (error) {
            toast({ title: "Error", description: "No se pudo cargar la URL del video: " + error.message, variant: "destructive" });
        } finally {
            setIsLoading(false);
        }
    }, [toast]);

    useEffect(() => {
        fetchVideoUrl();
    }, [fetchVideoUrl]);

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const { data, error } = await supabase.functions.invoke('set-app-setting', {
                body: { key: 'about_page_video_url', value: videoUrl }
            });

            if (error) throw error;
            if (data.error) throw new Error(data.error);

            setSavedVideoUrl(videoUrl);
            toast({ title: "Éxito", description: "La URL del video ha sido guardada." });

        } catch (error) {
            toast({ title: "Error al guardar", description: "No se pudo guardar la URL del video: " + error.message, variant: "destructive" });
        } finally {
            setIsSaving(false);
        }
    };


    return (
        <Card className="shadow-xl glass-effect-light">
            <CardHeader>
                <CardTitle className="text-2xl flex items-center"><FileVideo className="mr-3 text-purple-400"/>Gestionar Contenido de la Página "Conócenos"</CardTitle>
                <CardDescription>Actualiza el video principal que se muestra en la página "Conócenos". Pega un enlace de YouTube o Google Drive.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    <div>
                        <label htmlFor="video-url-input" className="block text-sm font-medium text-slate-300 mb-2">URL del Video</label>
                        <div className="flex flex-col sm:flex-row gap-2">
                             <Input 
                                id="video-url-input"
                                type="text"
                                placeholder="Pega aquí la URL del video..."
                                value={videoUrl}
                                onChange={(e) => setVideoUrl(e.target.value)}
                                className="flex-grow bg-slate-700/80 border-slate-600"
                                disabled={isSaving}
                            />
                            <Button onClick={handleSave} disabled={isSaving || videoUrl === savedVideoUrl} className="gradient-button">
                                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4" />}
                                Guardar URL
                            </Button>
                        </div>
                    </div>

                    <div>
                        <h4 className="text-lg font-semibold text-gold-aso mb-4">Vista Previa</h4>
                        {isLoading ? (
                            <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center">
                                <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                            </div>
                        ) : videoUrl ? (
                            <ManifestoVideo videoSrc={videoUrl} title="Vista previa del video" />
                        ) : (
                             <div className="w-full aspect-video bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 text-center p-4">
                                <div>
                                    <AlertTriangle className="h-8 w-8 text-yellow-400 mx-auto mb-2"/>
                                    <p>No hay ninguna URL de video configurada. Pega una en el campo de arriba para ver la vista previa.</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default ManageContent;