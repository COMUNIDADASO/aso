import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Gift, Loader2, AlertTriangle, CheckCircle, WifiOff, Info, RefreshCw } from 'lucide-react';

const ADMIN_EMAIL_FOR_FUNDS = 'direcwork@gmail.com';
const TARGET_ASO_EMISSION = 500000000;

const ManageReserveFunds = () => {
  const { adminUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState(true);
  const [emissionDone, setEmissionDone] = useState(false);
  const [currentAsoBalance, setCurrentAsoBalance] = useState(null);
  const [currentUsdBalance, setCurrentUsdBalance] = useState(null);
  const [error, setError] = useState(null);
  const [isNetworkError, setIsNetworkError] = useState(false);
  const [isUserConfigError, setIsUserConfigError] = useState(false);
  const { toast } = useToast();

  const checkEmissionStatus = useCallback(async (isManualRefresh = false) => {
    if (!adminUser) {
      setError("El usuario administrador no está autenticado.");
      setIsCheckingStatus(false);
      setIsUserConfigError(true);
      return;
    }

    const adminUserId = adminUser.id;

    if (isManualRefresh) {
      toast({ title: "Refrescando estado...", description: "Volviendo a verificar los fondos del administrador." });
    }
    setIsCheckingStatus(true);
    setError(null);
    setIsNetworkError(false);
    setIsUserConfigError(false);
    
    try {
      const { data: asoWallet, error: walletError } = await supabase
        .from('user_wallets')
        .select('balance')
        .eq('user_id', adminUserId)
        .eq('asset_symbol', 'ASO')
        .maybeSingle(); 
      
      if (walletError) {
        if (walletError.message.toLowerCase().includes('failed to fetch')) {
            setIsNetworkError(true);
            throw new Error("Error de red al verificar saldo ASO. Verifica tu conexión.");
        }
        throw new Error(`Error al verificar saldo ASO: ${walletError.message}`);
      }

      const asoBalance = parseFloat(asoWallet?.balance || 0);
      setCurrentAsoBalance(asoBalance);
      
      const { data: usdWallet, error: usdWalletError } = await supabase
        .from('user_wallets')
        .select('balance')
        .eq('user_id', adminUserId)
        .eq('asset_symbol', 'USD')
        .maybeSingle(); 
      
      if (usdWalletError) {
         if (usdWalletError.message.toLowerCase().includes('failed to fetch')) {
            setIsNetworkError(true);
            throw new Error("Error de red al verificar saldo USD. Verifica tu conexión.");
         }
         throw new Error(`Error al verificar saldo USD: ${usdWalletError.message}`);
      }
      setCurrentUsdBalance(parseFloat(usdWallet?.balance || 0));

      const { data: emissionTx, error: txError } = await supabase
        .from('transactions')
        .select('id')
        .eq('user_id', adminUserId)
        .eq('type', 'emision_inicial')
        .eq('status', 'completado')
        .limit(1)
        .maybeSingle();

      if (txError) {
        if (txError.message.toLowerCase().includes('failed to fetch')) {
            setIsNetworkError(true);
            throw new Error("Error de red al verificar transacción de emisión. Verifica tu conexión.");
        }
        throw new Error(`Error al verificar transacción de emisión: ${txError.message}`);
      }

      if (emissionTx && asoBalance < TARGET_ASO_EMISSION) {
        setError("Se detectó una emisión anterior pero el saldo es incorrecto. La operación forzará la corrección del saldo.");
        setEmissionDone(false);
      } else if (emissionTx || asoBalance >= TARGET_ASO_EMISSION) {
        setEmissionDone(true);
      } else {
        setEmissionDone(false);
      }

    } catch (errCatch) {
      console.error("Error detallado verificando estado de emisión:", errCatch);
      setError(errCatch.message);
      if (!isNetworkError) {
        toast({ title: "Error de Verificación", description: errCatch.message, variant: "destructive" });
      }
    } finally {
      setIsCheckingStatus(false);
    }
  }, [toast, adminUser]);

  useEffect(() => {
    if (adminUser) {
      checkEmissionStatus();
    }
  }, [adminUser, checkEmissionStatus]);

  const handlePerformEmission = async () => {
    setIsLoading(true);
    setError(null);
    setIsNetworkError(false);
    setIsUserConfigError(false);
    toast({ title: "✨ Realizando Emisión Única de ASO...", description: "Esta operación es única y puede tardar unos momentos. Se corregirán problemas de configuración si existen." });

    try {
      const { data, error: rpcError } = await supabase.rpc('execute_admin_reserve_funds_operation');

      if (rpcError) {
        console.error("Error RPC detallado:", rpcError);
        const lowerErrorMessage = rpcError.message.toLowerCase();
        if (lowerErrorMessage.includes('failed to fetch') || lowerErrorMessage.includes('network error')) {
          setIsNetworkError(true);
          throw new Error("Error de conexión con el servidor. Por favor, verifica tu conexión e inténtalo de nuevo.");
        }
        let detailedError = `Mensaje: ${rpcError.message}`;
        if (rpcError.details) detailedError += ` | Detalles: ${rpcError.details}`;
        if (rpcError.hint) detailedError += ` | Pista: ${rpcError.hint}`;
        throw new Error(detailedError);
      }
      
      if (data && data.success) {
        setEmissionDone(true);
        await checkEmissionStatus(true);
        toast({
          title: "✅ ¡Emisión Única Realizada!",
          description: data.message,
          variant: "success",
          duration: 9000,
        });
      } else if (data && data.error) {
        console.error("Error devuelto por la función SQL:", data.error);
        throw new Error(data.error || "La función SQL reportó un error durante la emisión.");
      } else {
        console.error("Respuesta inesperada de la función SQL:", data);
        throw new Error("Respuesta inesperada del servidor durante la emisión. Revisa los logs de la función.");
      }

    } catch (errCatch) {
      console.error("Error al realizar emisión:", errCatch);
      setError(errCatch.message);
      if (!isNetworkError) {
        toast({
          title: "❌ Error en la Emisión",
          description: errCatch.message,
          variant: "destructive",
          duration: 15000,
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (isCheckingStatus && !isNetworkError) {
    return (
      <div className="p-6 bg-slate-800/70 rounded-xl shadow-2xl glass-effect max-w-2xl mx-auto text-center">
        <Loader2 className="animate-spin h-8 w-8 text-purple-400 mx-auto mb-3" />
        <p className="text-slate-300">Verificando estado de la emisión inicial...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6 bg-slate-800/70 rounded-xl shadow-2xl glass-effect max-w-2xl mx-auto"
    >
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-semibold gradient-text-gold flex items-center">
          <Gift className="h-7 w-7 mr-3 text-yellow-400" />
          Emisión Inicial de Fondos
        </h3>
        <Button variant="outline" size="sm" onClick={() => checkEmissionStatus(true)} disabled={isCheckingStatus || isLoading}>
          <RefreshCw className={`h-4 w-4 ${isCheckingStatus ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {(error || isNetworkError || isUserConfigError) && (
        <div className="mb-4 p-3 bg-red-900/30 border border-red-700/50 rounded-lg text-red-300">
          <div className="flex items-start">
            <AlertTriangle className="inline-block mr-3 h-5 w-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                {isNetworkError && "Error de Red"}
                {isUserConfigError && "Error de Configuración de Usuario"}
                {!isNetworkError && !isUserConfigError && "Error de Verificación"}
              </p>
              <p className="text-sm">{error}</p>
            </div>
          </div>
        </div>
      )}

      {emissionDone ? (
        <div className="p-6 bg-green-800/30 border border-green-600/50 rounded-lg text-center">
          <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-3" />
          <p className="text-xl font-semibold text-green-300 mb-2">La emisión única de {TARGET_ASO_EMISSION.toLocaleString()} ASO ya ha sido realizada.</p>
          <p className="text-slate-300">Esta operación es la primera y única emisión del suministro total de ASO.</p>
          {currentAsoBalance !== null && (
            <p className="text-sm text-slate-400 mt-3">Saldo ASO actual del admin: <strong className="text-yellow-300">{parseFloat(currentAsoBalance).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 8})} ASO</strong></p>
          )}
          {currentUsdBalance !== null && (
            <p className="text-sm text-slate-400">Saldo USD actual del admin: <strong className="text-yellow-300">${parseFloat(currentUsdBalance).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} USD</strong></p>
          )}
        </div>
      ) : (
        <>
          <div className="bg-slate-700/50 p-4 rounded-lg mb-6 text-sm text-slate-300 space-y-2">
            <p className="flex items-start"><Info size={28} className="text-blue-400 mr-2 shrink-0"/> <strong className="text-gold-aso">Acción Única e Irreversible:</strong> Estás a punto de realizar la primera y única emisión del suministro total de ASO.</p>
            <ul className="list-disc list-inside pl-4 space-y-1">
              <li>Se acreditarán <strong className="text-yellow-300">{TARGET_ASO_EMISSION.toLocaleString()} ASO</strong> al saldo ASO del administrador (<code className="text-xs bg-slate-600 px-1 rounded">{ADMIN_EMAIL_FOR_FUNDS}</code>).</li>
              <li>El saldo USD del administrador se <strong className="text-yellow-300">actualizará</strong> para reflejar el valor total de su ASO (1 ASO = $500 USD).</li>
            </ul>
             <p className="text-xs text-slate-500 mt-2">Saldo ASO actual del admin: <strong className="text-yellow-300">{(currentAsoBalance !== null ? parseFloat(currentAsoBalance).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 8}) : 0)} ASO</strong></p>
          </div>
          <Button
            onClick={handlePerformEmission}
            disabled={isLoading || isCheckingStatus || emissionDone || isUserConfigError}
            className="w-full gradient-button py-3 text-lg font-semibold"
          >
            {isLoading ? (
              <>
                <Loader2 className="animate-spin mr-2 h-6 w-6" />
                Realizando Emisión...
              </>
            ) : (
              "Realizar Emisión Única de 500,000,000 ASO"
            )}
          </Button>
        </>
      )}
       <div className="mt-8 text-xs text-slate-500 text-center">
        <p>Esta operación se ejecuta directamente llamando a la función SQL <code className="text-purple-400">execute_admin_reserve_funds_operation</code>.</p>
        <p>Revisa los logs de la base de datos en Supabase para más detalles en caso de errores inesperados.</p>
      </div>
    </motion.div>
  );
};

export default ManageReserveFunds;