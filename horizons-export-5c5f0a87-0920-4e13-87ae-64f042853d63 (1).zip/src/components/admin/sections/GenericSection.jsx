import React from 'react';
import { motion } from 'framer-motion';
import { Edit3 } from 'lucide-react';

const GenericSection = ({ title, message }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="p-8 glass-effect rounded-xl text-center"
    >
      <Edit3 className="h-16 w-16 text-purple-400 mx-auto mb-4" />
      <h3 className="text-2xl font-semibold mb-4 gradient-text-gold">
        {title || "Sección en Desarrollo"}
      </h3>
      <p className="text-gray-400">{message || "Esta sección estará disponible pronto."}</p>
    </motion.div>
  );
};

export default GenericSection;