import React from 'react';
import { motion } from 'framer-motion';

const AdminDashboard = ({ menuItems }) => {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
      {menuItems.map((item, index) => (
        <motion.div
          key={item.name}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          whileHover={{ y: -10, scale: 1.03, boxShadow: "0 10px 20px rgba(139, 92, 246, 0.2)" }}
          className="glass-effect rounded-xl p-6 flex flex-col items-center text-center cursor-pointer"
          onClick={item.action}
        >
          <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mb-4">
            <item.icon className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-xl font-semibold mb-2 text-white">{item.name}</h2>
          <p className="text-sm text-gray-400">Gestionar {item.name.toLowerCase()}.</p>
        </motion.div>
      ))}
    </div>
  );
};

export default AdminDashboard;