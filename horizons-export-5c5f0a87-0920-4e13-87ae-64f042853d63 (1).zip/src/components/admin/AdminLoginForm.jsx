import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const AdminLoginForm = ({ onLoginSuccess }) => {
  const [adminEmail, setAdminEmail] = useState('direcwork@gmail.com'); // Pre-fill for convenience
  const [adminPassword, setAdminPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png";
  const adminTargetEmail = 'direcwork@gmail.com';
  const adminTargetPassword = 'Papapapa1@';


  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (adminEmail !== adminTargetEmail || adminPassword !== adminTargetPassword) {
      toast({ title: 'Credenciales incorrectas', description: 'El correo o la contraseña no son válidos para el administrador.', variant: 'destructive' });
      setIsLoading(false);
      return;
    }
    
    let { data, error } = await supabase.auth.signInWithPassword({
      email: adminEmail,
      password: adminPassword,
    });

    if (error && error.message === 'Invalid login credentials') {
      toast({ title: 'Intentando registrar administrador...', description: 'Primer inicio de sesión detectado para el administrador.' });
      // Intenta registrar al administrador si el login falla por "Invalid login credentials"
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: adminEmail,
        password: adminPassword,
        options: {
          data: {
            is_admin: true // Puedes añadir metadata si quieres
          },
          // Para el admin, podríamos confirmar el correo directamente.
          // O dejar que lo haga manualmente a través del enlace si prefieres ese flujo.
           emailRedirectTo: `${window.location.origin}/admin`, // O simplemente a la home
        }
      });

      if (signUpError) {
        toast({ title: 'Error al registrar administrador', description: signUpError.message, variant: 'destructive' });
        setIsLoading(false);
        return;
      }
      
      // Si el signUp fue exitoso, intentamos loguear de nuevo o usar los datos del signUp.
      // Supabase podría loguear automáticamente después de signUp si no hay confirmación de email.
      // O si la confirmación está habilitada, el admin necesitará confirmar su email.
      // Para simplificar, asumimos que el admin puede necesitar confirmar.
      if (signUpData.user) {
        // Aquí podríamos confirmar el email del admin programáticamente si fuera necesario
        // y tuviéramos los permisos (usualmente desde un entorno de servidor).
        // Por ahora, el admin podría necesitar confirmar su email.
        // await supabase.auth.admin.updateUserById(signUpData.user.id, { email_confirm: true }); // NO USAR EN CLIENTE
        
        toast({ title: 'Administrador registrado', description: 'Por favor, revisa tu correo para confirmar la cuenta si es necesario y luego intenta iniciar sesión.' });
        // Intentamos iniciar sesión de nuevo después del registro
        const { data: signInAfterSignUpData, error: signInAfterSignUpError } = await supabase.auth.signInWithPassword({
            email: adminEmail,
            password: adminPassword,
        });
        if (signInAfterSignUpError) {
            toast({ title: 'Error de inicio de sesión post-registro', description: signInAfterSignUpError.message, variant: 'destructive' });
        } else if (signInAfterSignUpData.user) {
            onLoginSuccess(signInAfterSignUpData.user);
        }

      } else {
         toast({ title: 'Registro de Admin completado', description: 'Por favor, confirma tu correo y luego inicia sesión.' });
      }

    } else if (error) {
      toast({ title: 'Error de inicio de sesión de administrador', description: error.message, variant: 'destructive' });
    } else if (data.user && data.user.email === adminTargetEmail) {
      onLoginSuccess(data.user);
    } else {
      // Si el login fue exitoso pero no es el admin, cerramos sesión.
      await supabase.auth.signOut();
      toast({ title: 'Acceso denegado', description: 'Este panel es solo para administradores.', variant: 'destructive' });
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md p-8 space-y-6 bg-slate-800 rounded-xl shadow-2xl glass-effect"
      >
        <div className="text-center">
          <img src={logoUrl} alt="COMUNIDAD ASO Logo" className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gold-aso mb-2">Acceso de Administrador</h1>
          <p className="text-gray-400"><span className="text-gold-aso">COMUNIDAD ASO</span></p>
        </div>
        <form onSubmit={handleAdminLogin} className="space-y-6">
          <div>
            <label htmlFor="admin-email" className="block text-sm font-medium text-gray-300 mb-1">Correo Electrónico</label>
            <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  id="admin-email"
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  placeholder="admin@email.com"
                  required
                  className="pl-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
                  disabled={isLoading}
                />
            </div>
          </div>
          <div>
            <label htmlFor="admin-password" className="block text-sm font-medium text-gray-300 mb-1">Contraseña</label>
             <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                id="admin-password"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="pl-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
                disabled={isLoading}
              />
            </div>
          </div>
          <Button type="submit" className="w-full gradient-button" disabled={isLoading}>
            {isLoading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-5 h-5 border-2 border-t-transparent border-white rounded-full mr-2"
                />
                Iniciando...
              </>
            ) : (
              'Iniciar Sesión como Admin'
            )}
          </Button>
        </form>
         <p className="text-xs text-gray-500 text-center">
          Solo el administrador ('{adminTargetEmail}') puede acceder.
        </p>
      </motion.div>
    </div>
  );
};

export default AdminLoginForm;