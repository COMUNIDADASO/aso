import React from 'react';
import { Button } from '@/components/ui/button';
import { LogOut, Menu, X, Home, Users, Settings, UploadCloud, Newspaper, Gift } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const AdminHeader = ({ adminUser, onLogout, activeSection, onSetActiveSection, menuItems }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png";

  const renderNavLinks = (isMobile = false) => (
    menuItems.map(item => (
      <Button
        key={item.id}
        variant={activeSection === item.id ? "secondary" : "ghost"}
        className={`w-full justify-start text-left px-3 py-2 ${isMobile ? 'mb-1' : ''} ${activeSection === item.id ? 'bg-purple-600 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}
        onClick={() => {
          onSetActiveSection(item.id);
          if (isMobile) setIsMobileMenuOpen(false);
        }}
      >
        <item.icon className="mr-2 h-5 w-5" />
        {item.label}
      </Button>
    ))
  );


  return (
    <header className="bg-slate-800/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <img src={logoUrl} alt="COMUNIDAD ASO Logo" className="h-10 w-10 mr-3" />
            <span className="text-xl font-semibold text-gold-aso">Panel de Administrador</span>
          </div>
          
          <nav className="hidden md:flex space-x-2">
            {menuItems.map(item => (
              <Button
                key={item.id}
                variant={activeSection === item.id ? "default" : "ghost"}
                className={`${activeSection === item.id ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}
                onClick={() => onSetActiveSection(item.id)}
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.label}
              </Button>
            ))}
          </nav>

          <div className="flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="rounded-full h-10 w-10 p-0 focus:ring-2 focus:ring-purple-500">
                  <img 
                    src={adminUser?.user_metadata?.avatar_url || `https://ui-avatars.com/api/?name=${adminUser?.email?.charAt(0)}&background=random&color=fff`} 
                    alt="Admin Avatar" 
                    className="h-8 w-8 rounded-full"
                  />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-slate-800 border-slate-700 text-slate-200" align="end">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{adminUser?.user_metadata?.name || 'Admin'}</p>
                    <p className="text-xs leading-none text-slate-400">{adminUser?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-slate-700" />
                <DropdownMenuItem onClick={onLogout} className="cursor-pointer hover:!bg-red-600/50 focus:!bg-red-600/50 text-red-400 hover:!text-red-300">
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <div className="md:hidden ml-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-slate-300 hover:text-white"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
      </div>
      {isMobileMenuOpen && (
        <div className="md:hidden bg-slate-800 border-t border-slate-700 px-2 pt-2 pb-3 space-y-1 sm:px-3">
           {renderNavLinks(true)}
        </div>
      )}
    </header>
  );
};

export default AdminHeader;