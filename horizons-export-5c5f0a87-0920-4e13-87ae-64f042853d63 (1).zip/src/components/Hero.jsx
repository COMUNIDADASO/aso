import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Shield, Zap, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import AuthForm from '@/components/AuthForm'; 
import CountdownTimer from '@/components/CountdownTimer';

const Hero = () => {
  const { toast } = useToast();
  const [isAuthModalOpen, setIsAuthModalOpen] = React.useState(false);
  const customToastMessage = "¡HOLA COMUNIDAD ASO se prepara para listarse en los Exchange! Pronto tendrás acceso. 🚀";

  const handleCTAClick = () => {
    setIsAuthModalOpen(true);
  };
  
  const handleDemoClick = () => {
     toast({
      title: "🚧 Demo no disponible aún",
      description: customToastMessage
    });
  }

  return (
    <section className="pt-28 sm:pt-32 pb-16 sm:pb-20 px-4 sm:px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-blue-800/10 dark:from-blue-600/10 dark:via-purple-600/10 dark:to-blue-800/10" />
      <div className="absolute top-10 left-5 sm:top-20 sm:left-10 w-48 h-48 sm:w-72 sm:h-72 bg-purple-500/5 rounded-full blur-2xl sm:blur-3xl floating-animation" />
      <div className="absolute bottom-10 right-5 sm:bottom-20 sm:right-10 w-64 h-64 sm:w-96 sm:h-96 bg-blue-500/5 rounded-full blur-2xl sm:blur-3xl floating-animation" style={{ animationDelay: '2s' }} />

      <div className="container mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-stretch">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col justify-center" 
          >
            <motion.h1 
              className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              El futuro de la economía y las finanzas globales son la <span className="gradient-text-gold">blockchain y los alimentos</span>. El ecosistema <span className="text-gold-aso">ASO</span> los pone en tus manos.
            </motion.h1>
            
            <motion.p 
              className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              Conecta la agricultura con las criptomonedas. Intercambia, mina y gestiona tus activos digitales respaldados por la producción agrícola real con <span className="text-gold-aso">COMUNIDAD ASO</span>.
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-8 sm:mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <Button 
                onClick={handleCTAClick}
                size="lg" 
                variant="glow"
                className="group text-sm sm:text-base px-4 py-2 sm:px-6 sm:py-3"
              >
                Comenzar Ahora
                <ArrowRight className="ml-1.5 sm:ml-2 h-4 w-4 sm:h-5 sm:w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                onClick={handleDemoClick}
                variant="outline" 
                size="lg"
                className="border-purple-500/50 text-purple-500 dark:text-purple-300 hover:bg-purple-500/10 text-sm sm:text-base px-4 py-2 sm:px-6 sm:py-3"
              >
                Ver Demo
              </Button>
            </motion.div>

            <motion.div 
              className="grid grid-cols-3 gap-4 sm:gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
            >
              <div className="text-center">
                <Shield className="h-6 w-6 sm:h-8 sm:w-8 text-green-400 mx-auto mb-1 sm:mb-2" />
                <p className="text-xs sm:text-sm text-muted-foreground">100% Seguro</p>
              </div>
              <div className="text-center">
                <Zap className="h-6 w-6 sm:h-8 sm:w-8 text-yellow-400 mx-auto mb-1 sm:mb-2" />
                <p className="text-xs sm:text-sm text-muted-foreground">Operaciones Rápidas</p>
              </div>
              <div className="text-center">
                <Globe className="h-6 w-6 sm:h-8 sm:w-8 text-blue-400 mx-auto mb-1 sm:mb-2" />
                <p className="text-xs sm:text-sm text-muted-foreground">Global</p>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative mt-8 lg:mt-0 flex items-start justify-center lg:-mt-6" 
          >
            <CountdownTimer />
          </motion.div>
        </div>
      </div>
      <Dialog open={isAuthModalOpen} onOpenChange={setIsAuthModalOpen}>
        <DialogContent className="sm:max-w-[425px] bg-card border-border glass-effect">
          <DialogHeader>
            <DialogTitle className="text-center text-xl sm:text-2xl gradient-text-gold">
              Bienvenido a <span className="text-gold-aso">COMUNIDAD ASO</span>
            </DialogTitle>
          </DialogHeader>
          <AuthForm onSuccess={() => setIsAuthModalOpen(false)} />
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Hero;