import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Users } from 'lucide-react';

    const CommunityButton = () => {
        const linktreeUrl = "https://linktr.ee/comunidadaso";

        return (
            <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 1 }}
                className="fixed bottom-6 right-6 z-50"
            >
                <a href={linktreeUrl} target="_blank" rel="noopener noreferrer">
                    <Button
                        size="lg"
                        className="bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-full shadow-lg transform hover:scale-110 transition-transform duration-300"
                    >
                        <Users className="mr-2 h-5 w-5" />
                        Únete a la Comunidad
                    </Button>
                </a>
            </motion.div>
        );
    };

    export default CommunityButton;