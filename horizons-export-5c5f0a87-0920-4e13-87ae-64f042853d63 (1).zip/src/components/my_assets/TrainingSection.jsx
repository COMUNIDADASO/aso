import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/supabaseClient';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { BookOpen, AlertTriangle, Loader2 } from 'lucide-react';
    import BookingModal from './BookingModal';

    const TrainingSection = ({ usdBalance, loadingBalances, userId, onBookingSuccess }) => {
        const [trainings, setTrainings] = useState([]);
        const [loadingTrainings, setLoadingTrainings] = useState(true);
        const [error, setError] = useState(null);
        const [selectedTraining, setSelectedTraining] = useState(null);
        const [isModalOpen, setIsModalOpen] = useState(false);

        useEffect(() => {
            const fetchTrainings = async () => {
                setLoadingTrainings(true);
                try {
                    const { data, error } = await supabase.from('trainings').select('*');
                    if (error) throw error;
                    setTrainings(data);
                } catch (err) {
                    setError('No se pudieron cargar las capacitaciones.');
                    console.error(err);
                } finally {
                    setLoadingTrainings(false);
                }
            };
            fetchTrainings();
        }, []);

        const handleReserveClick = (training) => {
            setSelectedTraining(training);
            setIsModalOpen(true);
        };

        const canAfford = usdBalance >= 5;

        if (loadingTrainings || loadingBalances) {
            return (
                <div className="mt-12 text-center">
                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-purple-400" />
                    <p className="text-slate-400 mt-2">Cargando capacitaciones...</p>
                </div>
            );
        }

        return (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="mt-12"
            >
                <h2 className="text-3xl sm:text-4xl font-bold mb-6 sm:mb-8 text-center gradient-text-gold">
                    Capacitaciones Disponibles
                </h2>

                {!canAfford && !loadingBalances && (
                    <div className="mb-6 p-4 bg-yellow-900/30 border border-yellow-700/50 rounded-lg text-center">
                        <AlertTriangle className="mx-auto h-8 w-8 text-yellow-400 mb-2" />
                        <p className="text-yellow-300 font-semibold">Saldo Insuficiente para Reservar</p>
                        <p className="text-slate-300 text-sm">Necesitas al menos $5.00 USD en tu wallet para reservar una capacitación.</p>
                    </div>
                )}

                {error && <p className="text-red-400 text-center">{error}</p>}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {trainings.map((training) => (
                        <Card key={training.id} className="bg-slate-800/60 border-slate-700 shadow-xl flex flex-col">
                            <CardHeader>
                                <img src={training.image_url} alt={training.title} className="rounded-t-lg h-40 w-full object-cover" />
                                <CardTitle className="mt-4 text-xl text-gold-aso">{training.title}</CardTitle>
                            </CardHeader>
                            <CardContent className="flex-grow flex flex-col">
                                <CardDescription className="text-slate-400 flex-grow">{training.description}</CardDescription>
                                <div className="mt-4 pt-4 border-t border-slate-700 flex justify-between items-center">
                                    <p className="text-lg font-bold text-green-400">${parseFloat(training.cost).toFixed(2)} USD</p>
                                    <Button
                                        onClick={() => handleReserveClick(training)}
                                        disabled={!canAfford || loadingBalances}
                                        className="bg-purple-600 hover:bg-purple-700"
                                    >
                                        <BookOpen className="mr-2 h-4 w-4" />
                                        Reservar
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {selectedTraining && (
                    <BookingModal
                        isOpen={isModalOpen}
                        setIsOpen={setIsModalOpen}
                        training={selectedTraining}
                        userId={userId}
                        onBookingSuccess={onBookingSuccess}
                    />
                )}
            </motion.div>
        );
    };

    export default TrainingSection;