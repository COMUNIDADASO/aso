import React from 'react';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Wallet, Repeat, LayoutList, CreditCard, Send, Loader2, WifiOff, Landmark } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import AssetWalletCards from '@/components/my_assets/AssetWalletCards';
    import LoadWalletSection from '@/components/my_assets/LoadWalletSection';
    import LoadWalletManual from '@/components/my_assets/LoadWalletManual';
    import TransferSection from '@/components/my_assets/TransferSection';
    import ExchangeSection from '@/components/my_assets/ExchangeSection';
    import TransactionsSection from '@/components/my_assets/TransactionsSection';

    const ManagementTabs = ({
      balances,
      transactions,
      loadingBalances,
      loadingTransactions,
      fetchAllWalletData,
      currentUser,
      payPalClientId,
      loadingPayPalId,
      networkErrorPayPal,
      fetchPayPalClientIdWithRetry,
      handleWalletLoadSuccess,
      handlePaymentError,
      availableAssetsForTransfer,
      userProfileData,
      loadingProfile,
    }) => {
      const triggerStyle = "data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg rounded-md px-3 py-2 text-sm font-medium transition-all";
      
      return (
        <>
          <h1 className="text-3xl sm:text-4xl font-bold mt-12 mb-6 sm:mb-8 text-center gradient-text-gold">
            Herramientas de Gestión
          </h1>
          <Tabs defaultValue="balances" className="w-full">
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 gap-1 max-w-5xl mx-auto bg-slate-800/90 p-1.5 rounded-lg shadow-md">
              <TabsTrigger value="balances" className={triggerStyle}><Wallet className="mr-2 h-4 w-4 inline-block" />Wallets</TabsTrigger>
              <TabsTrigger value="load-wallet" className={triggerStyle}><CreditCard className="mr-2 h-4 w-4 inline-block" />Cargar (PayPal)</TabsTrigger>
              <TabsTrigger value="load-manual" className={triggerStyle}><Landmark className="mr-2 h-4 w-4 inline-block" />Cargar (Manual)</TabsTrigger>
              <TabsTrigger value="transfer" className={triggerStyle}><Send className="mr-2 h-4 w-4 inline-block" />Transferir</TabsTrigger>
              <TabsTrigger value="exchange" className={triggerStyle}><Repeat className="mr-2 h-4 w-4 inline-block" />Intercambiar</TabsTrigger>
              <TabsTrigger value="history" className={triggerStyle}><LayoutList className="mr-2 h-4 w-4 inline-block" />Historial</TabsTrigger>
            </TabsList>

            <TabsContent value="balances" className="mt-8">
              <AssetWalletCards
                balances={balances} 
                loadingBalances={loadingBalances}
                onRefreshBalances={fetchAllWalletData}
                currentUser={currentUser}
                userProfileData={userProfileData}
                loadingProfile={loadingProfile}
              />
            </TabsContent>

            <TabsContent value="load-wallet" className="mt-8">
              {loadingPayPalId && !networkErrorPayPal ? (
                <div className="flex justify-center items-center my-10"><Loader2 className="h-8 w-8 animate-spin text-purple-400" /><p className="ml-3 text-slate-300">Cargando...</p></div>
              ) : networkErrorPayPal ? (
                <div className="my-10 p-4 bg-yellow-900/30 border border-yellow-700/50 rounded-lg text-center">
                  <WifiOff className="mx-auto h-8 w-8 text-yellow-400 mb-2" />
                  <p className="text-yellow-300 font-semibold">Error de Red (Pagos)</p>
                  <p className="text-slate-300 text-sm">{networkErrorPayPal}</p>
                  <Button variant="link" onClick={fetchPayPalClientIdWithRetry} className="text-purple-400 mt-1">Reintentar</Button>
                </div>
              ) : (
                <LoadWalletSection 
                  payPalClientId={payPalClientId}
                  onSuccess={handleWalletLoadSuccess}
                  onError={handlePaymentError}
                  currentUser={currentUser}
                />
              )}
            </TabsContent>

            <TabsContent value="load-manual" className="mt-8">
              <LoadWalletManual currentUser={currentUser} />
            </TabsContent>

            <TabsContent value="transfer" className="mt-8">
              <TransferSection 
                availableAssets={availableAssetsForTransfer}
                onTransaction={fetchAllWalletData}
                userProfileData={userProfileData}
                loadingProfile={loadingProfile}
              />
            </TabsContent>

            <TabsContent value="exchange" className="mt-8">
              <ExchangeSection />
            </TabsContent>

            <TabsContent value="history" className="mt-8">
              <TransactionsSection 
                transactions={transactions}
                loadingTransactions={loadingTransactions}
                onRefreshTransactions={fetchAllWalletData}
                currentUser={currentUser}
              />
            </TabsContent>
          </Tabs>
        </>
      );
    };

    export default ManagementTabs;