import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Coins, DollarSign, Briefcase, RefreshCw, AlertTriangle } from 'lucide-react';
import { ASSET_CONFIG, getAssetConfig } from '@/config/assets.jsx';

const StatCard = ({ title, value, icon, description, colorClass = "text-purple-400", unit = "" }) => {
  const IconComponent = icon;
  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(0,0,0,0.2)" }}
      className="h-full"
    >
      <Card className="bg-slate-800/70 border-slate-700 shadow-lg backdrop-blur-sm h-full flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-300">{title}</CardTitle>
          <IconComponent className={`h-5 w-5 ${colorClass}`} />
        </CardHeader>
        <CardContent className="flex-grow">
          <div className={`text-3xl font-bold ${colorClass}`}>{value} <span className="text-xl text-slate-400">{unit}</span></div>
          {description && <p className="text-xs text-slate-500 pt-1">{description}</p>}
        </CardContent>
      </Card>
    </motion.div>
  );
};

const UserDashboardSection = ({ balances, loadingBalances }) => {
  const asoBalance = balances['ASO'] || 0;
  const usdBalance = balances['USD'] || 0; 

  const otherCryptoBalances = ASSET_CONFIG
    .filter(asset => !['ASO', 'USD'].includes(asset.symbol) && balances[asset.symbol] > 0)
    .map(asset => ({
      ...asset,
      balance: balances[asset.symbol] || 0
    }));

  if (loadingBalances) {
    return (
      <div className="grid md:grid-cols-3 gap-4 sm:gap-6 mb-12">
        {[1,2,3].map(i => (
          <Card key={i} className="bg-slate-800/70 border-slate-700 shadow-lg backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 bg-slate-700 rounded w-3/4"></div>
               <div className="h-5 w-5 bg-slate-700 rounded-full"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-slate-700 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-slate-700 rounded w-full"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mb-12"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        <StatCard
          title="Saldo Total ASO"
          value={asoBalance.toLocaleString(undefined, { maximumFractionDigits: getAssetConfig('ASO').precision })}
          unit="ASO"
          icon={Coins}
          description="Total de ASO en tu billetera."
          colorClass="text-gold-aso"
        />
        <StatCard
          title="Saldo Recargado"
          value={usdBalance.toLocaleString(undefined, { maximumFractionDigits: getAssetConfig('USD').precision })}
          unit="USD"
          icon={DollarSign}
          description="Fondos disponibles cargados a tu cuenta."
          colorClass="text-green-400"
        />
        <Card className="bg-slate-800/70 border-slate-700 shadow-lg backdrop-blur-sm md:col-span-2 lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">Mis Otras Criptos</CardTitle>
            <Briefcase className="h-5 w-5 text-blue-400" />
          </CardHeader>
          <CardContent>
            {otherCryptoBalances.length > 0 ? (
              <div className="space-y-3 max-h-48 overflow-y-auto custom-scrollbar pr-2">
                {otherCryptoBalances.map(asset => {
                  const AssetIcon = asset.iconComponent;
                  return (
                    <div key={asset.symbol} className="flex items-center justify-between text-sm p-2 bg-slate-700/50 rounded-md">
                      <div className="flex items-center">
                        <AssetIcon />
                        <span className="ml-2 text-slate-200">{asset.name} ({asset.symbol})</span>
                      </div>
                      <span className={`font-semibold ${asset.color || 'text-slate-100'}`}>
                        {asset.balance.toLocaleString(undefined, { maximumFractionDigits: asset.precision })}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-slate-500 text-center py-4">No posees otras criptomonedas actualmente.</p>
            )}
             {otherCryptoBalances.length === 0 && (
                <div className="flex items-center justify-center text-slate-500 mt-2">
                    <AlertTriangle size={14} className="mr-1"/>
                    <span>Puedes intercambiar ASO o USD por otras criptos.</span>
                </div>
            )}
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default UserDashboardSection;