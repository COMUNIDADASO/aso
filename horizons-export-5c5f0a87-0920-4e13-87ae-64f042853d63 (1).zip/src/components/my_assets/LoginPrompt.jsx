import React from 'react';
import { motion } from 'framer-motion';
import { Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const LoginPrompt = () => {
  const { toast } = useToast();
  
  const handleLoginClick = () => {
    const authModalTrigger = document.querySelector('button[data-auth-modal-trigger="true"]');
    if (authModalTrigger) {
      authModalTrigger.click();
    } else {
      toast({ title: "Error", description: "No se pudo abrir el diálogo de inicio de sesión." });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 sm:px-6 py-20 text-center flex flex-col items-center justify-center min-h-[calc(100vh-200px)]"
    >
      <Wallet size={64} className="mx-auto text-purple-400 mb-4" />
      <h1 className="text-3xl sm:text-4xl font-bold mb-4 gradient-text-gold">Mis Activos</h1>
      <p className="text-lg text-gray-300 mb-6">Por favor, inicia sesión para ver y gestionar tus activos.</p>
      <Button onClick={handleLoginClick} className="gradient-bg hover:opacity-90">
        Iniciar Sesión
      </Button>
    </motion.div>
  );
};

export default LoginPrompt;