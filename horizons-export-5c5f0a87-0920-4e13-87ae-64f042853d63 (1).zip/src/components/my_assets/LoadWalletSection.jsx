import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CreditCard as LoadWalletIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';

const LoadWalletSection = ({ payPalClientId, onSuccess, onError, currentUser }) => {
  const { toast } = useToast();

  const handleDisabledClick = () => {
    toast({
      title: "Boton deshabilitado",
      variant: "default",
    });
  };

  if (!currentUser) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center p-8"
      >
        <p className="text-slate-300">Por favor, inicia sesión para cargar saldo a tu wallet.</p>
      </motion.div>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex justify-center"
    >
      <Card className="bg-slate-800/70 border-slate-700 shadow-xl w-full max-w-lg backdrop-blur-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-3">
            <LoadWalletIcon className="h-7 w-7 text-purple-400" />
            <CardTitle className="text-2xl font-bold text-gold-aso">
              Cargar Saldo a tu Wallet
            </CardTitle>
          </div>
          <CardDescription className="text-gray-400 pt-1">
            Añade fondos a tu cuenta de forma rápida y segura usando PayPal. El monto mínimo es $1.00 USD.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <label htmlFor="customAmountInput-wallet-top-up" className="block text-sm font-medium text-gray-300 mb-1">Ingresa el monto a cargar (USD):</label>
            <Input
              id="customAmountInput-wallet-top-up"
              type="text"
              inputMode="decimal"
              placeholder="Ej: 50.00"
              disabled
              className="bg-slate-700/50 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
            />
          </div>
          <Button
            onClick={handleDisabledClick}
            className="w-full text-lg py-3 sm:py-4 bg-blue-600 hover:bg-blue-700 transition-colors"
          >
            Pagar con PayPal
          </Button>
           <p className="text-xs text-slate-500 mt-4 text-center">
            Los fondos se acreditarán a tu cuenta. PayPal puede aplicar sus propias tarifas de transacción.
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default LoadWalletSection;