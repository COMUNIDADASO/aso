import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertTriangle } from 'lucide-react';
import { ASSET_CONFIG } from '@/config/assets.jsx';

const BalancesSection = ({ balances, loadingBalances, onRefreshBalances, currentUser }) => {
  const assetsToRender = [];
  ASSET_CONFIG.forEach(conf => {
    if (conf.breakdown) {
      conf.breakdown.forEach(bConf => {
        if (balances[bConf.symbol] !== undefined) {
          assetsToRender.push({ ...conf, ...bConf, breakdown: undefined });
        }
      });
    } else {
      if (balances[conf.symbol] !== undefined) {
        assetsToRender.push(conf);
      }
    }
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Saldos de Criptomonedas</CardTitle>
        <CardDescription>Tu portafolio actual de activos digitales.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {loadingBalances ? <p className="text-center text-gray-400 py-8">Cargando saldos... <RefreshCw className="inline-block animate-spin ml-2" /></p> : (
          Object.keys(balances).length > 0 ? (
            assetsToRender.map(assetConf => {
              const balance = balances[assetConf.symbol] || 0;
              const IconComponent = assetConf.iconComponent;
              return (
                <div key={assetConf.symbol} className={`p-4 sm:p-6 rounded-lg shadow-lg ${assetConf.isNative ? 'bg-gradient-to-r from-gold-aso/20 to-yellow-600/20' : 'bg-slate-700/30'}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className={`text-sm ${assetConf.isNative ? 'text-yellow-300' : 'text-slate-300'}`}>{assetConf.name}</p>
                      <p className="text-2xl sm:text-3xl font-bold text-white">{balance.toLocaleString(undefined, {maximumFractionDigits: assetConf.precision})} {assetConf.symbol}</p>
                    </div>
                    {IconComponent && <IconComponent className={`h-10 w-10 sm:h-12 sm:w-12 ${assetConf.color || ''}`} />}
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-center text-gray-400 py-8">No se encontraron saldos. <AlertTriangle className="inline-block ml-2" /></p>
          )
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={onRefreshBalances} variant="outline" className="w-full sm:w-auto border-purple-500 text-purple-300 hover:bg-purple-500/10" disabled={loadingBalances || !currentUser}>
          <RefreshCw className={`mr-2 h-4 w-4 ${loadingBalances ? 'animate-spin' : ''}`} /> Actualizar Saldos
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BalancesSection;