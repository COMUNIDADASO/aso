import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { RefreshCw, AlertTriangle } from 'lucide-react';

const TransactionsSection = ({ transactions, loadingTransactions, onRefreshTransactions, currentUser }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Historial de Transacciones</CardTitle>
        <CardDescription>Tus movimientos recientes en la plataforma.</CardDescription>
      </CardHeader>
      <CardContent>
        {loadingTransactions ? <p className="text-center text-gray-400 py-8">Cargando transacciones... <RefreshCw className="inline-block animate-spin ml-2" /></p> : (
          transactions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="hidden sm:table-cell">Fecha</TableHead>
                  <TableHead>Tipo / Descripción</TableHead>
                  <TableHead className="text-right">Monto</TableHead>
                  <TableHead className="text-right hidden md:table-cell">Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map(tx => (
                  <TableRow key={tx.id}>
                    <TableCell className="hidden sm:table-cell">{tx.date}</TableCell>
                    <TableCell>
                      <p className="font-medium capitalize">{tx.type}</p>
                      {tx.description && <p className="text-xs text-slate-400">{tx.description}</p>}
                    </TableCell>
                    <TableCell className="text-right">{tx.amountDisplay}</TableCell>
                    <TableCell className="text-right hidden md:table-cell">
                        <span className={`px-2 py-0.5 rounded-full text-xs capitalize ${
                          tx.status === 'completado' ? 'bg-green-500/20 text-green-300' : 
                          tx.status === 'pendiente' ? 'bg-yellow-500/20 text-yellow-300' :
                          'bg-red-500/20 text-red-300'
                        }`}>
                        {tx.status}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              <TableCaption>Fin del historial de transacciones.</TableCaption>
            </Table>
          ) : <p className="text-center text-gray-400 py-8">No hay transacciones recientes. <AlertTriangle className="inline-block ml-2" /></p>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={onRefreshTransactions} variant="outline" className="w-full sm:w-auto border-purple-500 text-purple-300 hover:bg-purple-500/10" disabled={loadingTransactions || !currentUser}>
          <RefreshCw className={`mr-2 h-4 w-4 ${loadingTransactions ? 'animate-spin' : ''}`} /> Actualizar Historial
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TransactionsSection;