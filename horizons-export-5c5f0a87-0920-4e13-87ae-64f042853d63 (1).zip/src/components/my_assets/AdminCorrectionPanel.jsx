import React, { useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, AlertTriangle, Save, CheckCircle, RefreshCw } from 'lucide-react';

const AdminCorrectionPanel = ({ onBalanceUpdate, currentUser }) => {
  const { toast } = useToast();
  const [balanceInput, setBalanceInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasBeenUsed, setHasBeenUsed] = useState(false);

  useEffect(() => {
    const usedFlag = localStorage.getItem('adminBalanceToolUsed');
    if (usedFlag === 'true') {
      setHasBeenUsed(true);
    }
  }, []);

  const handleResetTool = () => {
    localStorage.removeItem('adminBalanceToolUsed');
    setHasBeenUsed(false);
    toast({
      title: "Herramienta Reactivada",
      description: "Ahora puedes intentar establecer el saldo de nuevo.",
    });
  };

  const handleSetBalance = async () => {
    if (!currentUser) {
      toast({ title: "Error", description: "Usuario no encontrado. Por favor, recarga la página.", variant: "destructive" });
      return;
    }

    const balanceValue = parseFloat(balanceInput.replace(/,/g, ''));
    if (isNaN(balanceValue) || balanceValue < 0) {
      toast({
        title: "Valor Inválido",
        description: "Por favor, introduce un número válido para el saldo.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data: functionData, error: functionError } = await supabase.functions.invoke('set-admin-balance-manual', {
        body: { balance: balanceValue },
      });

      if (functionError) throw functionError;
      if (functionData.error) throw new Error(functionData.error);

      toast({
        title: "Éxito! Verificando...",
        description: "El servidor confirmó el cambio. Verificando que el saldo se refleje en tu wallet...",
        variant: "default",
        duration: 15000,
      });

      let verificationSuccess = false;
      for (let i = 0; i < 15; i++) { 
        await new Promise(resolve => setTimeout(resolve, 1000));
        const { data: walletData } = await supabase
          .from('user_wallets')
          .select('balance')
          .eq('user_id', currentUser.id)
          .eq('asset_symbol', 'ASO')
          .single();

        if (walletData && parseFloat(walletData.balance) === balanceValue) {
          verificationSuccess = true;
          break;
        }
      }

      if (verificationSuccess) {
        toast({
          title: "¡Saldo Actualizado Correctamente!",
          description: `Tu saldo de ASO es ahora ${balanceValue.toLocaleString()}.`,
          variant: "success",
        });
        localStorage.setItem('adminBalanceToolUsed', 'true');
        setHasBeenUsed(true);
      } else {
        throw new Error("La verificación del saldo falló. El saldo no se actualizó en la wallet. Por favor, inténtalo de nuevo.");
      }

      if (onBalanceUpdate) {
        await onBalanceUpdate();
      }

    } catch (error) {
      console.error("Error setting admin balance:", error);
      toast({
        title: "Error al Establecer Saldo",
        description: error.message || "No se pudo establecer el saldo. La herramienta no se ha bloqueado.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (hasBeenUsed) {
    return (
      <Card className="my-8 bg-green-900/30 border-green-700/50">
        <CardHeader>
          <CardTitle className="text-green-300 flex items-center">
            <CheckCircle className="mr-2" /> Herramienta Utilizada
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-slate-300 text-center sm:text-left">
            La herramienta de ajuste manual de saldo ya ha sido utilizada.
          </p>
          <Button onClick={handleResetTool} variant="outline" size="sm" className="border-green-600 text-green-300 hover:bg-green-800/50 hover:text-white">
            <RefreshCw className="mr-2 h-4 w-4" />
            Reactivar Herramienta
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="my-8 bg-yellow-900/30 border-yellow-700/50">
      <CardHeader>
        <CardTitle className="text-yellow-300 flex items-center">
          <AlertTriangle className="mr-2" /> Herramienta de Ajuste Manual de Saldo
        </CardTitle>
        <CardDescription className="text-yellow-400">
          Usa esta herramienta con extrema precaución. Se bloqueará después de un uso exitoso para establecer permanentemente tu saldo de ASO.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-slate-300">
            Introduce el saldo exacto de ASO que deseas tener en tu wallet de administrador.
          </p>
          <div>
            <label htmlFor="balance-input" className="text-sm font-medium text-slate-200 mb-2 block">
              Saldo de ASO
            </label>
            <Input
              id="balance-input"
              type="text"
              placeholder="Ej: 500000000"
              value={balanceInput}
              onChange={(e) => setBalanceInput(e.target.value)}
              disabled={isLoading}
              className="border-yellow-600 focus:ring-yellow-500"
            />
          </div>
          <Button
            onClick={handleSetBalance}
            disabled={isLoading || !balanceInput}
            variant="destructive"
            className="w-full sm:w-auto bg-yellow-600 hover:bg-yellow-700 text-white"
          >
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            Guardar Saldo (Acción Irreversible)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminCorrectionPanel;