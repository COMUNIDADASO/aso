import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { UserCircle2, Edit3, UploadCloud, Loader2, Save, DownloadCloud } from 'lucide-react';

const UserProfileSection = ({ profileData, onUpdateProfile, loading: loadingProp }) => {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [sexo, setSexo] = useState('');
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [localAvatarPreview, setLocalAvatarPreview] = useState(null); 
  const [uploading, setUploading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const fileInputRef = useRef(null);

  const seriesImages = {
    male: [
      "man looking at the camera with a slight smile",
      "professional man in a suit",
      "casual man outdoors",
      "futuristic hero male character concept art",
      "cyberpunk male warrior"
    ],
    female: [
      "woman with a friendly expression",
      "professional woman in business attire",
      "woman enjoying nature",
      "fantasy queen character portrait",
      "sci-fi female pilot"
    ],
    other: [
      "abstract artistic portrait",
      "serene landscape representing a person",
      "geometric pattern with human-like features",
      "mystical elemental being",
      "android or robot concept"
    ]
  };

  useEffect(() => {
    if (profileData) {
      setName(profileData.name || '');
      setEmail(profileData.email || '');
      setAvatarUrl(profileData.avatar_url || null);
      setLocalAvatarPreview(profileData.avatar_url || null);
      setSexo(profileData.raw_data?.sexo || '');
    } else {
      setName('');
      setEmail('');
      setAvatarUrl(null);
      setLocalAvatarPreview(null);
      setSexo('');
    }
  }, [profileData]);

  const getGenderKey = () => {
    const s = sexo?.toLowerCase().trim();
    if (s === 'masculino' || s === 'm' || s === 'male') return 'male';
    if (s === 'femenino' || s === 'f' || s === 'female' || s === 'mujer') return 'female';
    return 'other';
  };

  const getRandomSeriesImageDescription = () => {
    const genderKey = getGenderKey();
    const images = seriesImages[genderKey];
    return images[Math.floor(Math.random() * images.length)];
  };
  
  const displayAvatarAltText = name || 'Avatar de usuario';
  const currentAvatarSrc = localAvatarPreview || avatarUrl;


  const handleUploadAvatar = async (event) => {
    try {
      setUploading(true);
      if (!event.target.files || event.target.files.length === 0) {
        throw new Error('Debes seleccionar una imagen para subir.');
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${profileData.auth_user_id || Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      let { error: uploadError } = await supabase.storage.from('user-assets').upload(filePath, file, { upsert: true });
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from('user-assets').getPublicUrl(filePath);
      
      setLocalAvatarPreview(publicUrl); 
      setAvatarUrl(publicUrl); 

      toast({ title: "Imagen Subida", description: "Tu avatar ha sido actualizado. Guarda los cambios para confirmar.", variant: "success" });
    } catch (error) {
      toast({ title: "Error al Subir", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = ""; 
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const rawDataUpdates = { sexo: sexo };
    await onUpdateProfile({ name, avatar_url: avatarUrl, raw_data_updates: rawDataUpdates });
    setIsEditing(false);
  };
  
  const handleCancelEdit = () => {
    setIsEditing(false);
    if (profileData) {
        setName(profileData.name || '');
        setAvatarUrl(profileData.avatar_url || null);
        setLocalAvatarPreview(profileData.avatar_url || null);
        setSexo(profileData.raw_data?.sexo || '');
    }
  };

  const handleExportData = async () => {
    setIsExporting(true);
    toast({ title: "Preparando exportación...", description: "Estamos recopilando tus datos. Esto puede tardar un momento." });
    try {
        const { data, error } = await supabase.functions.invoke('export-user-data');

        if (error) throw error;

        if (!(data instanceof Blob)) {
            const errorJson = await data.json();
            throw new Error(errorJson.error || "La exportación devolvió un formato inesperado.");
        }

        const url = window.URL.createObjectURL(data);
        const a = document.createElement('a');
        a.href = url;
        a.download = `asocoin_data_export_${profileData.auth_user_id}.json`;
        document.body.appendChild(a);
        a.click();
        
        toast({ title: "¡Exportación Exitosa!", description: "Tus datos se han descargado.", variant: "success" });
        
        window.URL.revokeObjectURL(url);
        a.remove();
    } catch (error) {
        console.error("Error exporting data:", error);
        toast({ title: "Error en la Exportación", description: error.message, variant: "destructive" });
    } finally {
        setIsExporting(false);
    }
  };

  if (loadingProp && !profileData) { 
    return (
      <div className="flex justify-center items-center my-10">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
        <p className="ml-3 text-slate-300">Cargando perfil...</p>
      </div>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card className="mb-12 bg-slate-800/70 border-slate-700 shadow-xl backdrop-blur-sm">
        <CardHeader className="flex flex-col sm:flex-row items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              {currentAvatarSrc ? (
                <img src={currentAvatarSrc} alt={displayAvatarAltText} className="h-20 w-20 sm:h-24 sm:w-24 rounded-full object-cover border-4 border-purple-500 shadow-lg" />
              ) : (
                 <img-replace alt={getRandomSeriesImageDescription()} className="h-20 w-20 sm:h-24 sm:w-24 rounded-full object-cover border-4 border-purple-500 shadow-lg" />
              )}
              {isEditing && (
                <Button
                  size="icon"
                  variant="outline"
                  className="absolute bottom-0 right-0 bg-slate-700 hover:bg-slate-600 border-purple-400 rounded-full h-8 w-8 z-10"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  title="Cambiar avatar"
                >
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4 text-purple-300" />}
                </Button>
              )}
            </div>
            <div>
              <CardTitle className="text-2xl sm:text-3xl font-bold text-gold-aso">{name || 'Usuario'}</CardTitle>
              <CardDescription className="text-slate-400">{email}</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={handleExportData} disabled={isExporting} className="bg-blue-600 hover:bg-blue-700 text-white">
              {isExporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <DownloadCloud className="mr-2 h-4 w-4" />}
              Exportar Datos
            </Button>
            {!isEditing && (
              <Button variant="outline" onClick={() => setIsEditing(true)} className="border-purple-500 text-purple-300 hover:bg-purple-500/10">
                <Edit3 className="mr-2 h-4 w-4" /> Editar Perfil
              </Button>
            )}
          </div>
        </CardHeader>
        {isEditing && (
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6 pt-6">
              <div>
                <Label htmlFor="profileName" className="text-slate-300">Nombre Completo</Label>
                <Input
                  id="profileName"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
                  placeholder="Tu nombre"
                />
              </div>
               <div>
                <Label htmlFor="profileSexo" className="text-slate-300">Sexo (para imagen genérica)</Label>
                <Input
                  id="profileSexo"
                  type="text"
                  value={sexo}
                  onChange={(e) => setSexo(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
                  placeholder="Masculino / Femenino / Otro"
                />
              </div>
              <div>
                <Label htmlFor="avatarUpload" className="text-slate-300">Subir Nuevo Avatar</Label>
                <Input
                  id="avatarUpload"
                  type="file"
                  accept="image/*"
                  onChange={handleUploadAvatar}
                  disabled={uploading}
                  ref={fileInputRef}
                  className="bg-slate-700 border-slate-600 text-white file:text-purple-300 file:font-semibold file:bg-slate-600 file:border-none file:rounded-md file:px-3 file:py-1.5 hover:file:bg-purple-500/20"
                />
                {uploading && <p className="text-sm text-purple-400 mt-1">Subiendo imagen...</p>}
              </div>
            </CardContent>
            <CardFooter className="flex justify-end space-x-3">
              <Button type="button" variant="ghost" onClick={handleCancelEdit} className="text-slate-400 hover:text-slate-200">
                Cancelar
              </Button>
              <Button type="submit" className="gradient-button" disabled={uploading || loadingProp}>
                {loadingProp ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Guardar Cambios
              </Button>
            </CardFooter>
          </form>
        )}
      </Card>
    </motion.div>
  );
};

export default UserProfileSection;