import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { UglyCashIcon, BinanceIcon, KucoinIcon, CoinexIcon } from '@/config/assets.jsx';

const EXCHANGES = [
  { name: 'Ugly Cash', logo: UglyCashIcon, url: 'https://ugly.cash/es/' },
  { name: 'Binance', logo: BinanceIcon, url: 'https://www.binance.com/' },
  { name: 'KuCoin', logo: KucoinIcon, url: 'https://www.kucoin.com/' },
  { name: 'CoinEx', logo: CoinexIcon, url: 'https://www.coinex.com/' },
];

const ExternalExchangesSection = () => {
  const { toast } = useToast();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="mt-12 sm:mt-16"
    >
      <h2 className="text-2xl sm:text-3xl font-semibold mb-4 sm:mb-6 text-center text-slate-200">
        Conéctate con Exchanges Externos
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        {EXCHANGES.map(exchange => (
          <Card key={exchange.name} className="bg-slate-800/60 border-slate-700 hover:border-purple-500/70 hover:shadow-purple-500/20 transition-all duration-300 flex flex-col">
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-base sm:text-lg font-medium text-slate-100">{exchange.name}</CardTitle>
              <exchange.logo className="h-6 w-6" />
            </CardHeader>
            <CardContent className="flex flex-col flex-grow">
              <p className="text-xs sm:text-sm text-slate-400 mb-3 flex-grow">
                {exchange.name === 'Ugly Cash' 
                  ? 'Plataforma descentralizada para activos digitales.'
                  : `Opera con una amplia gama de activos en ${exchange.name}.`}
              </p>
              <Button variant="outline" className="w-full border-blue-500 text-blue-300 hover:bg-blue-500/10 mt-auto" onClick={() => {
                window.open(exchange.url, '_blank');
                toast({title: `Redirigiendo a ${exchange.name}`, description: "Se abrirá en una nueva pestaña."});
              }}>
                <ExternalLink className="mr-2 h-4 w-4" /> 
                {exchange.name === 'Ugly Cash' ? 'Conectar' : `Visitar ${exchange.name}`}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      <p className="text-xs text-slate-500 mt-4 text-center">
        COMUNIDAD ASO esta actualmente en procesos técnicos para conectarnos directamente a estas plataformas y pronto podrás usarlos en esta web con tus direcciones de wallet.
      </p>
    </motion.div>
  );
};

export default ExternalExchangesSection;