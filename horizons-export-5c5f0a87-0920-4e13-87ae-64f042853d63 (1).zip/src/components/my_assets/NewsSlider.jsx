import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardDescription, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, ExternalLink, Rss, AlertTriangle, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const NewsSlider = () => {
  const [newsItems, setNewsItems] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchNews = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('news_feed_items')
          .select('id, title, url, description, image_url')
          .order('created_at', { ascending: false })
          .limit(10); 

        if (error) throw error;
        setNewsItems(data || []);
      } catch (error) {
        console.error("Error fetching news:", error);
        toast({
          title: "Error al Cargar Noticias",
          description: "No se pudieron obtener las últimas noticias.",
          variant: "destructive",
        });
        setNewsItems([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchNews();
  }, [toast]);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? newsItems.length - 1 : prevIndex - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex === newsItems.length - 1 ? 0 : prevIndex + 1));
  };

  if (isLoading) {
    return (
      <div className="w-full py-8 text-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400 mx-auto" />
        <p className="text-slate-400 mt-2">Cargando noticias...</p>
      </div>
    );
  }

  if (!newsItems || newsItems.length === 0) {
    return (
      <div className="w-full py-8">
        <Card className="bg-slate-800/60 border-slate-700/50 p-6 rounded-xl shadow-lg text-center">
            <Rss className="mx-auto h-10 w-10 text-slate-500 mb-3" />
            <CardTitle className="text-lg text-slate-300">No hay noticias recientes</CardTitle>
            <CardDescription className="text-slate-400 text-sm">Vuelve más tarde para ver las últimas actualizaciones.</CardDescription>
        </Card>
      </div>
    );
  }

  const currentNews = newsItems[currentIndex];

  return (
    <div className="w-full relative py-8">
      <h2 className="text-2xl font-semibold text-slate-100 mb-6 text-center flex items-center justify-center">
        <Rss className="mr-3 text-purple-400" /> Últimas Noticias y Anuncios
      </h2>
      <motion.div
        key={currentIndex}
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -50 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl mx-auto"
      >
        <Card className="bg-gradient-to-br from-slate-800/70 via-slate-800/50 to-purple-900/30 border-slate-700/50 shadow-xl rounded-xl overflow-hidden glass-effect">
          {currentNews.image_url && (
             <img  src={currentNews.image_url} alt={currentNews.title || 'Imagen de noticia'} className="w-full h-48 object-cover" src="https://images.unsplash.com/photo-1662485732745-5a841bfe7f65" />
          )}
          <CardContent className="p-6">
            <CardTitle className="text-xl font-bold text-gold-aso mb-2 hover:text-purple-400 transition-colors">
              <a href={currentNews.url} target="_blank" rel="noopener noreferrer">
                {currentNews.title || new URL(currentNews.url).hostname}
              </a>
            </CardTitle>
            <CardDescription className="text-slate-300 text-sm mb-4 line-clamp-3">
              {currentNews.description || currentNews.url}
            </CardDescription>
            <Button asChild variant="outline" className="border-purple-500 text-purple-300 hover:bg-purple-500/20 w-full sm:w-auto">
              <a href={currentNews.url} target="_blank" rel="noopener noreferrer">
                Leer Más <ExternalLink className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {newsItems.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            onClick={handlePrev}
            className="absolute left-0 sm:left-4 top-1/2 transform -translate-y-1/2 bg-slate-700/50 hover:bg-purple-600/70 text-white rounded-full shadow-lg z-10"
            aria-label="Noticia Anterior"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleNext}
            className="absolute right-0 sm:right-4 top-1/2 transform -translate-y-1/2 bg-slate-700/50 hover:bg-purple-600/70 text-white rounded-full shadow-lg z-10"
            aria-label="Siguiente Noticia"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        </>
      )}
       <div className="flex justify-center mt-4 space-x-2">
        {newsItems.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 w-2 rounded-full transition-all duration-300 ${currentIndex === index ? 'bg-purple-500 scale-125' : 'bg-slate-600 hover:bg-slate-500'}`}
            aria-label={`Ir a noticia ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default NewsSlider;