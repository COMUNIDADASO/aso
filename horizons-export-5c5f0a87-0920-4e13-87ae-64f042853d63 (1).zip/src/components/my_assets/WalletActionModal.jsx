import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Send, ArrowDownToLine, Copy, AlertTriangle, QrCode, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const WalletActionModal = ({ isOpen, setIsOpen, asset, balance, userProfileData, loadingProfile }) => {
  const { toast } = useToast();
  const [sendAddress, setSendAddress] = useState('');
  const [sendAmount, setSendAmount] = useState('');
  const [sendMemo, setSendMemo] = useState('');
  const [activeTab, setActiveTab] = useState('send');
  const [depositAddress, setDepositAddress] = useState(null);
  const [loadingAddress, setLoadingAddress] = useState(false);

  const fetchDepositAddress = useCallback(async () => {
    if (!asset || depositAddress) return;
    setLoadingAddress(true);
    try {
      const { data, error } = await supabase.rpc('get_or_create_deposit_address', {
        p_asset_symbol: asset.symbol
      });

      if (error) throw error;
      
      if (data) {
        setDepositAddress(data);
      } else {
        throw new Error("No se recibió una dirección del servidor.");
      }
    } catch (err) {
      console.error("Error fetching deposit address:", err);
      toast({ title: "Error", description: `No se pudo generar tu dirección de depósito para ${asset.symbol}.`, variant: "destructive" });
    } finally {
      setLoadingAddress(false);
    }
  }, [asset, toast, depositAddress]);

  useEffect(() => {
    if (isOpen && activeTab === 'receive') {
      fetchDepositAddress();
    }
    if (!isOpen) {
      setActiveTab('send');
      setDepositAddress(null);
    }
  }, [activeTab, isOpen, fetchDepositAddress]);

  if (!asset) {
    return null;
  }

  const AssetIcon = asset.iconComponent || (() => <AlertTriangle className="h-6 w-6 text-yellow-400" />);

  const handleSend = () => {
    if (loadingProfile) {
      toast({ title: 'Verificando perfil...', description: 'Por favor, espere un momento.', variant: 'default' });
      return;
    }
    if (!userProfileData?.raw_data?.biometric_enabled) {
      toast({
        title: 'Verificación Requerida',
        description: 'CONFIGURE SU BIOMETRÍA PARA RETIRAR.',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: "🚧 Funcionalidad no implementada",
      description: `El envío de ${asset.symbol} a wallets externas no está disponible aún. ¡Puedes solicitarlo! 🚀`,
      variant: "warning",
      duration: 5000,
    });
  };

  const handleCopyAddress = () => {
    if (depositAddress) {
      navigator.clipboard.writeText(depositAddress);
      toast({ title: "Dirección Copiada", description: "Tu dirección de billetera ha sido copiada al portapapeles." });
    } else {
      toast({ title: "Dirección no disponible", description: `No hay una dirección de depósito para ${asset.symbol} en este momento.`, variant: "warning" });
    }
  };
  
  const generateQrCodeUrl = (address) => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(address)}`;
  };


  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[480px] bg-slate-800 border-slate-700 text-white glass-effect p-0">
        <DialogHeader className="p-6 pb-4 bg-slate-900/50 rounded-t-lg">
          <div className="flex items-center space-x-3">
            <AssetIcon className="h-8 w-8" />
            <DialogTitle className="text-2xl font-bold gradient-text-gold">Gestionar {asset.name} ({asset.symbol})</DialogTitle>
          </div>
          <DialogDescription className="text-slate-400">
            Saldo disponible: {balance.toLocaleString(undefined, { maximumFractionDigits: asset.precision })} {asset.symbol}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="send" onValueChange={setActiveTab} className="w-full px-6 pb-6">
          <TabsList className="grid w-full grid-cols-2 bg-slate-700/50 p-1 rounded-md mb-4">
            <TabsTrigger value="send" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-md rounded-sm"><Send className="mr-2 h-4 w-4 inline-block" />Enviar</TabsTrigger>
            <TabsTrigger value="receive" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white data-[state=active]:shadow-md rounded-sm"><ArrowDownToLine className="mr-2 h-4 w-4 inline-block" />Recibir</TabsTrigger>
          </TabsList>

          <TabsContent value="send" className="space-y-4">
            <div>
              <Label htmlFor="send-address" className="text-slate-300">Dirección de Destino</Label>
              <Input id="send-address" value={sendAddress} onChange={(e) => setSendAddress(e.target.value)} placeholder={`Dirección de ${asset.symbol}`} className="bg-slate-700/80 border-slate-600" />
            </div>
            <div>
              <Label htmlFor="send-amount" className="text-slate-300">Monto a Enviar</Label>
              <Input id="send-amount" type="number" value={sendAmount} onChange={(e) => setSendAmount(e.target.value)} placeholder="0.00" className="bg-slate-700/80 border-slate-600" />
            </div>
            {asset.requiresMemo && (
              <div>
                <Label htmlFor="send-memo" className="text-slate-300">Memo / Tag (Opcional)</Label>
                <Input id="send-memo" value={sendMemo} onChange={(e) => setSendMemo(e.target.value)} placeholder="Memo o Tag de Destino" className="bg-slate-700/80 border-slate-600" />
              </div>
            )}
            <Button onClick={handleSend} className="w-full gradient-button">
              <Send className="mr-2 h-4 w-4" /> Enviar {asset.symbol}
            </Button>
            <p className="text-xs text-slate-500 text-center">
              <AlertTriangle className="inline h-3 w-3 mr-1 text-yellow-400"/>Las transferencias a wallets externas pueden incurrir en tarifas de red.
            </p>
          </TabsContent>

          <TabsContent value="receive" className="space-y-4 text-center">
            <p className="text-slate-300 text-sm">Usa la siguiente dirección para recibir {asset.name}:</p>
             {loadingAddress ? (
                <div className="flex items-center justify-center p-4">
                  <Loader2 className="h-6 w-6 animate-spin text-purple-400" />
                  <p className="ml-2 text-slate-300">Generando dirección segura...</p>
                </div>
              ) : depositAddress ? (
              <>
                <div className="p-3 bg-slate-700/80 rounded-md text-lg font-mono break-all">
                  {depositAddress}
                </div>
                 <div className="flex justify-center my-4">
                    <img src={generateQrCodeUrl(depositAddress)} alt={`Código QR para ${asset.name}`} className="rounded-lg border-2 border-purple-500 p-1 bg-white" />
                </div>
                <Button onClick={handleCopyAddress} variant="outline" className="w-full border-purple-500 text-purple-300 hover:bg-purple-500/20">
                  <Copy className="mr-2 h-4 w-4" /> Copiar Dirección
                </Button>
              </>
            ) : (
              <div className="p-4 bg-yellow-900/30 rounded-md text-yellow-300 text-sm">
                <AlertTriangle className="inline h-4 w-4 mr-2" />
                No se pudo cargar tu dirección de depósito. Por favor, intenta de nuevo.
              </div>
            )}
            {asset.requiresMemo && (
                 <p className="text-xs text-yellow-400 mt-2"><AlertTriangle className="inline h-3 w-3 mr-1"/>¡Importante! Si el exchange de origen requiere un Memo/Tag para depósitos de {asset.symbol}, asegúrate de incluirlo.</p>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="px-6 pb-6 pt-2 sm:justify-center">
          <DialogClose asChild>
            <Button type="button" variant="secondary" className="bg-slate-600 hover:bg-slate-500 text-white w-full">Cerrar</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default WalletActionModal;