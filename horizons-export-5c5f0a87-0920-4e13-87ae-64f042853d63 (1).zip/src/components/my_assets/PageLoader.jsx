import React from 'react';
import { Loader2 } from 'lucide-react';

const PageLoader = ({ message }) => (
  <div className="container mx-auto px-4 sm:px-6 py-20 text-center flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
    <Loader2 size={64} className="mx-auto text-purple-400 mb-4 animate-spin" />
    <p className="text-lg text-gray-300">{message}</p>
  </div>
);

export default PageLoader;