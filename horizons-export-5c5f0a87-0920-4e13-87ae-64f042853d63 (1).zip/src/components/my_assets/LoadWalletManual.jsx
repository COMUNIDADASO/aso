import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Landmark, Clipboard, Check, Loader2, UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const BankInfoDisplay = ({ info }) => {
    const [copied, setCopied] = useState(null);

    const handleCopy = (textToCopy, field) => {
        navigator.clipboard.writeText(textToCopy);
        setCopied(field);
        setTimeout(() => setCopied(null), 2000);
    };

    return (
        <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600 space-y-2">
            <h4 className="font-bold text-purple-300">{info.title}</h4>
            {info.details.map((detail) => (
                <div key={detail.label} className="flex items-center justify-between text-sm flex-wrap gap-y-1">
                    <span className="text-slate-300 mr-2">{detail.label}:</span>
                    <div className="flex items-center gap-2">
                        <span className="font-mono text-gold-aso text-right">{detail.value}</span>
                        {detail.copyable && (
                            <Button size="sm" variant="ghost" onClick={() => handleCopy(detail.value, detail.label)} className="shrink-0">
                                {copied === detail.label ? <Check className="h-4 w-4 text-green-400" /> : <Clipboard className="h-4 w-4" />}
                            </Button>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
};

const LoadWalletManual = ({ currentUser }) => {
    const { toast } = useToast();
    const [amount, setAmount] = useState('');
    const [reference, setReference] = useState('');
    const [imageFile, setImageFile] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const bankDetails = {
        title: "Kachin Almacenes TIA (vía Lead Bank)",
        details: [
            { label: "Titular", value: "Miguel Peñafiel", copyable: true },
            { label: "Tipo de Cuenta", value: "Corriente", copyable: false },
            { label: "Banco", value: "Lead Bank", copyable: false },
            { label: "Dirección Banco", value: "1801 Main St., Kansas City, MO 64108", copyable: false },
            { label: "Nº de Cuenta", value: "219082032039", copyable: true },
            { label: "Ruta ACH/Wire", value: "101019644", copyable: true },
        ]
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file && file.type === 'image/jpeg') {
            if (file.size > 5 * 1024 * 1024) { // 5MB limit
                 toast({ title: "Archivo muy grande", description: "La imagen no debe superar los 5MB.", variant: "destructive" });
                 e.target.value = null;
                 setImageFile(null);
            } else {
                setImageFile(file);
            }
        } else {
            toast({ title: "Archivo no válido", description: "Por favor, selecciona un archivo de imagen .jpg", variant: "destructive" });
            e.target.value = null;
            setImageFile(null);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!currentUser) {
            toast({ title: "No autenticado", description: "Debes iniciar sesión para notificar un depósito.", variant: "destructive" });
            return;
        }
        if (!amount || !imageFile) {
            toast({ title: "Datos incompletos", description: "Por favor, ingresa el monto y sube el comprobante.", variant: "destructive" });
            return;
        }
        if (parseFloat(amount) < 5) {
            toast({ title: "Monto inválido", description: "La recarga mínima es de $5 USD.", variant: "destructive" });
            return;
        }

        setIsSubmitting(true);
        try {
            const filePath = `${currentUser.id}/${Date.now()}_${imageFile.name.replace(/\s/g, '_')}`;
            const { error: uploadError } = await supabase.storage
                .from('deposit-receipts')
                .upload(filePath, imageFile);

            if (uploadError) {
                throw new Error(`Error al subir imagen: ${uploadError.message}`);
            }

            const { error: insertError } = await supabase.from('manual_deposits').insert({
                user_id: currentUser.id,
                amount: parseFloat(amount),
                reference_code: reference || 'N/A',
                receipt_image_url: filePath,
                status: 'pendiente'
            });

            if (insertError) {
                throw new Error(`Error al registrar depósito: ${insertError.message}`);
            }

            toast({
                title: "Notificación Enviada",
                description: "Hemos recibido tu notificación. Será procesada en las próximas 24-48 horas.",
                variant: "success"
            });
            setAmount('');
            setReference('');
            setImageFile(null);
            if (document.getElementById('receipt-file')) {
                document.getElementById('receipt-file').value = null;
            }
        } catch (error) {
            toast({
                title: "Error al Notificar",
                description: error.message || "No se pudo enviar la notificación. Inténtalo de nuevo.",
                variant: "destructive"
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!currentUser) {
        return (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center p-8"
            >
                <p className="text-slate-300">Por favor, inicia sesión para notificar un depósito manual.</p>
            </motion.div>
        );
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex justify-center"
        >
            <Card className="bg-slate-800/70 border-slate-700 shadow-xl w-full max-w-2xl backdrop-blur-sm">
                <CardHeader className="pb-4">
                    <div className="flex items-center space-x-3">
                        <Landmark className="h-7 w-7 text-purple-400" />
                        <CardTitle className="text-2xl font-bold text-gold-aso">
                            Cargar Saldo Manualmente
                        </CardTitle>
                    </div>
                    <CardDescription className="text-gray-400 pt-1">
                        Realiza un depósito a la siguiente cuenta y notifícalo aquí para acreditar tu saldo.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4 mb-6">
                        <BankInfoDisplay info={bankDetails} />
                        <div className="text-xs text-center text-slate-400 p-2 bg-slate-900/50 rounded-md space-y-1">
                            <p><span className="font-bold text-gold-aso">Importante:</span> Saldo mínimo de recarga: <span className="font-semibold text-white">$5 USD</span>.</p>
                            <p>El valor de la comisión lo asume la empresa. Recibirás el monto total en tu wallet.</p>
                            <p className="pt-1 text-slate-300">Este valor podrá ser retirado cuando el dueño de la wallet desee o transferido dentro de la web a otras wallets mientras no esté minando.</p>
                        </div>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4 border-t border-slate-700 pt-6">
                        <h3 className="text-lg font-semibold text-slate-200">Notificar mi Depósito</h3>
                        <div>
                            <Label htmlFor="amount">Monto Depositado (USD)</Label>
                            <Input
                                id="amount"
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="Ej: 25.00"
                                min="5"
                                step="0.01"
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="reference">Número de Comprobante o Referencia (Opcional)</Label>
                            <Input
                                id="reference"
                                type="text"
                                value={reference}
                                onChange={(e) => setReference(e.target.value)}
                                placeholder="Ej: 0012345"
                            />
                        </div>
                        <div>
                            <Label htmlFor="receipt-file">Comprobante de Pago (.jpg)</Label>
                            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-600 border-dashed rounded-md">
                                <div className="space-y-1 text-center">
                                    <UploadCloud className="mx-auto h-12 w-12 text-slate-400" />
                                    <div className="flex text-sm text-slate-500">
                                        <label htmlFor="receipt-file" className="relative cursor-pointer bg-slate-800 rounded-md font-medium text-purple-400 hover:text-purple-300 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-slate-900 focus-within:ring-purple-500 px-1">
                                            <span>Sube un archivo</span>
                                            <input id="receipt-file" name="receipt-file" type="file" className="sr-only" accept="image/jpeg" onChange={handleFileChange} required />
                                        </label>
                                        <p className="pl-1">o arrástralo aquí</p>
                                    </div>
                                    <p className="text-xs text-slate-500">
                                        {imageFile ? imageFile.name : 'Solo archivos JPG, hasta 5MB'}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600" disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            {isSubmitting ? 'Enviando...' : 'Notificar Depósito'}
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default LoadWalletManual;