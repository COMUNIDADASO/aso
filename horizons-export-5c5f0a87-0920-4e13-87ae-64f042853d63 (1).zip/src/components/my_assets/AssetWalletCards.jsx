import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertTriangle, ExternalLink } from 'lucide-react';
import { ASSET_CONFIG } from '@/config/assets.jsx';
import WalletActionModal from '@/components/my_assets/WalletActionModal';

const AssetWalletCards = ({ balances, loadingBalances, onRefreshBalances, currentUser, userProfileData, loadingProfile }) => {
  const [selectedAssetModal, setSelectedAssetModal] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleCardClick = (asset) => {
    setSelectedAssetModal(asset);
    setIsModalOpen(true);
  };

  const renderAssetCard = (assetConf) => {
    const balance = balances[assetConf.symbol] || 0;
    const IconComponent = assetConf.iconComponent || (() => <AlertTriangle className="h-8 w-8 text-yellow-400"/>);

    return (
      <motion.div
        key={assetConf.symbol}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        whileHover={{ y: -5, boxShadow: "0px 8px 15px rgba(0,0,0,0.25)" }}
        className="cursor-pointer"
        onClick={() => handleCardClick(assetConf)}
      >
        <Card className={`rounded-xl shadow-lg overflow-hidden h-full flex flex-col ${assetConf.isNative ? 'bg-gradient-to-br from-gold-aso/20 via-yellow-700/10 to-slate-800/50 border-yellow-500/30' : 'bg-slate-800/60 border-slate-700/50 hover:border-purple-500/70'}`}>
          <CardHeader className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <IconComponent className="h-8 w-8" />
                <CardTitle className={`text-xl font-semibold ${assetConf.isNative ? 'text-gold-aso' : 'text-slate-100'}`}>{assetConf.name}</CardTitle>
              </div>
              <ExternalLink size={16} className="text-slate-500 hover:text-purple-400 transition-colors" />
            </div>
          </CardHeader>
          <CardContent className="p-4 flex-grow">
            <p className={`text-3xl font-bold ${assetConf.isNative ? 'text-yellow-300' : 'text-white'}`}>{balance.toLocaleString(undefined, { maximumFractionDigits: assetConf.precision })}</p>
            <p className="text-sm text-slate-400">{assetConf.symbol}</p>
          </CardContent>
        </Card>
      </motion.div>
    );
  };
  
  if (loadingBalances) {
     return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-slate-800/60 border-slate-700/50 p-4 rounded-xl shadow-lg">
              <div className="flex items-center space-x-3 mb-3">
                <div className="h-8 w-8 bg-slate-700 rounded-full animate-pulse"></div>
                <div className="h-5 w-3/5 bg-slate-700 rounded animate-pulse"></div>
              </div>
              <div className="h-8 w-4/5 bg-slate-700 rounded mb-1 animate-pulse"></div>
              <div className="h-4 w-1/5 bg-slate-700 rounded animate-pulse"></div>
            </Card>
          ))}
        </div>
     );
  }

  const assetsToRender = ASSET_CONFIG.filter(assetConf => balances[assetConf.symbol] !== undefined);

  return (
    <>
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-center">
        <h2 className="text-2xl font-semibold text-slate-100 mb-4 sm:mb-0">Mis Wallets</h2>
        <Button onClick={onRefreshBalances} variant="outline" className="border-purple-500 text-purple-300 hover:bg-purple-500/10" disabled={loadingBalances || !currentUser}>
          <RefreshCw className={`mr-2 h-4 w-4 ${loadingBalances ? 'animate-spin' : ''}`} /> Actualizar Saldos
        </Button>
      </div>
      
      {Object.keys(balances).length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {assetsToRender.map(assetConf => renderAssetCard(assetConf))}
        </div>
      ) : (
        <Card className="bg-slate-800/60 border-slate-700/50 p-8 rounded-xl shadow-lg text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400 mb-4" />
          <CardTitle className="text-xl text-slate-100 mb-2">No se encontraron saldos</CardTitle>
          <CardDescription className="text-slate-400">Parece que aún no tienes activos en tu cuenta o no hemos podido cargarlos.</CardDescription>
        </Card>
      )}

      {selectedAssetModal && (
        <WalletActionModal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          asset={selectedAssetModal}
          balance={balances[selectedAssetModal.symbol] || 0}
          userProfileData={userProfileData}
          loadingProfile={loadingProfile}
        />
      )}
    </>
  );
};

export default AssetWalletCards;