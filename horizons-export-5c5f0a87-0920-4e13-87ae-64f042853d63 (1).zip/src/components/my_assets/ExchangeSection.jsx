import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowRightLeft, Loader2, AlertTriangle, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { DEFAULT_RATES, getAssetConfig } from '@/config/assets.jsx';

const ExchangeSection = () => {
  const { toast } = useToast();
  const [fromAsset, setFromAsset] = useState('ASO');
  const [toAsset, setToAsset] = useState('USDT');
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [rates, setRates] = useState(DEFAULT_RATES);
  const [loadingRates, setLoadingRates] = useState(true);
  const [isExchanging, setIsExchanging] = useState(false);
  const [error, setError] = useState(null);
  const [isNetworkError, setIsNetworkError] = useState(false);
  const [isRateLimitError, setIsRateLimitError] = useState(false);

  const availableAssets = ['ASO', 'USDT', 'BTC', 'ETH', 'BNB', 'SOL'];

  const fetchRates = useCallback(async () => {
    setLoadingRates(true);
    setError(null);
    setIsNetworkError(false);
    setIsRateLimitError(false);
    try {
      const { data, error: functionError } = await supabase.functions.invoke('get-coinmarketcap-prices', {
        body: { symbols: ['USDT', 'BTC', 'ETH', 'BNB', 'SOL'] }
      });

      if (functionError) {
        console.error('Supabase function error fetching rates:', functionError);
        const errorMessageLower = functionError.message ? functionError.message.toLowerCase() : "";
        if (errorMessageLower.includes('failed to fetch')) {
          setIsNetworkError(true);
          throw new Error(`Error de red al obtener tasas. Usando valores por defecto.`);
        }
        if (errorMessageLower.includes("too many requests") || errorMessageLower.includes("429") || errorMessageLower.includes("rate limit")) {
          setIsRateLimitError(true);
          throw new Error(`Límite de API de precios (CoinMarketCap) alcanzado. Usando valores por defecto.`);
        }
        throw new Error(`Error del servidor de precios: ${functionError.message}`);
      }
      
      if (data && data.error) {
        console.error('Error from get-coinmarketcap-prices function:', data.error);
        const errorDetailsLower = data.details ? String(data.details).toLowerCase() : "";
        const errorFromFunctionLower = data.error ? String(data.error).toLowerCase() : "";

        if (errorDetailsLower.includes("too many requests") || errorDetailsLower.includes("429") || errorDetailsLower.includes("rate limit") ||
            errorFromFunctionLower.includes("too many requests") || errorFromFunctionLower.includes("429") || errorFromFunctionLower.includes("rate limit")) {
          setIsRateLimitError(true);
          throw new Error(`Límite de API de precios (CoinMarketCap) alcanzado. Usando valores por defecto.`);
        }
        throw new Error(`Error procesando precios: ${data.error}`);
      }

      if (data && data.rates) {
        setRates(prevRates => ({ ...DEFAULT_RATES, ...prevRates, ...data.rates }));
      } else {
        console.warn('No rates data received, using default rates.');
        setRates(DEFAULT_RATES);
         setError('No se pudieron obtener las tasas de cambio actuales. Usando valores por defecto.');
      }
    } catch (err) {
      console.error('Error fetching rates:', err);
      if (err.message.includes("Error de red")) setIsNetworkError(true);
      if (err.message.includes("Rate Limit") || err.message.includes("Too Many Requests") || err.message.includes("429")) setIsRateLimitError(true);
      setError(err.message || 'No se pudieron cargar las tasas de cambio. Usando tasas por defecto.');
      setRates(DEFAULT_RATES); 
    } finally {
      setLoadingRates(false);
    }
  }, []);

  useEffect(() => {
    fetchRates();
    const intervalId = setInterval(fetchRates, 21600000); 
    return () => clearInterval(intervalId);
  }, [fetchRates]);

  useEffect(() => {
    if (fromAmount && rates[fromAsset] && rates[toAsset] && rates[toAsset] !== 0) {
      const amountInUsd = parseFloat(fromAmount) * rates[fromAsset];
      const targetAmount = amountInUsd / rates[toAsset];
      const toAssetConfig = getAssetConfig(toAsset);
      setToAmount(targetAmount.toFixed(toAssetConfig.precision));
    } else {
      setToAmount('');
    }
  }, [fromAmount, fromAsset, toAsset, rates]);

  const handleSwapAssets = () => {
    setFromAsset(toAsset);
    setToAsset(fromAsset);
  };

  const handleExchange = async () => {
    if (!fromAmount || parseFloat(fromAmount) <= 0) {
      toast({
        title: 'Error de Intercambio',
        description: 'Por favor, ingresa una cantidad válida para intercambiar.',
        variant: 'destructive',
      });
      return;
    }

    setIsExchanging(true);
    setIsNetworkError(false); 
    try {
      const userResponse = await supabase.auth.getUser();
      const userId = userResponse.data.user?.id;

      if (!userId) {
        throw new Error("No se pudo obtener el ID de usuario. Asegúrate de haber iniciado sesión.");
      }
      
      const { data, error: exchangeError } = await supabase.functions.invoke('process-exchange', {
        body: {
          fromAsset,
          toAsset,
          fromAmount: parseFloat(fromAmount),
          userId: userId
        },
      });

      if (exchangeError) {
        if (exchangeError instanceof TypeError && exchangeError.message.toLowerCase().includes('failed to fetch')) {
          setIsNetworkError(true);
          throw new Error(`Error de red al procesar intercambio. Verifica tu conexión.`);
        }
        throw exchangeError;
      }
      
      if (data && data.error) {
        throw new Error(data.error);
      }

      toast({
        title: 'Intercambio Exitoso',
        description: `Has intercambiado ${fromAmount} ${fromAsset} por ${toAmount} ${toAsset}.`,
        variant: 'success',
      });
      setFromAmount('');
      setToAmount('');
      
    } catch (err) {
      console.error('Error during exchange:', err);
      if (err.message.includes("Error de red")) setIsNetworkError(true);
      toast({
        title: 'Error de Intercambio',
        description: err.message || 'Ocurrió un error al procesar el intercambio. Inténtalo de nuevo.',
        variant: 'destructive',
      });
    } finally {
      setIsExchanging(false);
    }
  };

  const getAssetLogoElement = (assetSymbol) => {
    const assetConfig = getAssetConfig(assetSymbol);
    const IconComponent = assetConfig.iconComponent;
    return IconComponent ? <IconComponent className="h-5 w-5" /> : <ArrowRightLeft className="h-5 w-5 text-gray-400" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-slate-800/60 border-slate-700 shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-gold-aso flex items-center">
            <ArrowRightLeft className="mr-2 h-6 w-6" />
            Intercambio Rápido
          </CardTitle>
          <CardDescription className="text-gray-400">
            Intercambia tus activos de forma segura y eficiente.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loadingRates && (
            <div className="flex items-center justify-center p-6 text-gray-300">
              <Loader2 className="mr-2 h-5 w-5 animate-spin text-purple-400" />
              Cargando tasas de cambio...
            </div>
          )}
          {!loadingRates && error && (
             <div className="flex items-center justify-center p-4 mb-4 text-sm text-red-400 bg-red-900/30 rounded-lg">
              {isRateLimitError ? <AlertTriangle className="mr-2 h-5 w-5" /> : isNetworkError ? <WifiOff className="mr-2 h-5 w-5" /> : <AlertTriangle className="mr-2 h-5 w-5" />}
              {error}
            </div>
          )}
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="w-full sm:w-2/5">
                <label htmlFor="fromAsset" className="block text-sm font-medium text-gray-300 mb-1">Desde</label>
                <Select value={fromAsset} onValueChange={setFromAsset}>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-purple-500">
                    <div className="flex items-center">
                      {getAssetLogoElement(fromAsset)}
                      <SelectValue placeholder="Seleccionar activo" className="ml-2" />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600 text-white">
                    {availableAssets.map(asset => (
                      <SelectItem key={asset} value={asset} className="hover:bg-slate-600 focus:bg-slate-600">
                        <div className="flex items-center">
                          {getAssetLogoElement(asset)}
                          <span className="ml-2">{asset}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full sm:w-3/5">
                <label htmlFor="fromAmount" className="block text-sm font-medium text-gray-300 mb-1">Cantidad</label>
                <Input
                  id="fromAmount"
                  type="number"
                  placeholder="0.00"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-purple-500"
                />
              </div>
            </div>

            <div className="flex justify-center items-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSwapAssets}
                className="text-purple-400 hover:text-purple-300 hover:bg-slate-700 transition-transform duration-300 ease-in-out hover:scale-110"
                aria-label="Intercambiar activos"
              >
                <ArrowRightLeft className="h-6 w-6" />
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="w-full sm:w-2/5">
                <label htmlFor="toAsset" className="block text-sm font-medium text-gray-300 mb-1">Hacia</label>
                <Select value={toAsset} onValueChange={setToAsset}>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-purple-500">
                     <div className="flex items-center">
                        {getAssetLogoElement(toAsset)}
                        <SelectValue placeholder="Seleccionar activo" className="ml-2" />
                      </div>
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600 text-white">
                    {availableAssets.map(asset => (
                      <SelectItem key={asset} value={asset} className="hover:bg-slate-600 focus:bg-slate-600">
                        <div className="flex items-center">
                          {getAssetLogoElement(asset)}
                          <span className="ml-2">{asset}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full sm:w-3/5">
                <label htmlFor="toAmount" className="block text-sm font-medium text-gray-300 mb-1">Cantidad Estimada</label>
                <Input
                  id="toAmount"
                  type="number"
                  placeholder="0.00"
                  value={toAmount}
                  readOnly
                  className="bg-slate-900 border-slate-700 text-gray-300 placeholder-gray-500 cursor-not-allowed"
                />
              </div>
            </div>
            
            <div className="text-xs text-center text-gray-400 pt-2">
              Tasa de cambio (vs USD): 1 {fromAsset} ≈ ${rates[fromAsset]?.toFixed(2) || 'N/A'} | 1 {toAsset} ≈ ${rates[toAsset]?.toFixed(2) || 'N/A'}
              <br />
              Las tasas son aproximadas y pueden variar. {isRateLimitError ? "Las tasas pueden estar desactualizadas por límite de API." : ""}
            </div>

            <Button
              onClick={handleExchange}
              disabled={isExchanging || loadingRates || !fromAmount || parseFloat(fromAmount) <= 0}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 text-base transition-all duration-300 ease-in-out transform hover:scale-105"
            >
              {isExchanging ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <ArrowRightLeft className="mr-2 h-5 w-5" />
              )}
              {isExchanging ? 'Procesando Intercambio...' : 'Intercambiar Ahora'}
            </Button>
            {isNetworkError && !isExchanging && (
              <p className="text-center text-sm text-yellow-400 mt-2 flex items-center justify-center">
                <WifiOff size={16} className="mr-1"/> Podría haber problemas de red. Intenta de nuevo.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ExchangeSection;