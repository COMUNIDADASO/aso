import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Send, Search, UserCircle, Landmark, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const TransferSection = ({ availableAssets, onTransaction, userProfileData, loadingProfile }) => {
  const { user } = useAuth();
  const { toast } = useToast();

  const [recipientIdentifier, setRecipientIdentifier] = useState('');
  const [amount, setAmount] = useState('');
  const [selectedAsset, setSelectedAsset] = useState(availableAssets.length > 0 ? availableAssets[0].symbol : 'ASO');
  const [recipientInfo, setRecipientInfo] = useState(null);
  const [isSearchingRecipient, setIsSearchingRecipient] = useState(false);
  const [isProcessingTransfer, setIsProcessingTransfer] = useState(false);
  const [searchError, setSearchError] = useState('');

  const selectedAssetDetails = availableAssets.find(a => a.symbol === selectedAsset);
  const balance = selectedAssetDetails ? selectedAssetDetails.balance : 0;

  const handleSearchRecipient = useCallback(async () => {
    if (!recipientIdentifier.trim()) {
      setSearchError("Por favor, ingresa un identificador (email, cédula o celular).");
      setRecipientInfo(null);
      return;
    }
    setIsSearchingRecipient(true);
    setSearchError('');
    setRecipientInfo(null);

    try {
      const { data, error } = await supabase.functions.invoke('find-user-for-transfer', {
        body: { identifier: recipientIdentifier.trim() },
      });

      if (error) throw new Error(`Error de red o función: ${error.message}`);
      if (data.error) throw new Error(data.error);
      
      if (data.user && data.user.auth_user_id === user.id) {
        throw new Error("No puedes transferirte fondos a ti mismo.");
      }

      if (data.user) {
        setRecipientInfo(data.user);
      } else {
        setSearchError("Usuario no encontrado o no activo para transferencias.");
      }
    } catch (err) {
      setSearchError(err.message);
      setRecipientInfo(null);
      toast({
        title: 'Error Buscando Destinatario',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      setIsSearchingRecipient(false);
    }
  }, [recipientIdentifier, toast, user]);

  const handleTransfer = async (e) => {
    e.preventDefault();
    if (loadingProfile) {
      toast({ title: 'Verificando perfil...', description: 'Por favor, espere un momento.', variant: 'default' });
      return;
    }
    if (!userProfileData?.raw_data?.biometric_enabled) {
      toast({
        title: 'Verificación Requerida',
        description: 'CONFIGURE SU BIOMETRÍA PARA RETIRAR.',
        variant: 'destructive',
      });
      return;
    }

    if (!user || !recipientInfo || !recipientInfo.auth_user_id || !amount || !selectedAsset) {
      toast({ title: 'Datos incompletos', description: 'Verifica el destinatario, monto y activo.', variant: 'destructive' });
      return;
    }

    const transferAmount = parseFloat(amount);
    if (isNaN(transferAmount) || transferAmount <= 0) {
      toast({ title: 'Monto inválido', description: 'El monto debe ser un número positivo.', variant: 'destructive' });
      return;
    }

    if (transferAmount > balance) {
      toast({ title: 'Fondos insuficientes', description: `No tienes suficiente ${selectedAsset}. Saldo actual: ${balance.toFixed(8)}`, variant: 'destructive' });
      return;
    }

    setIsProcessingTransfer(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-transfer', {
        body: {
          sender_user_id: user.id,
          recipient_identifier: recipientIdentifier.trim(), 
          recipient_user_id: recipientInfo.auth_user_id,
          recipient_name: recipientInfo.name,
          asset_symbol: selectedAsset,
          amount: transferAmount,
        },
      });

      if (error) throw new Error(`Error de red o función: ${error.message}`);
      if (data.error) throw new Error(data.error);

      toast({
        title: 'Transferencia Exitosa',
        description: `${transferAmount} ${selectedAsset} enviados a ${recipientInfo.name || recipientInfo.email}.`,
      });
      setRecipientIdentifier('');
      setAmount('');
      setRecipientInfo(null);
      setSearchError('');
      if (onTransaction) onTransaction(); 
    } catch (err) {
      toast({
        title: 'Error en la Transferencia',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      setIsProcessingTransfer(false);
    }
  };
  
  useEffect(() => {
    setRecipientInfo(null);
    setSearchError('');
  }, [recipientIdentifier]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="p-6 bg-slate-800/50 rounded-xl shadow-xl glass-card"
    >
      <h3 className="text-2xl font-semibold mb-6 text-gold-aso flex items-center">
        <Send className="mr-3 text-purple-400" />
        Realizar Transferencia
      </h3>
      <form onSubmit={handleTransfer} className="space-y-6">
        <div>
          <Label htmlFor="recipient" className="text-gray-300 mb-1 block">Destinatario (Email, Cédula o Celular)</Label>
          <div className="flex space-x-2">
            <Input
              id="recipient"
              type="text"
              value={recipientIdentifier}
              onChange={(e) => setRecipientIdentifier(e.target.value)}
              placeholder="Ej: usuario@email.com o 12345678"
              className="flex-grow"
              disabled={isSearchingRecipient || isProcessingTransfer}
            />
            <Button
              type="button"
              onClick={handleSearchRecipient}
              disabled={isSearchingRecipient || !recipientIdentifier.trim()}
              className="shrink-0 bg-purple-600 hover:bg-purple-700"
            >
              {isSearchingRecipient ? <Loader2 className="animate-spin h-5 w-5" /> : <Search className="h-5 w-5" />}
              <span className="ml-2 hidden sm:inline">Buscar</span>
            </Button>
          </div>
          {searchError && <p className="text-red-400 text-sm mt-2 flex items-center"><AlertTriangle size={16} className="mr-1"/>{searchError}</p>}
          {recipientInfo && (
            <div className="mt-3 p-3 bg-slate-700/50 rounded-md text-sm text-green-300 flex items-center">
              <UserCircle size={20} className="mr-2 text-purple-400"/>
              Destinatario: <span className="font-semibold ml-1">{recipientInfo.name || recipientInfo.email}</span> (ID: ...{recipientInfo.auth_user_id.slice(-6)})
            </div>
          )}
        </div>

        <div>
          <Label htmlFor="asset" className="text-gray-300 mb-1 block">Activo a Transferir</Label>
          <Select
            value={selectedAsset}
            onValueChange={setSelectedAsset}
            disabled={isProcessingTransfer || availableAssets.length === 0}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Selecciona un activo" />
            </SelectTrigger>
            <SelectContent>
              {availableAssets.length > 0 ? availableAssets.map(asset => (
                <SelectItem key={asset.symbol} value={asset.symbol}>
                  {asset.name} ({asset.symbol}) - Saldo: {asset.balance.toFixed(8)}
                </SelectItem>
              )) : (
                <SelectItem value="ASO" disabled>ASO (Cargando...)</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="amount" className="text-gray-300 mb-1 block">Monto</Label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`0.00 ${selectedAsset}`}
            min="0.00000001" 
            step="any"
            disabled={!recipientInfo || isProcessingTransfer || !selectedAssetDetails}
          />
           {selectedAssetDetails && <p className="text-xs text-gray-400 mt-1">Saldo disponible de {selectedAsset}: {balance.toFixed(8)}</p>}
        </div>

        <Button
          type="submit"
          className="w-full gradient-button"
          disabled={!recipientInfo || !amount || isProcessingTransfer || isSearchingRecipient || !selectedAssetDetails || parseFloat(amount) > balance}
        >
          {isProcessingTransfer ? (
            <>
              <Loader2 className="animate-spin h-5 w-5 mr-2" />
              Procesando...
            </>
          ) : (
            <>
              <Send className="h-5 w-5 mr-2" />
              Transferir {amount} {selectedAsset}
            </>
          )}
        </Button>
      </form>
      <div className="mt-6 p-4 bg-slate-700/30 rounded-lg text-sm text-gray-400 space-y-2">
          <p className="font-semibold text-purple-300 flex items-center"><Landmark size={18} className="mr-2"/> Sobre las Transferencias:</p>
          <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Las transferencias entre usuarios de la plataforma son instantáneas.</li>
              <li>Asegúrate de que el identificador del destinatario (email, cédula o celular) sea correcto.</li>
              <li>Las transferencias son finales y no se pueden revertir una vez confirmadas.</li>
              <li>Se registrará una transacción para el remitente y otra para el destinatario.</li>
          </ul>
      </div>
    </motion.div>
  );
};

export default TransferSection;