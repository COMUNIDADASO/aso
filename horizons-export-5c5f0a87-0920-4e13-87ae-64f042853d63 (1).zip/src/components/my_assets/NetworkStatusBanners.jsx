import React from 'react';
import { WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

const NetworkErrorBanner = ({ title, message, onRetry }) => (
  <div className="mb-6 p-4 bg-yellow-900/30 border border-yellow-700/50 rounded-lg text-center">
    <WifiOff className="mx-auto h-8 w-8 text-yellow-400 mb-2" />
    <p className="text-yellow-300 font-semibold">{title}</p>
    <p className="text-slate-300 text-sm">{message}</p>
    {onRetry && (
      <Button variant="link" onClick={onRetry} className="text-purple-400 mt-1">Reintentar</Button>
    )}
  </div>
);

const NetworkStatusBanners = ({ errors, retryFunctions }) => (
  <>
    {errors.auth && <NetworkErrorBanner title="Error de Red (Autenticación)" message={errors.auth} />}
    {errors.profile && <NetworkErrorBanner title="Error de Red (Perfil)" message={errors.profile} onRetry={retryFunctions.profile} />}
    {errors.wallet && <NetworkErrorBanner title="Error de Red (Billetera)" message={errors.wallet} onRetry={retryFunctions.wallet} />}
  </>
);

export default NetworkStatusBanners;