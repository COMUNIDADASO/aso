import React, { useState } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { DayPicker } from 'react-day-picker';
    import 'react-day-picker/dist/style.css';
    import { format } from 'date-fns';
    import { es } from 'date-fns/locale';
    import { Loader2, Calendar, AlertTriangle } from 'lucide-react';

    const BookingModal = ({ isOpen, setIsOpen, training, userId, onBookingSuccess }) => {
        const [selectedDate, setSelectedDate] = useState(null);
        const [isBooking, setIsBooking] = useState(false);
        const { toast } = useToast();

        const handleBooking = async () => {
            if (!selectedDate) {
                toast({ title: "Selecciona una fecha", description: "Debes elegir una fecha para la capacitación.", variant: "destructive" });
                return;
            }

            setIsBooking(true);
            try {
                const { data, error } = await supabase.functions.invoke('book-training', {
                    body: {
                        userId,
                        trainingId: training.id,
                        bookingDate: format(selectedDate, 'yyyy-MM-dd'),
                    },
                });

                if (error) throw new Error(`Error de red: ${error.message}`);
                if (data.error) throw new Error(data.error);

                toast({
                    title: "¡Reserva Exitosa!",
                    description: `Has reservado "${training.title}" para el ${format(selectedDate, 'PPP', { locale: es })}.`,
                    variant: "success",
                });
                onBookingSuccess();
                setIsOpen(false);
            } catch (err) {
                toast({
                    title: "Error en la Reserva",
                    description: err.message,
                    variant: "destructive",
                });
            } finally {
                setIsBooking(false);
            }
        };

        const today = new Date();

        return (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="sm:max-w-[425px] bg-slate-900 border-slate-700 text-white">
                    <DialogHeader>
                        <DialogTitle className="text-gold-aso text-2xl">Reservar Capacitación</DialogTitle>
                        <DialogDescription className="text-slate-400">
                            Estás a punto de reservar: <span className="font-semibold text-purple-300">{training.title}</span>.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                        <h4 className="text-slate-300 mb-2">Selecciona una fecha en el calendario:</h4>
                        <div className="flex justify-center rounded-md bg-slate-800 p-2">
                            <DayPicker
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                fromDate={today}
                                locale={es}
                                styles={{
                                    caption: { color: '#d1d5db' },
                                    head: { color: '#9ca3af' },
                                    day: { color: '#e5e7eb' },
                                    nav_button: { color: '#c4b5fd' },
                                }}
                                classNames={{
                                    day_selected: 'bg-purple-600 text-white',
                                    day_today: 'text-gold-aso font-bold',
                                }}
                            />
                        </div>
                        {selectedDate && (
                            <p className="text-center mt-4 text-green-400">
                                Fecha seleccionada: {format(selectedDate, 'PPP', { locale: es })}
                            </p>
                        )}
                    </div>
                    <div className="p-3 bg-slate-800/50 rounded-lg text-sm">
                        <p className="flex items-center text-yellow-400"><AlertTriangle size={16} className="mr-2" />Costo de la reserva: <b className="ml-1">${parseFloat(training.cost).toFixed(2)} USD</b></p>
                        <p className="text-slate-400 mt-1">Este monto se descontará de tu saldo en USD. Esta acción es irreversible.</p>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsOpen(false)} className="border-slate-600 text-slate-300 hover:bg-slate-700">Cancelar</Button>
                        <Button
                            onClick={handleBooking}
                            disabled={!selectedDate || isBooking}
                            className="bg-gradient-to-r from-purple-600 to-blue-600"
                        >
                            {isBooking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Calendar className="mr-2 h-4 w-4" />}
                            {isBooking ? 'Confirmando...' : 'Confirmar Reserva'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };

    export default BookingModal;