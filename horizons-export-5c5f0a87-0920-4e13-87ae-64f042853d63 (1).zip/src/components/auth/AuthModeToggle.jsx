import React from 'react';

const AuthModeToggle = ({ authMode, setAuthMode, isEmailOnly = false }) => {
  if (authMode === 'login') {
    return (
      <>
        <span>¿No tienes cuenta?</span>
        <button onClick={() => setAuthMode('signup')} className="font-semibold text-purple-400 hover:text-purple-300 ml-1">
          Regístrate aquí
        </button>
        <br />
        <button onClick={() => setAuthMode('forgotPassword')} className="text-xs text-slate-500 hover:text-slate-400 mt-1">
          ¿Olvidaste tu contraseña?
        </button>
      </>
    );
  }

  if (authMode === 'signup') {
    return (
      <>
        <span>¿Ya tienes una cuenta?</span>
        <button onClick={() => setAuthMode('login')} className="font-semibold text-purple-400 hover:text-purple-300 ml-1">
          Inicia sesión
        </button>
      </>
    );
  }

  if (authMode === 'forgotPassword') {
    return (
      <>
        <span>¿Recordaste tu contraseña?</span>
        <button onClick={() => setAuthMode('login')} className="font-semibold text-purple-400 hover:text-purple-300 ml-1">
          Inicia sesión
        </button>
        <br />
        <span>¿No tienes cuenta?</span>
        <button onClick={() => setAuthMode('signup')} className="font-semibold text-purple-400 hover:text-purple-300 ml-1">
          Regístrate aquí
        </button>
      </>
    );
  }

  return null;
};

export default AuthModeToggle;