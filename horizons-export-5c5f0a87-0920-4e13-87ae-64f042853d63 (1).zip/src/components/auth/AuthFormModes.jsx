import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Eye, EyeOff, LogIn, UserPlus, Send } from 'lucide-react';

export const LoginFormMode = ({ identifier, setIdentifier, password, setPassword, showPassword, togglePasswordVisibility, handleLogin, isLoading, isEmailOnly }) => (
  <form onSubmit={handleLogin} className="space-y-4">
    <div>
      <label htmlFor="login-identifier" className="sr-only">{isEmailOnly ? "Email" : "Email / Cédula / Celular"}</label>
      <Input
        id="login-identifier"
        type={isEmailOnly ? "email" : "text"}
        placeholder={isEmailOnly ? "tu@email.com" : "Email, Cédula o Celular"}
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
    </div>
    <div className="relative">
      <label htmlFor="login-password" className="sr-only">Contraseña</label>
      <Input
        id="login-password"
        type={showPassword ? 'text' : 'password'}
        placeholder="Contraseña"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
      <Button type="button" variant="ghost" size="icon" onClick={togglePasswordVisibility} className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-slate-400 hover:text-purple-400">
        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
      </Button>
    </div>
    <Button type="submit" className="w-full gradient-button" disabled={isLoading}>
      <LogIn className="mr-2 h-5 w-5" />
      {isLoading ? 'Ingresando...' : 'Ingresar'}
    </Button>
  </form>
);

export const SignupFormMode = ({ identifier, setIdentifier, password, setPassword, confirmPassword, setConfirmPassword, showPassword, togglePasswordVisibility, handleSignUp, isLoading, isEmailOnly }) => (
  <form onSubmit={handleSignUp} className="space-y-4">
    <div>
      <label htmlFor="signup-identifier" className="sr-only">{isEmailOnly ? "Email" : "Email / Cédula / Celular"}</label>
      <Input
        id="signup-identifier"
        type={isEmailOnly ? "email" : "text"}
        placeholder={isEmailOnly ? "tu@email.com" : "Email, Cédula o Celular"}
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
    </div>
    <div className="relative">
      <label htmlFor="signup-password" className="sr-only">Contraseña</label>
      <Input
        id="signup-password"
        type={showPassword ? 'text' : 'password'}
        placeholder="Contraseña (mín. 8 caracteres)"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
      <Button type="button" variant="ghost" size="icon" onClick={togglePasswordVisibility} className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-slate-400 hover:text-purple-400">
        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
      </Button>
    </div>
    <div>
      <label htmlFor="signup-confirm-password" className="sr-only">Confirmar Contraseña</label>
      <Input
        id="signup-confirm-password"
        type="password"
        placeholder="Confirmar Contraseña"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
    </div>
    <Button type="submit" className="w-full gradient-button" disabled={isLoading}>
      <UserPlus className="mr-2 h-5 w-5" />
      {isLoading ? 'Registrando...' : 'Crear Cuenta'}
    </Button>
  </form>
);

export const ForgotPasswordByEmailMode = ({ email, setEmail, handlePasswordResetByEmail, isLoading }) => (
  <form onSubmit={handlePasswordResetByEmail} className="space-y-4">
    <div>
      <label htmlFor="forgot-email" className="sr-only">Email</label>
      <Input
        id="forgot-email"
        type="email"
        placeholder="Ingresa tu email registrado"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        className="bg-slate-700/80 border-slate-600"
      />
    </div>
    <Button type="submit" className="w-full gradient-button" disabled={isLoading}>
      <Send className="mr-2 h-5 w-5" />
      {isLoading ? 'Enviando...' : 'Enviar Enlace de Recuperación'}
    </Button>
  </form>
);