import React from 'react';
import { Input } from '@/components/ui/input';
import { Eye, EyeOff, Mail, KeyRound, Smartphone, Fingerprint } from 'lucide-react';

export const IdentifierField = ({ value, onChange, placeholder, id = "identifier" }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">
      Email, Cédula o Celular <span className="text-red-500">*</span>
    </label>
    <div className="relative">
      <Smartphone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
      <Input
        id={id} type="text" value={value} onChange={onChange}
        placeholder={placeholder} required
        className="pl-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
      />
    </div>
  </div>
);

export const EmailField = ({ value, onChange, placeholder, id = "email", isRequired = true }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">
      Correo Electrónico {isRequired && <span className="text-red-500">*</span>}
    </label>
    <div className="relative">
      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
      <Input
        id={id} type="email" value={value} onChange={onChange}
        placeholder={placeholder} required={isRequired}
        className="pl-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
      />
    </div>
  </div>
);

export const PasswordField = ({ value, onChange, placeholder, showPassword, togglePasswordVisibility, id = "password" }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">Contraseña <span className="text-red-500">*</span></label>
    <div className="relative">
      <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
      <Input
        id={id} type={showPassword ? 'text' : 'password'} value={value} onChange={onChange}
        placeholder={placeholder} required
        className="pl-10 pr-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
      />
      <button type="button" onClick={togglePasswordVisibility} className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm" aria-label={showPassword ? "Ocultar" : "Mostrar"}>
        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
      </button>
    </div>
  </div>
);

export const ConfirmPasswordField = ({ value, onChange, placeholder, showPassword, id = "confirm-password" }) => (
   <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">Confirmar Contraseña <span className="text-red-500">*</span></label>
    <Input
      id={id} type={showPassword ? 'text' : 'password'} value={value} onChange={onChange}
      placeholder={placeholder} required
      className="pl-3 pr-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
    />
  </div>
);

export const IdentifierResetField = ({ value, onChange, placeholder, id = "identifier-reset" }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">
      Cédula o Celular Registrado <span className="text-red-500">*</span>
    </label>
    <div className="relative">
      <Fingerprint className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
      <Input
        id={id} type="text" value={value} onChange={onChange}
        placeholder={placeholder} required
        className="pl-10 bg-slate-700 border-slate-600 text-white focus:border-purple-500"
      />
    </div>
  </div>
);