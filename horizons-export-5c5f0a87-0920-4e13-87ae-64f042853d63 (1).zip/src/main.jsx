import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import App from '@/App';
import '@/index.css';
import { Web3WalletProvider } from '@/context/Web3WalletProvider';
import { ThemeProvider } from '@/contexts/ThemeProvider';

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then((registration) => {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      })
      .catch((error) => {
        console.log('ServiceWorker registration failed: ', error);
      });
  });
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Router>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <Web3WalletProvider>
          <App />
        </Web3WalletProvider>
      </ThemeProvider>
    </Router>
  </React.StrictMode>
);