import React from 'react';
import { DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';

const createIcon = (src, alt) => ({ className, ...props }) => (
  <img src={src} alt={alt} className={cn("h-5 w-5", className)} {...props} />
);

// Wallet & Exchange Icons
export const AsoIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/21fc331c2a7fe1b71c8445d1388db24e.png", "ASO");
export const UglyCashIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/2d45387e709f8ca503c4389092b0ddee.png", "Ugly Cash");
export const KucoinIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/8069f0678b1c4f2b78f922ea140849c0.png", "KuCoin");
export const CoinexIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/da84b34bf66555002583255568d8bb0f.png", "CoinEx");
export const MetaMaskIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/99d8f987e7679d95b7c39efd786c2394.png", "MetaMask");
export const TrustWalletIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/c69b922c267bf1410c56035b6d775347.png", "Trust Wallet");


// Crypto Icons
const BtcIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/7cf5b3c3c5bee8d37344c3ad726d6df7.png", "BTC");
const EthIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/913c891d14eafd84d8d615e365b66566.png", "ETH");
const BnbIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/264f4a7625292041907cada7beea84ea.png", "BNB");
export const BinanceIcon = BnbIcon;
const SolIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/6210d1e543c456a8b225d26a437b01e5.png", "SOL");
const UsdtIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/4edbdaf89561c44f47c584814f8bfd8f.png", "USDT");
const VercoinIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/95a67ffaa4e987f0310ee8c19fcb48a8.png", "Vercoin");
const UsdcIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/3b5b15c599a62d5e1ce79100dc83fe64.png", "USDC");
const XrpIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/e86afbe439c9a9507cad6031912ff581.png", "XRP");
const DogeIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/efd04110ce26d305da2eceddf7f1fccf.png", "DOGE");
const AdaIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/d581811d9d7cd36709b8fbfc7b330880.png", "ADA");
const AvaxIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/4bbdf7ec82c0bc809d640fcfedd922ef.png", "AVAX");
const ShibIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/577cb728d4bb2f02d9fddd65a2aea5ea.png", "SHIB");
const DotIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/2a476a0b2b3820155b09c7c0b5f4c527.png", "DOT");
const LinkIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/3d4f3ce1a386916a6c42014741b95616.png", "LINK");
const TrxIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/237ee84f1d484b75d433572787569bb5.png", "TRX");
const BchIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/85fab0af3e8b60ddae02e2e6dd0a88f0.png", "BCH");
const LtcIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/38edd2ab281bf981bf4f48cb91a9f0f9.png", "LTC");
const UniIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/087a37b1ef373ad3ca2287e67f7dcd01.png", "UNI");
const MaticIcon = createIcon("https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/97c84fa85dd345a436ca3b05a7aa2faf.png", "MATIC");
export const DefaultIcon = () => <DollarSign className="h-5 w-5 text-gray-400"/>;

export const ASSET_CONFIG = [
  { symbol: 'ASO', name: 'Comunidad ASO', iconComponent: AsoIcon, isNative: true, precision: 10 },
  { symbol: 'USD', name: 'Vercoin', iconComponent: VercoinIcon, color: "text-green-500", precision: 2 },
  { symbol: 'BTC', name: 'Bitcoin', iconComponent: BtcIcon, color: "text-orange-400", precision: 8 },
  { symbol: 'ETH', name: 'Ethereum', iconComponent: EthIcon, color: "text-indigo-400", precision: 8 },
  { symbol: 'BNB', name: 'BNB', iconComponent: BnbIcon, color: "text-yellow-400", precision: 4 },
  { symbol: 'USDT', name: 'Tether', iconComponent: UsdtIcon, color: "text-green-400", precision: 2 },
  { symbol: 'SOL', name: 'Solana', iconComponent: SolIcon, color: "text-purple-400", precision: 6 },
  { symbol: 'USDC', name: 'USD Coin', iconComponent: UsdcIcon, color: "text-blue-400", precision: 2 },
  { symbol: 'XRP', name: 'XRP', iconComponent: XrpIcon, color: "text-blue-300", precision: 6 },
  { symbol: 'DOGE', name: 'Dogecoin', iconComponent: DogeIcon, precision: 2 },
  { symbol: 'ADA', name: 'Cardano', iconComponent: AdaIcon, color: "text-sky-400", precision: 6 },
  { symbol: 'AVAX', name: 'Avalanche', iconComponent: AvaxIcon, color: "text-red-500", precision: 4 },
  { symbol: 'SHIB', name: 'Shiba Inu', iconComponent: ShibIcon, precision: 2 },
  { symbol: 'DOT', name: 'Polkadot', iconComponent: DotIcon, color: "text-pink-500", precision: 8 },
  { symbol: 'LINK', name: 'Chainlink', iconComponent: LinkIcon, color: "text-blue-500", precision: 6 },
  { symbol: 'TRX', name: 'TRON', iconComponent: TrxIcon, color: "text-red-600", precision: 2 },
  { symbol: 'BCH', name: 'Bitcoin Cash', iconComponent: BchIcon, color: "text-green-500", precision: 8 },
  { symbol: 'LTC', name: 'Litecoin', iconComponent: LtcIcon, color: "text-gray-400", precision: 8 },
  { symbol: 'UNI', name: 'Uniswap', iconComponent: UniIcon, color: "text-pink-400", precision: 6 },
  { symbol: 'MATIC', name: 'Polygon', iconComponent: MaticIcon, color: "text-purple-500", precision: 6 },
];

export const getAssetConfig = (symbol) => ASSET_CONFIG.find(a => a.symbol === symbol) || { name: symbol, iconComponent: DefaultIcon, color: "text-gray-400", precision: 2 };

export const DEFAULT_RATES = {
  ASO: 500,    
  BTC: 60000,  
  ETH: 3500,   
  BNB: 600,    
  USDT: 1,     
  SOL: 150,    
  USDC: 1,
  XRP: 0.5,
  DOGE: 0.15,
  ADA: 0.45,
  AVAX: 35,
  SHIB: 0.000025,
  DOT: 7.5,
  LINK: 15,
  TRX: 0.12,
  BCH: 450,
  LTC: 80,
  UNI: 10,
  MATIC: 0.7,
  USD: 1,
};