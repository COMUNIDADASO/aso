import { Bitcoin, DollarSign } from 'lucide-react';
import React from 'react';

export const ASSET_CONFIG = [
  { 
    symbol: 'ASO', 
    name: 'Comunidad ASO', 
    icon: () => <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/5c5f0a87-0920-4e13-87ae-64f042853d63/a174c4000cc2fa6d125aca785a61d663.png" alt="ASO" className="h-6 w-6 mr-2" />, 
    isNative: true,
    precision: 6 
  },
  { 
    symbol: 'BTC', 
    name: 'Bitcoin', 
    icon: Bitcoin, 
    color: "text-orange-400",
    precision: 8 
  },
  { 
    symbol: 'AIDA', 
    name: 'AIDA Placeholder', 
    icon: DollarSign, 
    color: "text-teal-400",
    precision: 2 
  },
  { 
    symbol: 'USDT', 
    name: 'Tether', 
    icon: DollarSign, 
    color: "text-green-400",
    precision: 2
  },
  { 
    symbol: 'USDC', 
    name: 'USD Coin', 
    icon: DollarSign, 
    color: "text-blue-400",
    precision: 2
  },
];

export const getAssetConfig = (symbol) => ASSET_CONFIG.find(a => a.symbol === symbol) || { name: symbol, icon: DollarSign, color: "text-gray-400", precision: 2 };

export const DEFAULT_RATES = { ASO_BTC: 0.00002, ASO_USDT: 10, ASO_USDC: 10, ASO_AIDA: 5, BTC_USDT: 60000 };