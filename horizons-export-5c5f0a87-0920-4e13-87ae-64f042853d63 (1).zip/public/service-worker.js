/* eslint-disable no-restricted-globals */

const CACHE_NAME = 'comunidad-aso-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  // Add paths to your main JS bundles, CSS files, and important images
  // Example: '/assets/logo.png', '/src.mjs' (check your build output for actual filenames)
  '/assets/logo-aso-trans-gold-8dfd3432.png', // Example, check actual generated name
  // You'll need to list other critical assets here
  // Consider caching the main page chunks and AboutPage content if frequently accessed.
];

self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching app shell');
        return cache.addAll(urlsToCache);
      })
      .then(() => {
        console.log('Service Worker: Installation complete');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Caching failed', error);
      })
  );
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  // Remove old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.filter(cache => cache !== CACHE_NAME).map(cache => caches.delete(cache))
      );
    }).then(() => {
      console.log('Service Worker: Old caches cleared, activation complete');
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', (event) => {
  // We only want to cache GET requests.
  if (event.request.method !== 'GET') {
    return;
  }

  // For navigation requests, try network first, then cache (Network Falling Back to Cache).
  // For other assets (CSS, JS, images), try cache first, then network (Cache Falling Back to Network or Cache First).
  
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          // Check if we received a valid response
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          // IMPORTANT: Clone the response. A response is a stream
          // and because we want the browser to consume the response
          // as well as the cache consuming the response, we need
          // to clone it so we have two streams.
          const responseToCache = response.clone();
          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(event.request, responseToCache);
            });
          return response;
        })
        .catch(() => {
          return caches.match(event.request)
            .then(cachedResponse => {
              return cachedResponse || caches.match('/index.html'); // Fallback to home
            });
        })
    );
  } else {
    // Cache First strategy for other assets
    event.respondWith(
      caches.match(event.request)
        .then((response) => {
          if (response) {
            return response; // Return from cache
          }
          // Not in cache, fetch from network
          return fetch(event.request).then(
            (networkResponse) => {
              // Check if we received a valid response
              if(!networkResponse || networkResponse.status !== 200 /*|| networkResponse.type !== 'basic'*/) {
                 // Removed type check for opaque responses like CDN assets
                return networkResponse;
              }
              const responseToCache = networkResponse.clone();
              caches.open(CACHE_NAME)
                .then(cache => {
                  cache.put(event.request, responseToCache);
                });
              return networkResponse;
            }
          ).catch(error => {
            console.error('Service Worker: Fetching asset failed:', error);
            // Optionally, return a fallback placeholder for images or assets if fetch fails
          });
        })
    );
  }
});